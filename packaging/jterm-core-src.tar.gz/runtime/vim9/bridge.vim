vim9script
# Real Vim owns editing, undo, mappings, plugins, buffers and windows.  This
# optional runtime publishes metadata and GUI buffer paint data, and accepts
# a small, explicit action set. It never reconstructs text from PTY output.
# Protocol and installation details are documented beside this file.

if exists('g:jterm_vim9_bridge_loaded')
  finish
endif
if v:version < 900 || !has('vim9script') || !has('channel')
    || !has('job') || !has('timers') || !has('quickfix')
  throw 'JTerm IDE requires Vim 9 with +vim9script +channel +job +timers +quickfix'
endif

var address = $JTERM_VIM9_ADDR
var authToken = $JTERM_VIM9_TOKEN
var projectRoot = empty($JTERM_VIM9_ROOT) ? getcwd() : $JTERM_VIM9_ROOT
# Build tools and language servers started after startup must not inherit the
# bridge credential.  The remaining script-local copy is never serialized.
unlet $JTERM_VIM9_TOKEN
if empty(address) || empty(authToken)
  finish
endif
g:jterm_vim9_bridge_loaded = true
g:jterm_vim9_connected = false
g:jterm_vim9_popup_cards = false
g:jterm_vim9_render_protocol = 0
g:jterm_vim9_virtual_text_after = false
g:jterm_vim9_virtual_text_inline = false

var bridge: channel
var authenticated = false
var workbenchConnected = false
var workbenchActionDepth = 0
var shuttingDown = false
var sending = false
var sequence = 0
var sendBatchDepth = 0
var sendBatch = ''
var pendingQuit = 0
var flushTimer = -1
var pollTimer = -1
var previousState = ''
var diagnosticsKey = ''
var diagnosticsCache: dict<any> = {items: [], total: 0}
var lspDiagnosticsTick = 0
var bufferViews: dict<dict<any>> = {}
var buildJob: job
var buildGeneration = 0
var buildRunning = false
var buildClosed = false
var buildExited = false
var buildCancelled = false
var buildCommand = ''
var buildExit: any = v:null
var buildLines: list<string> = []
var buildTail: list<string> = []
var buildDropped = 0
var buildErrorFormat = ''
var searchJob: job
var searchGeneration = 0
var searchRunning = false
var searchClosed = false
var searchExited = false
var searchQuery = ''
var searchRoot = ''
var searchExit = 0
var searchRows: list<dict<any>> = []
var searchDropped = 0
var searchErrors: list<string> = []
var searchCancelled = false
var searchOptions: dict<any> = {case: 'smart', regex: false, whole_word: false, glob: ''}
var deferredSave: dict<any> = {}
var deferredSaveTimer = -1
var deferredSaveBuffer = 0
var checkingSaveInput = false
var renderEnabled = false
var renderTimer = -1
var renderRevision = 0
var previousRender = ''
var renderProtocol = 1
var previousRenderLayout = ''
var previousRenderRows: dict<string> = {}
var renderKeyframeRevision = 0
var renderBaseKey = ''
var renderBase: list<dict<any>> = []
var renderStyles: dict<dict<any>> = {}
var renderThemeKey = ''
var renderThemeGeneration = 0
var renderThemePending = false
var renderNormal: dict<any> = {}
var cursorOption: any = v:null
var cursorShapes: dict<dict<any>> = {}

# Keep the same per-mode reset and ordered 'a:' overlay semantics as Vim's
# parse_shape_opt(). Sampling does not change the user's guicursor option.
def ParseCursorOption(value: string)
  var exclusive = false
  for part in split(value, ',')
    var halves = split(part, ':', true)
    if len(halves) != 2
      continue
    endif
    var modes = split(tolower(halves[0]), '-')
    exclusive = exclusive || index(modes, 've') >= 0
    for name in keys(cursorShapes)
      if index(modes, name) < 0 && index(modes, 'a') < 0
        continue
      endif
      var shape = cursorShapes[name]
      if index(modes, name) >= 0
        shape.shape = 'block'
        shape.percentage = 100
        shape.blinkwait = 700
        shape.blinkon = 400
        shape.blinkoff = 250
      endif
      for argument in split(halves[1], '-')
        var token = tolower(argument)
        if token ==# 'block'
          shape.shape = 'block'
          shape.percentage = 100
        elseif token =~# '^\(ver\|hor\)\d\+$'
          shape.shape = token[0 : 2] ==# 'ver' ? 'vertical' : 'horizontal'
          shape.percentage = min([100, max([1, str2nr(strpart(token, 3))])])
        elseif token =~# '^blink\(wait\|on\|off\)\d\+$'
          var field = matchstr(token, '^blink\a\+')
          shape[field] = min([2147483647, str2nr(strpart(token, strlen(field)))])
        elseif !empty(argument)
          shape.group = argument
        endif
      endfor
    endfor
  endfor
  if !exclusive
    cursorShapes.ve = copy(cursorShapes.v)
  endif
enddef

def RenderCursorAppearance(): dict<any>
  var option = exists('+guicursor') ? &guicursor : ''
  if type(cursorOption) != v:t_string || cursorOption !=# option
    if empty(cursorShapes)
      for name in ['n', 'v', 've', 'o', 'i', 'r', 'c', 'ci', 'cr', 'sm']
        cursorShapes[name] = {shape: 'block', percentage: 100, group: '',
          blinkwait: 700, blinkon: 400, blinkoff: 250}
      endfor
      ParseCursorOption(has('gui')
        ? 'n-v-c:block-Cursor/lCursor,ve:ver35-Cursor,o:hor50-Cursor,i-ci:ver25-Cursor/lCursor,r-cr:hor20-Cursor/lCursor,sm:block-Cursor-blinkwait175-blinkoff150-blinkon175'
        : 'n-v-c:block,o:hor50,i-ci:hor15,r-cr:hor30,sm:block')
    endif
    ParseCursorOption(option)
    cursorOption = option
  endif
  var current = mode(1)
  var name = current =~# '^no' ? 'o' : (current =~# '^i' ? 'i' : (current =~# '^R' ? 'r' : 'n'))
  if index(['v', 'V', "\<C-V>"], current) >= 0
    name = &selection ==# 'exclusive' ? 've' : 'v'
  endif
  var result = copy(cursorShapes[name])
  var groups = split(remove(result, 'group'), '/', true)
  var mapped = (name ==# 'i' || name ==# 'r') && &iminsert == 1
  var group = get(groups, mapped && len(groups) > 1 ? 1 : 0, '')
  var id = hlID(group)
  result.style = copy(RenderStyle(id))
  if id == 0
    result.style.reverse = true
  endif
  return result
enddef
# Each real Vim window has its own viewport and syntax context, even when
# several windows display the same buffer. Keep the expensive base paint
# cache per window; cursor/selection overlays are composed on every sample.
var renderWindowCaches: dict<dict<any>> = {}
var renderWindowSample: dict<any> = {}
var renderSamplingWindow = 0
# The active window's ordered Visual endpoints, used for closed fold rows.
var renderSamplingVisual: dict<any> = {}
var scrollAcknowledgements: dict<number> = {}
var scrollAcknowledgedRows: dict<number> = {}
var scrollMovedRows = 0
var pointerGesture: dict<any> = {}
var renderLineGeneration = ''
var renderLineCache: dict<dict<any>> = {}

def SendEncoded(encoded: string)
  if sendBatchDepth > 0
    sendBatch ..= encoded
  else
    ch_sendraw(bridge, encoded)
  endif
enddef

def Send(payload: dict<any>)
  if ch_status(bridge) !=# 'open'
    return
  endif
  sequence += 1
  payload.protocol = 1
  payload.seq = sequence
  SendEncoded(json_encode(payload) .. "\n")
enddef

# Only consumes complete objects produced by json_encode() below, before
# transport fields are added. Keep the sampled JSON for equality/size checks
# and add the numeric envelope without traversing all paint runs a second time.
def SendRenderJson(encoded: string, revision: number = 0)
  if ch_status(bridge) !=# 'open'
    return
  endif
  sequence += 1
  var suffix = revision > 0 ? ',"revision":' .. revision : ''
  SendEncoded(strpart(encoded, 0, strlen(encoded) - 1) .. suffix
    .. ',"protocol":1,"seq":' .. sequence .. "}\n")
enddef

def FlushSendBatch()
  var encoded = sendBatch
  sendBatch = ''
  if !empty(encoded) && ch_status(bridge) ==# 'open'
    ch_sendraw(bridge, encoded)
  endif
enddef

def Reply(id: number, ok: bool, error: string = '')
  Send({event: 'response', id: id, ok: ok, error: strcharpart(error, 0, 2048)})
enddef

# This is an adapter for the user's already-loaded vimrc, not an Ex/RPC
# extension point. Both directions have a closed vocabulary and bounded data.
const WORKBENCH_ACTIONS = ['simple_files', 'simple_buffers', 'simple_grep',
  'simple_doc_pin',
  'simple_outline', 'simple_rename', 'simple_code_action', 'simple_git_status',
  'simple_git_diff', 'simple_git_hunk', 'simple_markdown_preview', 'simple_keys',
  'simple_workbench', 'simple_diagnostics', 'simple_next_diagnostic',
  'simple_previous_diagnostic', 'simple_recent', 'simple_tree_toggle',
  'simple_tree_reveal', 'simple_terminal_toggle', 'simple_terminal_new',
  'simple_terminal_next', 'simple_terminal_previous', 'simple_code_lens',
  'simple_code_lens_run', 'simple_inlay_hints', 'simple_implementation',
  'simple_type_definition', 'simple_workspace_symbols', 'simple_incoming_calls',
  'simple_outgoing_calls', 'simple_supertypes', 'simple_subtypes',
  'simple_signature_help',
  'simple_git_next_hunk', 'simple_git_previous_hunk', 'simple_git_stage_hunk',
  'simple_git_undo_hunk', 'simple_git_blame', 'simple_git_blame_line', 'simple_git_history',
  'simple_plugin_status', 'simple_plugin_check', 'simple_plugin_install',
  'simple_plugin_update', 'simple_plugin_stop', 'simple_plugin_diff',
  'simple_plugin_profile', 'simple_plugin_health', 'simple_lsp_status',
  'simple_lsp_restart', 'simple_lsp_log', 'simple_tree_refresh',
  'simple_statusline_toggle', 'simple_statusline_health',
  'simple_diagnostics_errors', 'simple_next_error', 'simple_previous_error',
  'simple_refresh_diagnostics', 'simple_highlight_symbol', 'simple_clear_highlights',
  'simple_terminal_send_line', 'simple_terminal_list', 'simple_terminal_health']
const WORKBENCH_SEMANTICS = ['definition', 'hover', 'references', 'format']

def WorkbenchCapabilities(): list<string>
  var result: list<string> = []
  if !exists('*g:VimrcWorkbenchCapabilities') || !exists('*g:VimrcWorkbenchAction')
    return result
  endif
  try
    var provided: any = call('g:VimrcWorkbenchCapabilities', [])
    if type(provided) != v:t_list
      return result
    endif
    for action in provided[: 127]
      if type(action) == v:t_string
          && (index(WORKBENCH_ACTIONS, action) >= 0 || index(WORKBENCH_SEMANTICS, action) >= 0)
          && index(result, action) < 0
        add(result, action)
      endif
    endfor
  catch
    # Optional user hooks may be reloading or their plugins may be absent.
  endtry
  return result
enddef

def WorkbenchText(value: dict<any>, field: string, limit: number): string
  var item: any = get(value, field, '')
  return type(item) == v:t_string
    ? substitute(strcharpart(item, 0, limit), '[[:cntrl:]]', '', 'g') : ''
enddef

def WorkbenchCount(value: dict<any>, field: string): number
  var item: any = get(value, field, 0)
  return type(item) == v:t_number ? min([1000000, max([0, item])]) : 0
enddef

def WorkbenchBool(value: dict<any>, field: string): bool
  var item: any = get(value, field, false)
  return type(item) == v:t_bool ? item : false
enddef

def WorkbenchDict(value: dict<any>, field: string): dict<any>
  var item: any = get(value, field, {})
  return type(item) == v:t_dict ? item : {}
enddef

def WorkbenchState(): dict<any>
  if !exists('*g:VimrcWorkbenchState')
    return {}
  endif
  try
    var source = [bufnr(), win_getid(), b:changedtick]
    var provided: any = call('g:VimrcWorkbenchState', [])
    if type(provided) != v:t_dict || empty(provided)
        || source != [bufnr(), win_getid(), b:changedtick]
      return {}
    endif
    var git = WorkbenchDict(provided, 'git')
    var diagnostics = WorkbenchDict(provided, 'diagnostics')
    var remote = WorkbenchDict(provided, 'remote')
    var lsp = WorkbenchDict(provided, 'lsp')
    var plugins = WorkbenchDict(provided, 'plugins')
    var tree = WorkbenchDict(provided, 'tree')
    var statusline = WorkbenchDict(provided, 'statusline')
    # Never serialize the returned dictionary itself. A provider could carry
    # unrelated secrets, functions, channels or cyclic plugin state.
    return {buffer: bufnr(), window: win_getid(), changedtick: b:changedtick,
      provider: WorkbenchText(provided, 'provider', 64),
      root: WorkbenchText(provided, 'root', 4096),
      native: WorkbenchBool(provided, 'native'),
      large_file: WorkbenchBool(provided, 'large_file'),
      git: {head: WorkbenchText(git, 'head', 128),
        ahead: WorkbenchCount(git, 'ahead'), behind: WorkbenchCount(git, 'behind'),
        added: WorkbenchCount(git, 'added'), changed: WorkbenchCount(git, 'changed'),
        removed: WorkbenchCount(git, 'removed')},
      diagnostics: {error: WorkbenchCount(diagnostics, 'error'),
        warning: WorkbenchCount(diagnostics, 'warning'), info: WorkbenchCount(diagnostics, 'info'),
        hint: WorkbenchCount(diagnostics, 'hint')},
      remote: {connected: WorkbenchBool(remote, 'connected'),
        label: WorkbenchText(remote, 'label', 256), root: WorkbenchText(remote, 'root', 4096)},
      lsp: {available: WorkbenchBool(lsp, 'available'), status: WorkbenchText(lsp, 'status', 256)},
      plugins: {available: WorkbenchBool(plugins, 'available'), known: WorkbenchBool(plugins, 'known'),
        running: WorkbenchBool(plugins, 'running'), operation: WorkbenchText(plugins, 'operation', 64),
        total: WorkbenchCount(plugins, 'total'), completed: WorkbenchCount(plugins, 'completed'),
        installed: WorkbenchCount(plugins, 'installed'), updated: WorkbenchCount(plugins, 'updated'),
        errors: WorkbenchCount(plugins, 'errors')},
      tree: {available: WorkbenchBool(tree, 'available'), visible: WorkbenchBool(tree, 'visible'),
        root: WorkbenchText(tree, 'root', 4096)},
      statusline: {available: WorkbenchBool(statusline, 'available'), enabled: WorkbenchBool(statusline, 'enabled')}}
  catch
    return {}
  endtry
enddef

def WorkbenchLifecycle(connected: bool)
  if workbenchConnected == connected
    return
  endif
  workbenchConnected = connected
  g:jterm_vim9_connected = connected
  g:jterm_vim9_popup_cards = connected && renderProtocol >= 7
  g:jterm_vim9_render_protocol = connected ? renderProtocol : 0
  # This producer capability is independent of the wire version: older
  # protocol-6 bridges did not compose virtual text into source-free runs.
  g:jterm_vim9_virtual_text_after = connected
  g:jterm_vim9_virtual_text_inline = connected
  try
    if connected
      doautocmd <nomodeline> User JTermVim9Ready
    else
      doautocmd <nomodeline> User JTermVim9Disconnected
    endif
  catch
    # A user autocommand must not break authenticated channel processing.
  endtry
enddef

def Capabilities(): list<string>
  var result = ['open', 'save', 'save_all', 'buffer', 'build', 'cancel_build',
    'goto', 'close_buffer', 'close_current_buffer', 'next_buffer', 'previous_buffer', 'split', 'save_and_build',
    'navigate_back', 'navigate_forward', 'cancel_search',
    'snapshot', 'set_render', 'render_resync', 'scroll_view', 'pointer', 'next_diagnostic', 'previous_diagnostic', 'quit']
  if executable('rg')
    add(result, 'search')
    add(result, 'search_with_options')
  endif
  if exists('*g:VimrcCanReopenBuffer') && g:VimrcCanReopenBuffer()
    add(result, 'reopen_buffer')
  endif
  if exists(':LspGotoDefinition') == 2 || !empty(tagfiles()) || !empty(&tagfunc)
    add(result, 'definition')
  endif
  for [action, command] in items({hover: 'LspHover', references: 'LspShowReferences',
      rename: 'LspRename', format: 'LspFormat'})
    if exists(':' .. command) == 2
      add(result, action)
    endif
  endfor
  return uniq(sort(result + WorkbenchCapabilities()))
enddef

# Native buffer rendering uses Vim's buffer bytes, syntax engine and GUI
# highlight attributes. No text or color is recovered from the PTY screen.
# Unsupported display features publish an explicit fallback instead of lying
# about Vim's visible editing state. The first renderer deliberately keeps
# Vim's exact cell geometry so existing mouse/IME input remains authoritative.
def RenderColor(id: number, part: string): any
  var value = tolower(synIDattr(id, part .. '#', 'gui'))
  if value ==# 'fg' || value ==# 'foreground'
    return get(renderNormal, 'foreground', v:null)
  elseif value ==# 'bg' || value ==# 'background'
    return get(renderNormal, 'background', v:null)
  endif
  if value !~# '^#[0-9a-f]\{6}$'
    value = get(v:colornames, value, '')
  endif
  return value =~# '^#[0-9a-fA-F]\{6}$' ? str2nr(strpart(value, 1), 16) : v:null
enddef

def RenderStyle(id: number): dict<any>
  var resolved = synIDtrans(id)
  var key = string(resolved)
  if has_key(renderStyles, key)
    return renderStyles[key]
  endif
  var style: dict<any> = {foreground: RenderColor(resolved, 'fg'),
    background: RenderColor(resolved, 'bg'), special: RenderColor(resolved, 'sp')}
  for attribute in ['bold', 'italic', 'underline', 'undercurl', 'strikethrough', 'reverse']
    style[attribute] = synIDattr(resolved, attribute, 'gui') ==# '1'
  endfor
  renderStyles[key] = style
  return style
enddef

def MergeRenderStyle(base: dict<any>, overlay: dict<any>): dict<any>
  var result = copy(base)
  for name in ['foreground', 'background', 'special']
    if type(get(overlay, name, v:null)) == v:t_number
      result[name] = overlay[name]
    endif
  endfor
  for name in ['bold', 'italic', 'underline', 'undercurl', 'strikethrough', 'reverse']
    result[name] = get(base, name, false) || get(overlay, name, false)
  endfor
  return result
enddef

def RefreshRenderTheme()
  if !renderEnabled
    return
  endif
  # :highlight may run without ColorScheme. The low-rate reconciliation and
  # command-mode transitions also catch those changes, including linked groups.
  var key = string([&background, hlget(), v:colornames])
  if key !=# renderThemeKey
    renderThemeKey = key
    renderThemeGeneration += 1
    renderBaseKey = ''
    renderStyles = {}
    renderNormal = {}
    renderNormal = copy(RenderStyle(hlID('Normal')))
    if type(renderNormal.foreground) != v:t_number
      renderNormal.foreground = &background ==# 'light' ? 0x24292f : 0xd8dee9
    endif
    if type(renderNormal.background) != v:t_number
      renderNormal.background = &background ==# 'light' ? 0xffffff : 0x20242c
    endif
  endif
enddef

def NativeTextBuffer(type: string): bool
  # These buffers still own ordinary Vim text, byte positions and undo. Their
  # write/readonly/autocommand semantics remain entirely Vim's responsibility.
  return index(['', 'nofile', 'nowrite', 'acwrite'], type) >= 0
enddef

def RenderableTextBuffer(type: string): bool
  # Help and quickfix own special Enter/mouse semantics. They may publish
  # source paint, but never enter the semantic pointer/scroll input path.
  return NativeTextBuffer(type) || type ==# 'help' || type ==# 'quickfix'
enddef

def ListCharGlyphs(value: string): list<string>
  var glyphs: list<string> = []
  var offset = 0
  while offset < strlen(value)
    var tail = strpart(value, offset)
    var glyph = strcharpart(tail, 0, 1)
    var bytes = strlen(glyph)
    if glyph ==# '\'
      var kind = strpart(tail, 1, 1)
      var digits = kind ==# 'x' ? 2 : (kind ==# 'u' ? 4 : (kind ==# 'U' ? 8 : 0))
      var hex = strpart(tail, 2, digits)
      if digits == 0 || strlen(hex) != digits || hex !~# '^\x\+$'
        throw 'This listchars escape uses the compatibility view'
      endif
      var codepoint = str2nr(hex, 16)
      if codepoint > 0x10ffff || (codepoint >= 0xd800 && codepoint <= 0xdfff)
        throw 'This listchars codepoint uses the compatibility view'
      endif
      glyph = nr2char(codepoint)
      bytes = digits + 2
    endif
    if strdisplaywidth(glyph) != 1 || glyph =~# '[\x00-\x1f\x7f]'
      throw 'Native listchars requires single-cell printable glyphs'
    endif
    add(glyphs, glyph)
    offset += bytes
  endwhile
  return glyphs
enddef

def RenderListChars(): dict<list<string>>
  var result: dict<list<string>> = {}
  if !&list
    return result
  endif
  for entry in split(&listchars, ',')
    var colon = stridx(entry, ':')
    var name = strpart(entry, 0, colon)
    if colon < 0 || index(['tab', 'space', 'lead', 'trail', 'nbsp', 'eol', 'extends', 'precedes', 'conceal'], name) < 0
      throw 'This listchars field uses the compatibility view'
    endif
    var glyphs = ListCharGlyphs(strpart(entry, colon + 1))
    if (name ==# 'tab' && len(glyphs) != 2 && len(glyphs) != 3)
        || (name !=# 'tab' && len(glyphs) != 1)
      throw 'This listchars glyph sequence uses the compatibility view'
    endif
    result[name] = glyphs
  endfor
  return result
enddef

def QuickfixCurrentLine(info: dict<any>): number
  if &buftype !=# 'quickfix'
    return 0
  endif
  if !get(info, 'quickfix', 0)
    return -1
  endif
  var list = get(info, 'loclist', 0)
    ? getloclist(0, {idx: 0, qfbufnr: 0}) : getqflist({idx: 0, qfbufnr: 0})
  # A plugin may construct a lookalike special buffer or retire a list. Never
  # decorate it with another list's current entry.
  if get(list, 'qfbufnr', 0) != bufnr()
    return -1
  endif
  return get(list, 'idx', 0)
enddef

def WindowNormalGroup(): dict<any>
  if !exists('+winhighlight')
    return {supported: true, name: &wincolor}
  endif
  # New Vim versions implement wincolor using a Normal-only winhighlight
  # mapping. Read the effective mapping: wincolor itself can be stale after
  # :set winhighlight=. General highlight remapping needs a separate adapter.
  var mapping = getwinvar(0, '&winhighlight')
  if empty(mapping)
    return {supported: true, name: ''}
  endif
  var pair = split(mapping, ':', true)
  if len(pair) != 2 || index(['!(', 'Normal'], pair[0]) < 0
      || empty(pair[1]) || pair[1] =~# '[!,]'
    return {supported: false, name: ''}
  endif
  return {supported: true, name: pair[1]}
enddef

def WindowNormalStyle(): dict<any>
  var group = WindowNormalGroup()
  if empty(group.name)
    return renderNormal
  endif
  var id = synIDtrans(hlID(group.name))
  var style = RenderStyle(id)
  if style == RenderStyle(0) && synIDattr(id, 'nocombine', 'gui') !=# '1'
    return renderNormal
  endif
  # wincolor replaces Normal's attributes, while unspecified colors retain
  # the global Normal colors. Never rebind RenderColor's fg/bg references or
  # the globally cached raw syntax styles to the last sampled window.
  var result = copy(style)
  for color in ['foreground', 'background', 'special']
    if type(result[color]) != v:t_number
      result[color] = renderNormal[color]
    endif
  endfor
  return result
enddef

def VisiblePopups(): list<number>
  return filter(popup_list(), (_, id) => get(popup_getpos(id), 'visible', 0) != 0)
enddef

def RenderFallback(): string
  if !RenderableTextBuffer(&buftype)
    return 'This special Vim buffer uses the compatibility view'
  elseif mode(1) !~# '^[nivVR\x16]'
    return 'Vim command, prompt or terminal input uses the compatibility view'
  elseif (pumvisible() && renderProtocol < 5) || (renderProtocol < 6 && !empty(VisiblePopups()))
    return 'Vim completion and popup windows use the compatibility view'
  elseif &diff || &rightleft || &arabic || &spell || &conceallevel > 0
    return 'This Vim display option needs the compatibility view'
  elseif !WindowNormalGroup().supported
    return 'General Vim window highlight remapping uses the compatibility view'
  elseif get(winsaveview(), 'coladd', 0) > 0
      || (index(['v', 'V', "\<C-V>"], mode(1)) >= 0 && getpos('v')[3] > 0)
    return 'Vim virtual-space cursor and selections use the compatibility view'
  elseif &foldcolumn != 0
    return 'Vim fold columns use the compatibility view'
  elseif &hlsearch && v:hlsearch && @/ =~# '\\[_%zn]'
    return 'Multiline and positional Vim searches use the compatibility view'
  endif
  return RenderMatchFallback(getmatches())
enddef

def RenderMatchFallback(matches: list<dict<any>>): string
  if len(matches) > 64
    return 'Vim matches exceed the bounded native decoration budget'
  endif
  var positions = 0
  for decoration in matches
    if has_key(decoration, 'conceal') || synIDtrans(hlID(decoration.group)) == hlID('Conceal')
      return 'Vim conceal matches use the compatibility view'
    endif
    if has_key(decoration, 'pattern')
      # String matching has no buffer/mark/cursor context. Be conservative
      # about multiline atoms, position atoms and changed match boundaries.
      # In particular, do not interpret \%l relative to this sampled string.
      if strlen(decoration.pattern) > 4096 || decoration.pattern =~# '\\[_%zn]' || decoration.pattern =~# "[\r\n]"
        return 'Multiline and positional Vim match patterns use the compatibility view'
      endif
    else
      positions += len(filter(keys(decoration), (_, key) => key =~# '^pos\d\+$'))
      if positions > 2048
        return 'Vim match positions exceed the bounded native decoration budget'
      endif
    endif
  endfor
  return ''
enddef

# getmatches() is in ascending priority/insertion order. Like Vim, select one
# winning match rather than merging every overlapping match's attributes.
# Search has priority zero and wins ties with a priority-zero plugin match.
def RenderMatchRanges(text: string, lineNumber: number, matches: list<dict<any>>): list<dict<any>>
  var ranges: list<dict<any>> = []
  for decoration in matches
    var style = RenderStyle(hlID(decoration.group))
    if style == RenderStyle(0)
      continue
    endif
    if has_key(decoration, 'pattern')
      var offset = 0
      while offset <= strlen(text)
        # matchadd() always starts case-sensitive and magic, independent of
        # ignorecase/smartcase/magic. Explicit pattern switches still win.
        var found = matchstrpos(text, '\m\C' .. decoration.pattern, offset)
        if found[1] < 0
          break
        endif
        if found[1] == found[2]
          throw 'Zero-width Vim match patterns use the compatibility view'
        endif
        add(ranges, {start: found[1], end: found[2], priority: decoration.priority, style: style})
        offset = found[2]
        if len(ranges) > 512
          throw 'Vim matches exceed the bounded native line decoration budget'
        endif
      endwhile
    else
      for [key, position] in items(decoration)
        if key !~# '^pos\d\+$' || position[0] != lineNumber
          continue
        endif
        var start = len(position) == 1 ? 0 : position[1] - 1
        var end = len(position) == 1 ? strlen(text) : start + position[2]
        # Positional matches highlight existing text, never the empty EOL
        # cell. A byte inside a multi-byte character is not its start.
        if end > start && end > 0 && start < strlen(text)
          add(ranges, {start: start, end: end, priority: decoration.priority, style: style})
          if len(ranges) > 512
            throw 'Vim matches exceed the bounded native line decoration budget'
          endif
        endif
      endfor
    endif
  endfor
  var search: list<dict<any>> = []
  var searchStyle = RenderStyle(hlID('Search'))
  if searchStyle != RenderStyle(0)
    for span in RenderSearchRanges(text)
      add(search, {start: span[0], end: span[1], priority: 0, style: searchStyle})
    endfor
  endif
  if len(ranges) + len(search) > 512
    throw 'Vim matches exceed the bounded native line decoration budget'
  endif
  return filter(copy(ranges), (_, span) => span.priority <= 0) + search
    + filter(ranges, (_, span) => span.priority > 0)
enddef

def RenderSigns(first: number, last: number): dict<any>
  var result: dict<any> = {}
  var placed = get(sign_getplaced(bufnr(), {group: '*'}), 0, {signs: []}).signs
  for sign in placed
    if sign.lnum < first || sign.lnum > last
      continue
    endif
    var definition = get(sign_getdefined(sign.name), 0, {})
    var key = string(sign.lnum)
    if !has_key(result, key) || sign.priority > result[key].priority
      result[key] = extend(copy(definition), {priority: sign.priority})
    elseif sign.priority == result[key].priority
      # Vim combines equal-priority text and line-highlight signs.
      extend(result[key], definition, 'keep')
    endif
  endfor
  return result
enddef

def RenderSearchRanges(text: string): list<list<number>>
  var ranges: list<list<number>> = []
  if !&hlsearch || !v:hlsearch || empty(@/)
    return ranges
  endif
  # matchstrpos() uses the same Vim regex engine. Explicit \c/\C inside the
  # pattern retain their usual precedence over the search option defaults.
  var pattern = (&ignorecase && !(&smartcase && @/ =~# '\u') ? '\c' : '\C') .. @/
  var offset = 0
  while offset <= strlen(text)
    var found = matchstrpos(text, pattern, offset)
    if found[1] < 0
      break
    endif
    if found[1] == found[2]
      throw 'Zero-width Vim search highlights use the compatibility view'
    endif
    add(ranges, [found[1], max([found[1] + 1, found[2]])])
    if len(ranges) > 512
      throw 'Vim search exceeds the bounded native line decoration budget'
    endif
    offset = found[2] > found[1] ? found[2] : found[1] + 1
  endwhile
  return ranges
enddef

def AddRenderRun(runs: list<dict<any>>, glyph: dict<any>, style: dict<any>, previousPlain: bool): bool
  # ASCII shaping may be batched. A non-ASCII grapheme always keeps its own
  # Vim-owned display advance, preventing fallback fonts from moving neighbors.
  # A coalesced run must preserve a one-byte/one-cell source mapping. Expanded
  # tabs remain separate so a native hover can recover the exact buffer byte.
  # Extraction already classifies printable single-byte, non-tab glyphs.
  # Selection segments preserve that classification and the byte/cell ratio.
  # Track the previous classification separately: a one-cell fragment of an
  # expanded tab must not merge with neighboring ASCII despite its short text.
  var ascii = glyph.plain
  if !empty(runs) && ascii && previousPlain
    var previous = runs[-1]
    if previous.row == glyph.row && previous.column + previous.cells == glyph.column
        && previous.line == glyph.line && previous.byte_end == glyph.byte_start
        && previous.style == style
      previous.text ..= glyph.text
      previous.cells += glyph.cells
      previous.byte_end = glyph.byte_end
      return true
    endif
  endif
  # Materialize only wire fields. Copying every cached paint/selection field
  # and deleting it again was paid for every visible glyph on every frame.
  add(runs, {row: glyph.row, column: glyph.column, text: glyph.text,
    cells: glyph.cells, line: glyph.line, byte_start: glyph.byte_start,
    byte_end: glyph.byte_end, style: style})
  return ascii
enddef

def RenderSelectionSegments(glyph: dict<any>, visual: string, anchor: list<number>, current: list<number>, block: list<number>): list<dict<any>>
  if empty(visual) || visual ==# 'V' || !glyph.plain || glyph.cells <= 1
    return [glyph]
  endif
  var cuts = [0, glyph.cells]
  if visual ==# "\<C-V>"
    for column in block
      add(cuts, max([0, min([glyph.cells, column - glyph.virtual_column])]))
    endfor
  else
    for position in [anchor, current]
      if position[1] == glyph.line
        var column = position[2] - 1 - glyph.byte_start
        add(cuts, max([0, min([glyph.cells, column])]))
        add(cuts, max([0, min([glyph.cells, column + 1])]))
      endif
    endfor
  endif
  cuts = uniq(sort(cuts, 'n'))
  var result: list<dict<any>> = []
  for index in range(len(cuts) - 1)
    var start = cuts[index]
    var count = cuts[index + 1] - start
    if count > 0
      var part = copy(glyph)
      part.text = strpart(glyph.text, start, count)
      part.column += start
      part.virtual_column += start
      part.cells = count
      part.byte_start += start
      part.byte_end = part.byte_start + count
      add(result, part)
    endif
  endfor
  return result
enddef

# Column guides are window-local display overlays, not source-line syntax.
# Split only ASCII spans and expanded tabs; a wide/combining glyph keeps its
# atomic source range and takes the style at its first display cell, like Vim.
def RenderColumnSegments(glyph: dict<any>, columns: list<number>, leftcol: number): list<dict<any>>
  if empty(columns) || (!glyph.plain && !get(glyph, 'tab', false))
    return [glyph]
  endif
  var first = max([glyph.virtual_column, leftcol])
  var cuts = [0, glyph.cells]
  for column in columns
    if column >= first && column < first + glyph.cells
      add(cuts, column - first)
      add(cuts, column - first + 1)
    endif
  endfor
  cuts = uniq(sort(cuts, 'n'))
  if len(cuts) == 2
    return [glyph]
  endif
  var result: list<dict<any>> = []
  for index in range(len(cuts) - 1)
    var start = cuts[index]
    var count = cuts[index + 1] - start
    var part = copy(glyph)
    part.text = strpart(glyph.text, start, count)
    part.column += start
    part.virtual_column = first + start
    part.cells = count
    if glyph.plain
      part.byte_start += start
      part.byte_end = part.byte_start + count
    endif
    add(result, part)
  endfor
  return result
enddef

def RenderColorColumns(leftcol: number, width: number): list<number>
  var columns: list<number> = []
  # Vim accepts at most 256 entries, with signed entries relative to textwidth.
  for entry in split(&colorcolumn, ',')[0 : 255]
    var relative = entry =~# '^[+-]'
    if relative && &textwidth == 0
      continue
    endif
    var column = str2nr(entry) + (relative ? &textwidth : 0) - 1
    if column >= leftcol && column < leftcol + width
      add(columns, column)
    endif
  endfor
  return uniq(sort(columns, 'n'))
enddef

def RenderSelected(glyph: dict<any>, visual: string, anchor: list<number>, current: list<number>, block: list<number>): bool
  if empty(visual) || glyph.line == 0
    return false
  endif
  var lowLine = min([anchor[1], current[1]])
  var highLine = max([anchor[1], current[1]])
  if glyph.line < lowLine || glyph.line > highLine
    return false
  endif
  if visual ==# 'V'
    return true
  elseif visual ==# "\<C-V>"
    return glyph.virtual_column < block[1]
      && glyph.virtual_column + glyph.cells > block[0]
  endif
  var forward = anchor[1] < current[1] || (anchor[1] == current[1] && anchor[2] <= current[2])
  var first = forward ? anchor : current
  var last = forward ? current : anchor
  if (glyph.line == first[1] && glyph.byte_end <= first[2] - 1)
      || (glyph.line == last[1] && glyph.byte_start > last[2] - 1)
    return false
  endif
  if &selection ==# 'exclusive' && glyph.line == current[1]
      && glyph.byte_start <= current[2] - 1 && glyph.byte_end > current[2] - 1
    return false
  endif
  return true
enddef

var nativeScrollLeft = -1

var nativeScrollSkip = 0

def SampleNativeScrollLeft()
  nativeScrollLeft = winsaveview().leftcol
  nativeScrollSkip = winsaveview().skipcol
enddef

# Standard primary-pointer gestures only. Custom mappings, Select-mode and
# virtual columns remain owned by the compatibility input path.
def NativePointerAvailable(checkInline: bool = true): bool
  const current = mode(1)
  # 'block' only permits virtual space in blockwise Visual mode, which is
  # already excluded here. Normal/characterwise source targets remain exact.
  if !NativeTextBuffer(&buftype) || pumvisible() || !empty(VisiblePopups()) || index(['n', 'v'], current) < 0
      || (!empty(&virtualedit) && &virtualedit !=# 'block')
      || &selectmode =~# 'mouse' || &mouse !~# (current ==# 'n' ? '[an]' : '[av]')
    return false
  endif
  for mappingMode in ['n', 'x']
    for key in ['<LeftMouse>', '<LeftDrag>', '<LeftRelease>']
      if !empty(maparg(key, mappingMode))
        return false
      endif
    endfor
  endfor
  if checkInline
    # Property-only changes do not advance changedtick. Recheck at dispatch,
    # so a delayed native press/drag cannot bypass a newly added inline hint.
    for property in prop_list(line('w0'), {end_lnum: line('w$')})
      if property.col > 0 && has_key(property, 'text')
        return false
      endif
    endfor
  endif
  return true
enddef

def NativeScrollAvailable(): bool
  # Scrolling does not synthesize a pointer gesture. Mouse mappings, mouse=
  # and virtualedit=block must not disable direct touchpad pixels. Keep busy
  # modes and completion under Vim's compatibility input ownership.
  return NativeTextBuffer(&buftype) && index(['n', 'i'], mode(1)) >= 0
    && !pumvisible() && empty(VisiblePopups())
enddef

def NativeSourceWindow(request: dict<any>): number
  const window = PositiveNumber(request, 'window')
  const buffer = PositiveNumber(request, 'buffer')
  const tick: any = get(request, 'changedtick', -1)
  const info = getwininfo(window)
  if win_id2win(window) == 0 || empty(info) || info[0].bufnr != buffer
      || type(tick) != v:t_number || tick < 0 || getbufvar(buffer, 'changedtick') != tick
      || !NativeTextBuffer(getbufvar(buffer, '&buftype'))
    throw 'The native source window or buffer generation changed'
  endif
  return window
enddef

# Display rows between the viewport before and after a scroll, counting a
# closed fold once and every wrapped part (smoothscroll 'skipcol') once.
def MeasureScrolledRows(previousTop: number, previousSkip: number)
  var view = winsaveview()
  var width = max([1, winwidth(0) - getwininfo(win_getid())[0].textoff])
  var fromPart = &wrap ? previousSkip / width : 0
  var toPart = &wrap ? view.skipcol / width : 0
  var top = line('w0')
  scrollMovedRows = top > previousTop || (top == previousTop && toPart >= fromPart)
    ? WrapRowsBetween(previousTop, fromPart, top, toPart, width)
    : -WrapRowsBetween(top, toPart, previousTop, fromPart, width)
enddef

def ScrollSourceWindow(request: dict<any>, id: number)
  SafeToChange()
  if !NativeScrollAvailable() || SaveInputPending()
    throw 'Precision scrolling requires idle Normal or Insert mode'
  endif
  const window = NativeSourceWindow(request)
  const info = getwininfo(window)[0]
  const top = PositiveNumber(request, 'topline')
  const left: any = get(request, 'leftcol', -1)
  if info.topline != top
    throw 'The native viewport changed before scrolling'
  endif
  nativeScrollLeft = -1
  win_execute(window, 'call ' .. expand('<SID>') .. 'SampleNativeScrollLeft()')
  if type(left) != v:t_number || left < 0 || nativeScrollLeft != left
    throw 'The horizontal native viewport changed before scrolling'
  endif
  # Protocol 9 hosts name the smoothscroll row they are looking at.
  const skip: any = get(request, 'skipcol', nativeScrollSkip)
  if type(skip) != v:t_number || skip != nativeScrollSkip
    throw 'The native viewport changed before scrolling'
  endif
  const previousSkip = nativeScrollSkip
  # Batch only the validated scroll transaction. In particular, getchar(1)
  # above can run nested callbacks while a save waits for SafeState; those
  # unrelated input/save callbacks retain their existing immediate delivery.
  sendBatchDepth += 1
  try
    ScrollWindow(request)
    # Count in the scrolled split's own fold state: <C-E>/<C-Y> treat a closed
    # fold as one row, so a topline delta alone cannot confirm the movement.
    scrollMovedRows = 0
    win_execute(window, 'noautocmd call ' .. expand('<SID>') .. 'MeasureScrolledRows(' .. top .. ', ' .. previousSkip .. ')')
    scrollAcknowledgements = filter(scrollAcknowledgements, (key, _) => win_id2win(str2nr(key)) > 0)
    scrollAcknowledgedRows = filter(scrollAcknowledgedRows, (key, _) => win_id2win(str2nr(key)) > 0)
    scrollAcknowledgements[string(window)] = id
    scrollAcknowledgedRows[string(window)] = scrollMovedRows
    # Keep semantic acknowledgement before response, but in one channel write.
    # Separate small writes can wait for TCP's delayed ACK/Nagle timer and
    # stall the next source-bound request by roughly 40ms even on loopback.
    EmitRender()
    Reply(id, true)
  finally
    sendBatchDepth -= 1
    if sendBatchDepth == 0
      FlushSendBatch()
    endif
  endtry
enddef

def SourcePointer(request: dict<any>)
  const previous = pointerGesture
  pointerGesture = {}
  SafeToChange()
  if !NativePointerAvailable(false) || SaveInputPending()
    throw 'This input state or mouse mapping uses Vim compatibility input'
  endif
  const window = NativeSourceWindow(request)
  const gesture = PositiveNumber(request, 'gesture')
  const phase = RequiredString(request, 'phase', 16)
  if index(['press', 'drag', 'release'], phase) < 0
    throw 'Unknown native pointer phase'
  endif
  const lineNumber = PositiveNumber(request, 'line')
  const byte: any = get(request, 'byte_column', -1)
  const textRows = getbufline(request.buffer, lineNumber)
  if empty(textRows) || type(byte) != v:t_number || byte < 0
      || byte > strlen(textRows[0]) || byte > 16384
      || (byte < strlen(textRows[0]) && byteidxcomp(textRows[0], charidx(textRows[0], byte, true)) != byte)
    throw 'Native pointer position is not a valid source byte boundary'
  endif
  if phase !=# 'press'
    if empty(previous) || previous.gesture != gesture || previous.window != window
        || win_getid() != window || previous.buffer != bufnr() || previous.tick != b:changedtick
        || previous.mode !=# mode(1) || previous.cursor !=# getcurpos()[1 : 2]
      throw 'The native pointer gesture was interrupted; it will not be replayed'
    endif
    if !NativePointerAvailable()
      throw 'This decorated window uses Vim compatibility pointer input'
    endif
  else
    if !win_gotoid(window)
      throw 'The requested native pointer window is unavailable'
    endif
    # WinEnter/BufEnter hooks are allowed to run, but cannot redirect the click
    # to a different buffer or invalidate its captured source generation.
    NativeSourceWindow(request)
    if win_getid() != window || !NativePointerAvailable() || !empty(RenderFallback())
      throw 'The target window no longer supports this native pointer gesture'
    endif
    if mode(1) ==# 'v'
      execute "normal! \<Esc>"
    endif
  endif
  if phase !=# 'press' && mode(1) ==# 'n'
      && previous.target !=# [lineNumber, byte]
    normal! v
  endif
  cursor(lineNumber, byte + 1)
  if phase !=# 'release'
    pointerGesture = {gesture: gesture, window: window, buffer: bufnr(),
      tick: b:changedtick, mode: mode(1), cursor: getcurpos()[1 : 2], target: [lineNumber, byte]}
  endif
  Changed()
  EmitRender()
enddef

def AfterPropertyOrder(left: dict<any>, right: dict<any>): number
  var leftPriority = get(left.definition, 'priority', 0)
  var rightPriority = get(right.definition, 'priority', 0)
  # prop_list() returns newest first at equal priority; Vim draws the oldest
  # label first. Across priorities, the higher-priority label comes first.
  return leftPriority == rightPriority ? right.order - left.order
    : (leftPriority > rightPriority ? -1 : 1)
enddef

def InlinePropertyOrder(left: dict<any>, right: dict<any>): number
  return left.col == right.col ? AfterPropertyOrder(left, right) : left.col - right.col
enddef

# Inline labels advance the same display column as source characters. In
# particular a Tab after a hint uses the shifted tab stop, not its old width.
# Only public source/option/property APIs are read; no terminal grid is sampled.
def InlineTextLayout(lineNumber: number, properties: list<any>): dict<any>
  var text = getline(lineNumber)
  if strlen(text) > 16384 || strchars(text) > 4096
    return {reason: 'This long line exceeds the bounded native paint budget'}
  endif
  var column = 0
  var byte = 0
  var labels: list<any> = []
  var advances: dict<number> = {}
  for original in sort(copy(properties), InlinePropertyOrder)
    var property = copy(original)
    var start = property.col - 1
    if start < byte || start > strlen(text)
        || (start < strlen(text) && byteidx(text, charidx(text, start)) != start)
      return {reason: 'Inline Vim virtual text inside a source grapheme uses the compatibility view'}
    endif
    column += strdisplaywidth(strpart(text, byte, start - byte), column)
    property.paint_column = column
    var width = strdisplaywidth(property.text)
    column += width
    var key = string(start)
    advances[key] = get(advances, key, 0) + width
    add(labels, property)
    byte = start
  endfor
  column += strdisplaywidth(strpart(text, byte), column)
  return {labels: labels, advances: advances, width: column, reason: ''}
enddef

def RenderVirtualText(runs: list<dict<any>>, properties: list<any>, context: dict<any>): string
  var column = context.width_before + (context.eol ? 1 : 0)
  var right = context.left + context.width
  for property in (context.inline ? properties : sort(copy(properties), AfterPropertyOrder))
    column = context.inline ? property.paint_column : column + get(property, 'text_padding_left', 0)
    var text = property.text
    # Vim's wrap+truncate branch adds an ellipsis, with additional wide-glyph
    # and padding rules. Until that display branch is modeled, do not guess.
    if &wrap && column + strdisplaywidth(text) > context.width
      return 'Truncated wrapped Vim virtual text uses the compatibility view'
    endif
    var style = context.style
    var highlight = get(property.definition, 'highlight', '')
    if !empty(highlight)
      style = MergeRenderStyle(style, RenderStyle(hlID(highlight)))
    endif
    var previousPlain = false
    for index in range(strchars(text, true))
      var cluster = strcharpart(text, index, 1, true)
      var cells = strdisplaywidth(cluster)
      if cells <= 0 || cells > 2
        return 'Complex Vim virtual text uses the compatibility view'
      endif
      var finish = column + cells
      if finish > context.left && column < right
        if column < context.left || finish > right
          return 'Partially clipped Vim virtual text uses the compatibility view'
        endif
        var glyphStyle = style
        var guide = get(context.guides, string(column), {})
        if !empty(guide)
          glyphStyle = MergeRenderStyle(glyphStyle, guide)
        endif
        var plain = strlen(cluster) == 1
        var screenColumn = context.column + column - context.left
        if previousPlain && plain && runs[-1].column + runs[-1].cells == screenColumn
            && runs[-1].style == glyphStyle
          runs[-1].text ..= cluster
          runs[-1].cells += cells
        else
          add(runs, {row: context.row, column: screenColumn, text: cluster, cells: cells,
            line: 0, byte_start: 0, byte_end: 0, style: glyphStyle})
        endif
        previousPlain = plain
      else
        previousPlain = false
      endif
      column = finish
      if column >= right
        break
      endif
    endfor
    if column >= right
      break
    endif
  endfor
  return ''
enddef

# One 'fillchars' item for the sampled window, or the default. An empty
# result means the glyph cannot be painted cell-exactly.
def RenderFillChar(name: string, default: string): string
  var value = matchstr(&fillchars, '\%(^\|,\)' .. name .. ':\zs\%(\\.\|[^,]\)\+')
  if empty(value)
    return stridx(',' .. &fillchars, ',' .. name .. ':') >= 0 ? '' : default
  endif
  try
    var glyphs = ListCharGlyphs(value)
    return len(glyphs) == 1 ? glyphs[0] : ''
  catch
    return ''
  endtry
enddef

# The effective 'showbreak' of the sampled window (global-local, "NONE").
def RenderShowbreak(): string
  var local = &l:showbreak
  return local ==# 'NONE' ? '' : (empty(local) ? &g:showbreak : local)
enddef

# Screen rows of one buffer line with 'wrap', exactly like plines_win():
# virtcol() includes linebreak, breakindent, showbreak and wide-glyph padding.
def WrapLineParts(lineNumber: number, width: number): number
  var cells = virtcol([lineNumber, '$']) - 1
  if &list && stridx(&listchars, 'eol:') >= 0
    cells += 1
  endif
  return cells <= width ? 1 : (cells - 1) / width + 1
enddef

# Display rows from (fromLine, fromPart) forward to (toLine, toPart) in the
# current window, counting a closed fold once and each wrapped part once.
def WrapRowsBetween(fromLine: number, fromPart: number, toLine: number, toPart: number, width: number): number
  if fromLine == toLine
    return toPart - fromPart
  endif
  var count = -fromPart
  var lineNumber = fromLine
  while lineNumber < toLine
    var foldEnd = foldclosedend(lineNumber)
    if foldEnd > 0
      count += 1
      lineNumber = foldEnd + 1
    else
      count += &wrap ? WrapLineParts(lineNumber, width) : 1
      lineNumber += 1
    endif
  endwhile
  return count + toPart
enddef

# Remove painted ink from screen cells [from, to) of one row before an overlay
# such as smoothscroll's "<<<" or 'display' "@@@" covers them. One-byte-per-cell
# ASCII runs are sliced; a wide glyph losing one half leaves a space in the
# other half, like Vim. Background-only runs keep their full extent.
def ClearRunCells(runs: list<dict<any>>, row: number, from: number, to: number)
  var index = 0
  while index < len(runs)
    var run = runs[index]
    var start = run.column
    var finish = run.column + run.cells
    if run.row != row || finish <= from || start >= to || run.text =~# '^ *$'
      index += 1
      continue
    endif
    var pieces: list<dict<any>> = []
    var sliced = strlen(run.text) == run.cells && run.text =~# '^[\x20-\x7e]*$'
    for [pieceStart, pieceEnd] in [[start, min([from, finish])], [max([to, start]), finish]]
      if pieceEnd <= pieceStart
        continue
      endif
      var piece = copy(run)
      piece.column = pieceStart
      piece.cells = pieceEnd - pieceStart
      if sliced
        piece.text = strpart(run.text, pieceStart - start, pieceEnd - pieceStart)
        if run.line > 0 && run.byte_end - run.byte_start == run.cells
          piece.byte_start = run.byte_start + pieceStart - start
          piece.byte_end = piece.byte_start + piece.cells
        endif
      else
        piece.text = repeat(' ', piece.cells)
        piece.line = 0
        piece.byte_start = 0
        piece.byte_end = 0
      endif
      add(pieces, piece)
    endfor
    remove(runs, index)
    for piece in pieces
      insert(runs, piece, index)
      index += 1
    endfor
  endwhile
enddef

# Base glyphs of one buffer line that wraps onto several screen rows. Each
# glyph records its continuation row ('part') and its column in that row.
# Without 'linebreak', 'breakindent' or 'showbreak' the virtual columns are
# computed here; otherwise Vim's own virtcol() supplies every glyph's span,
# including linebreak padding. 'heads' are the cells before the first glyph
# of a continuation row (breakindent and showbreak); 'fillers' are the '>'
# cells left by a wide glyph that did not fit at a row end.
def WrapLineGlyphs(lineNumber: number, text: string, context: dict<any>): dict<any>
  var width: number = context.width
  var oracle: bool = context.oracle
  var lineProperties: list<any> = context.properties
  var matchRanges: list<dict<any>> = context.matches
  var glyphs: list<dict<any>> = []
  var heads: dict<number> = {}
  var fillers: list<list<number>> = []
  var result = {glyphs: glyphs, heads: heads, fillers: fillers, parts: 1, reason: ''}
  var byteColumn = 0
  var virtualColumn = 0
  var lastEnd = 0
  var asciiLine = strlen(text) == strchars(text)
  for charIndex in range(strchars(text, true))
    var cluster = asciiLine ? strpart(text, charIndex, 1) : strcharpart(text, charIndex, 1, true)
    var tab = cluster ==# "\t"
    # With 'wrap', strdisplaywidth(text, col) already counts the '>' cell of a
    # wide glyph at the row end; the row transition below adds it once.
    var cells = strlen(cluster) == 1 && !tab ? 1
      : (tab ? strdisplaywidth(cluster, virtualColumn) : strdisplaywidth(cluster))
    if cells <= 0 || cells > 2 && !tab
      result.reason = 'A zero-width or complex wrapped Vim glyph uses the compatibility view'
      return result
    endif
    var nextByte = byteColumn + strlen(cluster)
    var vstart = virtualColumn
    var vcells = cells
    if oracle
      var span = virtcol([lineNumber, byteColumn + 1], 1)
      if cells == 2 && !tab && lastEnd % width == width - 1
        # For a wide glyph pushed past the '>' filler, virtcol() leaves the
        # next row's showbreak/breakindent out of its start; its end is exact.
        vstart = span[1] - 2
        vcells = 2
      else
        vstart = span[0] - 1
        vcells = span[1] - span[0] + 1
      endif
    elseif cells == 2 && vstart % width == width - 1
      vstart += 1
    endif
    if vstart < lastEnd || (vcells < cells && !tab)
      result.reason = 'This wrapped Vim layout uses the compatibility view'
      return result
    endif
    # The first glyph starts row 0 at column 0; each later glyph continues
    # the previous one's row or starts the next row. Only the wide-glyph '>'
    # filler may leave a gap at a row end; breakindent/showbreak padding
    # ('head') precedes the first glyph of a continuation row.
    var part = vstart / width
    var padded = false
    if lastEnd == 0
      padded = vstart != 0
    else
      var previousRow = (lastEnd - 1) / width
      if part == previousRow
        padded = vstart != lastEnd
      elseif part == previousRow + 1
        var gap = (previousRow + 1) * width - lastEnd
        if gap == 1 && cells == 2
          add(fillers, [previousRow, width - 1])
        else
          padded = gap != 0
        endif
        heads[string(part)] = vstart - part * width
      else
        padded = true
      endif
    endif
    if padded
      result.reason = 'This wrapped Vim row padding uses the compatibility view'
      return result
    endif
    var style = RenderStyle(synID(lineNumber, byteColumn + 1, true))
    var propertyStyle: dict<any> = {}
    var propertyPriority = -2147483648
    var propertyOverride = false
    var propertyCombine = true
    for property in lineProperties
      var definition = property.definition
      var priority = get(definition, 'priority', 0)
      if byteColumn < property.col - 1 + property.length && nextByte > property.col - 1
          && priority > propertyPriority && !empty(get(definition, 'highlight', ''))
        propertyStyle = RenderStyle(hlID(definition.highlight))
        propertyPriority = priority
        propertyOverride = !!get(definition, 'override', false)
        propertyCombine = !!get(definition, 'combine', true)
      endif
    endfor
    if !empty(propertyStyle)
      style = propertyCombine ? MergeRenderStyle(style, propertyStyle) : copy(propertyStyle)
    endif
    var matchStyle: dict<any> = {}
    for matchRange in matchRanges
      if byteColumn >= matchRange.start && byteColumn < matchRange.end
        matchStyle = matchRange.style
      endif
    endfor
    var override = propertyOverride ? propertyStyle : {}
    var spacer = tab || vcells > cells
    var plain = strlen(cluster) == 1 && !spacer
    # A tab or a linebreak-padded blank may continue on the next row; with
    # breakindent/showbreak padding that split position is not observable.
    var segmentStart = vstart
    var remaining = vcells
    while remaining > 0
      var column = segmentStart % width
      var segment = min([remaining, width - column])
      if segment < remaining && (!spacer || !empty(context.showbreak) || context.breakindent)
        result.reason = 'This wrapped Vim glyph crosses a padded row and uses the compatibility view'
        return result
      endif
      var segmentPart = segmentStart / width
      var previous = empty(glyphs) ? {} : glyphs[-1]
      if plain && !empty(previous) && previous.plain && previous.part == segmentPart
          && previous.byte_end == byteColumn && previous.style == style
          && previous.offset + previous.cells == column
          && previous.override_style == override && previous.match_style == matchStyle
        previous.text ..= cluster
        previous.cells += 1
        previous.byte_end = nextByte
      else
        add(glyphs, {row: 0, part: segmentPart, offset: column, column: 0,
          text: spacer ? repeat(' ', segment) : cluster, cells: segment, line: lineNumber,
          byte_start: byteColumn, byte_end: nextByte, virtual_column: segmentStart,
          plain: plain, tab: spacer, list_style: {}, style: style,
          override_style: override, match_style: matchStyle})
      endif
      segmentStart += segment
      remaining -= segment
    endwhile
    lastEnd = vstart + vcells
    virtualColumn = lastEnd
    byteColumn = nextByte
  endfor
  result.parts = lastEnd <= width ? 1 : (lastEnd - 1) / width + 1
  return result
enddef

# fillchars 'fold:' item for the sampled window ('-' by default). An empty
# result means the glyph cannot be painted cell-exactly.
def RenderFoldFill(): string
  var value = matchstr(&fillchars, '\%(^\|,\)fold:\zs\%(\\.\|[^,]\)\+')
  if empty(value)
    return stridx(',' .. &fillchars, ',fold:') >= 0 ? '' : '-'
  endif
  try
    var glyphs = ListCharGlyphs(value)
    return len(glyphs) == 1 ? glyphs[0] : ''
  catch
    return ''
  endtry
enddef

# Vim's own relative numbering counts a closed fold as one row (see
# get_cursor_rel_lnum()). Count display rows starting in [from, to).
def DisplayRowsBetween(from: number, to: number): number
  var count = 0
  var lineNumber = from
  while lineNumber < to
    count += 1
    var foldEnd = foldclosedend(lineNumber)
    lineNumber = foldEnd > 0 ? foldEnd + 1 : lineNumber + 1
  endwhile
  return count
enddef

# One closed fold row, composed as Vim's fold_line() draws it: Folded over the
# whole width, two blank sign cells, the fold-start (or relative) number, the
# 'foldtext' result truncated before a glyph that would not fit, and the
# fillchars fold glyph to the window edge. Visual replaces the text style when
# the whole fold is selected; ColorColumn and CursorColumn then combine with
# it. Fold glyphs are display-only and never advertise buffer source bytes.
def RenderFoldRow(runs: list<dict<any>>, context: dict<any>): string
  var view = context.view
  var folded = context.folded
  var gutter = ''
  if context.sign_width > 0
    gutter ..= repeat(' ', min([2, view.columns]))
  endif
  if context.number
    var label = context.number_label
    gutter ..= strpart(label, 0, max([0, view.columns - strlen(gutter)]))
  endif
  var textColumn = strlen(gutter)
  if textColumn > 0
    add(runs, {row: context.row, column: view.column, text: gutter, cells: textColumn,
      line: 0, byte_start: 0, byte_end: 0, style: folded})
  endif
  var text = foldtextresult(context.line)
  if text =~# '[\x00-\x08\x0a-\x1f\x7f\u0590-\u08ff\u200b-\u200f\u202a-\u202e\u2066-\u2069\ufeff]'
    return 'Control and bidirectional fold text uses the compatibility view'
  elseif strlen(text) > 4096
    return 'This fold text exceeds the bounded native paint budget'
  endif
  var fill = RenderFoldFill()
  if empty(fill)
    return 'This fillchars fold glyph uses the compatibility view'
  endif
  var base = context.selected ? context.visual : folded
  # Window-relative cells that combine an extra guide style, in Vim's order.
  var guides: dict<dict<any>> = {}
  for column in context.color_columns
    var cell = textColumn + column - context.leftcol
    if cell >= textColumn && cell < view.columns
      guides[string(cell)] = MergeRenderStyle(base, context.color_style)
    endif
  endfor
  if context.cursor_column >= 0
    var cell = textColumn + context.cursor_column - context.leftcol
    if cell >= textColumn && cell < view.columns
      guides[string(cell)] = MergeRenderStyle(get(guides, string(cell), base), context.cursor_style)
    endif
  endif
  var column = textColumn
  var previousPlain = false
  for index in range(strchars(text, true))
    var cluster = strcharpart(text, index, 1, true)
    var cells = strdisplaywidth(cluster)
    if cells <= 0 || cells > 2
      return 'Complex fold text uses the compatibility view'
    elseif column + cells > view.columns
      break
    endif
    var style = get(guides, string(column), base)
    var plain = strlen(cluster) == 1
    if plain && previousPlain && runs[-1].style == style && !has_key(guides, string(column))
        && !has_key(guides, string(runs[-1].column - view.column + runs[-1].cells - 1))
      runs[-1].text ..= cluster
      runs[-1].cells += 1
    else
      add(runs, {row: context.row, column: view.column + column, text: cluster, cells: cells,
        line: 0, byte_start: 0, byte_end: 0, style: style})
    endif
    previousPlain = plain
    column += cells
  endfor
  # A filler run of one repeated single-cell glyph is stretched to exactly its
  # cells by every native painter; only guide cells interrupt it.
  while column < view.columns
    var finish = column + 1
    if !has_key(guides, string(column))
      while finish < view.columns && !has_key(guides, string(finish))
        finish += 1
      endwhile
    endif
    add(runs, {row: context.row, column: view.column + column, text: repeat(fill, finish - column),
      cells: finish - column, line: 0, byte_start: 0, byte_end: 0,
      style: get(guides, string(column), base)})
    column = finish
  endwhile
  return ''
enddef

# Gutter and padding glyphs of a wrapped line's sampled screen rows, drawn
# as Vim's win_line() does: continuation rows show a blank sign column and a
# blank number column (CursorLineNr only with cursorlineopt "line"/"both"),
# 'showbreak' in the breakindent/showbreak head, and '>' where a wide glyph
# did not fit. Smoothscroll's first row keeps the sign, and shows the line
# number only with 'number' + 'relativenumber', its leading blanks as "-".
# showbreak cells are NonText; Vim draws column guides on them too. A wrapped
# row spans exactly one text width of virtual columns.
def GuideCellStyle(context: dict<any>, part: number, column: number): dict<any>
  var guides: dict<any> = get(context, 'guides', {})
  var guide = empty(guides) ? {} : get(guides,
    string(part * context.width + column - context.view.column - context.textoff), {})
  return empty(guide) ? context.cursor_line : MergeRenderStyle(context.cursor_line, guide)
enddef

def RenderContinuationRows(runs: list<dict<any>>, context: dict<any>): string
  var layout = context.layout
  if empty(layout) || !get(layout, 'wrapped', false)
    return 'This wrapped Vim line layout uses the compatibility view'
  endif
  var view = context.view
  var sampled = context.sampled
  var showbreak: string = context.showbreak
  var showbreakCells = strdisplaywidth(showbreak)
  for part in range(sampled[0], sampled[1])
    var row = context.row + part
    # The topline's first visible row; its hidden parts may be margin rows.
    var skipRow = part > 0 && part == context.skip_part
    if part > 0
      if context.sign_width > 0
        add(runs, {row: row, column: view.column,
          text: skipRow ? context.sign_label : repeat(' ', context.sign_width), cells: context.sign_width,
          line: 0, byte_start: 0, byte_end: 0,
          style: skipRow ? context.sign_style : context.sign_column_style})
      endif
      if context.numbers
        var label = repeat(' ', context.number_width)
        if skipRow && &number && &relativenumber
          label = substitute(context.number_label, '^ \+', '\=repeat("-", strlen(submatch(0)))', '')
        endif
        add(runs, {row: row, column: view.column + max([0, context.sign_width]),
          text: label, cells: strdisplaywidth(label), line: 0, byte_start: 0, byte_end: 0,
          style: skipRow ? context.number_style : context.continued_number_style})
      endif
      if !empty(showbreak)
        var head = get(layout.heads, string(part), -1)
        if head < showbreakCells
          return 'This wrapped Vim showbreak layout uses the compatibility view'
        endif
        var column = view.column + context.textoff + (context.showbreak_first ? 0 : head - showbreakCells)
        for index in range(strchars(showbreak, true))
          var glyph = strcharpart(showbreak, index, 1, true)
          var cells = strdisplaywidth(glyph)
          add(runs, {row: row, column: column, text: glyph, cells: cells,
            line: 0, byte_start: 0, byte_end: 0, style: GuideCellStyle(context, part, column)})
          column += cells
        endfor
      endif
    endif
    for filler in layout.fillers
      if filler[0] == part
        # Vim writes the filler with its own NonText attribute after guides
        # were combined (multi_attr in win_line()), so no guide shows there.
        add(runs, {row: row, column: view.column + context.textoff + filler[1], text: '>', cells: 1,
          line: 0, byte_start: 0, byte_end: 0, style: context.cursor_line})
      endif
    endfor
  endfor
  return ''
enddef

def RenderWindowFrame(margin: number = 0): dict<any>
  var windowNormal = WindowNormalStyle()
  var listChars = RenderListChars()
  var info = getwininfo(win_getid())[0]
  var view = {row: info.winrow - 1, column: info.wincol - 1,
    rows: info.height, columns: info.width}
  # Keep a statically typed local for the append hot path. Passing frame.runs
  # (dict<any> lookup) into AddRenderRun makes Vim recursively infer/check the
  # growing list on every glyph, even when its parameter is list<any>.
  var paintRuns: list<dict<any>> = []
  var frame: dict<any> = {event: 'render', supported: true, fallback_reason: '',
    rows: &lines, columns: &columns, window: win_getid(), buffer: bufnr(),
    changedtick: b:changedtick, mode: mode(1), view: view,
    default_style: renderNormal, cursor: {row: 0, column: 0, width: 1, visible: false},
    runs: paintRuns, completion: v:null, popups: []}
  var reason = RenderFallback()
  var quickfixLine = QuickfixCurrentLine(info)
  if quickfixLine < 0 || quickfixLine > line('$')
    reason = 'This quickfix window has no authoritative list identity'
  endif
  if !empty(reason)
    frame.supported = false
    frame.fallback_reason = reason
    return frame
  endif
  var savedView = winsaveview()
  var first = line('w0')
  var last = line('w$')
  var textWidth = view.columns - info.textoff
  if textWidth < 1
    frame.supported = false
    frame.fallback_reason = 'This Vim window has no visible text columns'
    return frame
  endif
  # Every sampled display row is [line, part, parts]. A closed fold is one
  # row [start, 0, 1]; render protocol 9 also paints 'wrap' continuation rows,
  # one per screen line a buffer line occupies. Hidden lines inside a fold are
  # never sampled, styled or published.
  var wrapRows = &wrap && renderProtocol >= 9
  var skipPart = 0
  if wrapRows && &cpoptions =~# 'n'
    frame.supported = false
    frame.fallback_reason = 'The cpoptions n flag uses the compatibility view'
    return frame
  elseif wrapRows && savedView.skipcol > 0
    if savedView.skipcol % textWidth != 0
      frame.supported = false
      frame.fallback_reason = 'This smoothscroll offset uses the compatibility view'
      return frame
    endif
    skipPart = savedView.skipcol / textWidth
  endif
  var foldEnds: dict<number> = {}
  var lineParts: dict<number> = {}
  var visibleEntries: list<list<number>> = []
  # How an unfinished last line is shown, following 'display'.
  var bottom = ''
  var rowLine = first
  var rowPart = skipPart
  while rowLine <= line('$') && len(visibleEntries) < view.rows && (wrapRows || rowLine <= last)
    var rowKey = string(rowLine)
    var foldEnd = foldclosedend(rowLine)
    if foldEnd > 0
      foldEnds[rowKey] = foldEnd
      add(visibleEntries, [rowLine, 0, 1])
      rowLine = foldEnd + 1
      rowPart = 0
      continue
    endif
    var parts = wrapRows ? WrapLineParts(rowLine, textWidth) : 1
    lineParts[rowKey] = parts
    if rowPart >= parts
      frame.supported = false
      frame.fallback_reason = 'This smoothscroll offset uses the compatibility view'
      return frame
    endif
    if len(visibleEntries) + parts - rowPart > view.rows
      bottom = &display =~# 'truncate' ? 'truncate' : (&display =~# 'lastline' ? 'lastline' : 'hidden')
      if bottom ==# 'hidden'
        if rowLine == first
          frame.supported = false
          frame.fallback_reason = 'A wrapped line taller than its Vim window uses the compatibility view'
          return frame
        endif
        break
      endif
    endif
    while rowPart < parts && len(visibleEntries) < view.rows
      add(visibleEntries, [rowLine, rowPart, parts])
      rowPart += 1
    endwhile
    if rowPart < parts
      break
    endif
    rowLine += 1
    rowPart = 0
  endwhile
  if !empty(foldEnds) && (renderProtocol < 8 || foldclosed(first) != first && foldclosed(first) > 0)
    frame.supported = false
    frame.fallback_reason = 'Closed Vim folds use the compatibility view'
    return frame
  endif
  # 'display' truncate replaces the whole last row with "@@@": no text there.
  var truncatedEntry: list<number> = []
  if bottom ==# 'truncate'
    truncatedEntry = remove(visibleEntries, -1)
  endif
  if empty(visibleEntries)
    frame.supported = false
    frame.fallback_reason = 'This Vim window is too small for native paint'
    return frame
  endif
  var lastEntry = visibleEntries[-1]
  last = get(foldEnds, string(lastEntry[0]), lastEntry[0])
  frame.topline = first
  frame.botline = last
  frame.leftcol = savedView.leftcol
  frame.textoff = info.textoff
  frame.line_count = line('$')
  frame.overscan = []
  # The bounded property scan below supplies inline pointer ownership.
  frame.native_pointer = renderProtocol >= 3 && NativePointerAvailable(false)
  frame.native_scroll = renderProtocol >= 3 && NativeScrollAvailable()
  frame.scroll_ack = get(scrollAcknowledgements, string(win_getid()), 0)
  frame.line_lengths = map(copy(visibleEntries), (_, entry) => strlen(getline(entry[0])))
  var aboveEntries: list<list<number>> = []
  var belowEntries: list<list<number>> = []
  if margin > 0
    # Margins are display rows too: the topline's parts hidden by
    # smoothscroll come first above it, a closed fold contributes one row and
    # a wrapped line one row per part.
    var upLine = first
    var upPart = skipPart - 1
    while len(aboveEntries) < margin
      if upPart < 0
        upLine -= 1
        if upLine < 1
          break
        endif
        var start = foldclosed(upLine)
        if start > 0
          foldEnds[string(start)] = foldclosedend(upLine)
          insert(aboveEntries, [start, 0, 1])
          upLine = start
          continue
        endif
        lineParts[string(upLine)] = wrapRows ? WrapLineParts(upLine, textWidth) : 1
        upPart = lineParts[string(upLine)] - 1
      endif
      insert(aboveEntries, [upLine, upPart, lineParts[string(upLine)]])
      upPart -= 1
    endwhile
    # Below continues exactly after the last row that shows buffer text.
    # Rows replaced by 'display' "@" lines are not contiguous text.
    var downLine = empty(truncatedEntry) ? rowLine : truncatedEntry[0]
    var downPart = empty(truncatedEntry) ? rowPart : truncatedEntry[1]
    while bottom !=# 'hidden' && bottom !=# 'truncate' && downLine <= line('$') && len(belowEntries) < margin
      var downKey = string(downLine)
      var foldEnd = downPart == 0 ? foldclosedend(downLine) : -1
      if foldEnd > 0
        foldEnds[downKey] = foldEnd
        add(belowEntries, [downLine, 0, 1])
        downLine = foldEnd + 1
        continue
      endif
      if !has_key(lineParts, downKey)
        lineParts[downKey] = wrapRows ? WrapLineParts(downLine, textWidth) : 1
      endif
      add(belowEntries, [downLine, downPart, lineParts[downKey]])
      downPart += 1
      if downPart >= lineParts[downKey]
        downLine += 1
        downPart = 0
      endif
    endwhile
    if !empty(foldEnds) && renderProtocol < 8
      frame.supported = false
      frame.fallback_reason = 'Closed Vim folds use the compatibility view'
      return frame
    endif
  endif
  var displayEntries = aboveEntries + visibleEntries + belowEntries
  var topIndex = len(aboveEntries)
  # A line's row is the index of its part 0, which may lie outside the sample
  # when smoothscroll or a margin edge cuts the line.
  var rowOffset: dict<number> = {}
  var sampledParts: dict<list<number>> = {}
  var displayRows: list<number> = []
  var wrapped = false
  for index in range(len(displayEntries))
    var entry = displayEntries[index]
    var entryKey = string(entry[0])
    if !has_key(rowOffset, entryKey)
      rowOffset[entryKey] = index - entry[1]
      sampledParts[entryKey] = [entry[1], entry[1]]
      add(displayRows, entry[0])
    else
      sampledParts[entryKey][1] = entry[1]
    endif
    wrapped = wrapped || entry[2] > 1
  endfor
  first = displayRows[0]
  last = get(foldEnds, string(displayRows[-1]), displayRows[-1])
  var textRows = empty(foldEnds) ? displayRows
    : filter(copy(displayRows), (_, lineNumber) => !has_key(foldEnds, string(lineNumber)))
  if !empty(foldEnds) || wrapped
    # Protocol 8/9 row map; source-bound scrolling counts display rows.
    # Continuation rows carry exact source bytes, so the native pointer keeps
    # working there. A closed fold row is display-only: clicks in a folded
    # split stay with Vim, which opens folds and maps hidden lines.
    frame.display_lines = map(copy(visibleEntries), (_, entry) => entry[0])
    frame.fold_ends = map(copy(visibleEntries), (_, entry) => get(foldEnds, string(entry[0]), 0))
    if wrapped
      frame.wrap_parts = map(copy(visibleEntries), (_, entry) => entry[1])
      frame.wrap_rows = map(copy(visibleEntries), (_, entry) => entry[2])
      # Without smoothscroll <C-E> moves whole lines, not the requested rows.
      if !&smoothscroll
        frame.native_scroll = false
      endif
    endif
    if !empty(foldEnds)
      frame.native_pointer = false
    endif
  endif
  if renderProtocol >= 9
    frame.skipcol = savedView.skipcol
  endif
  if view.rows > 200 || view.columns > 400 || len(displayEntries) - 1 > 200 + 2 * margin
    frame.supported = false
    frame.fallback_reason = 'This viewport exceeds the bounded native paint budget'
    return frame
  endif
  var numberWidth = (&number || &relativenumber)
    ? max([&numberwidth, strlen(string(line('$'))) + 1]) : 0
  var signWidth = info.textoff - numberWidth
  var signs = RenderSigns(first, last)
  if !empty(foldEnds)
    # Vim draws neither signs nor sign highlights on a closed fold row, and
    # hidden lines inside a fold cannot affect the visible sign geometry.
    filter(signs, (key, _) => has_key(rowOffset, key) && !has_key(foldEnds, key))
  endif
  if !empty(signs) && (signWidth > 2 || signWidth < 0)
    frame.supported = false
    frame.fallback_reason = 'Multiple Vim sign columns use the compatibility view'
    return frame
  endif
  for sign in values(signs)
    var signText = get(sign, 'text', '')
    if !empty(get(sign, 'icon', '')) || strdisplaywidth(signText) > 2
        || signText =~# '[\x00-\x1f\x7f]'
      frame.supported = false
      frame.fallback_reason = 'This image or complex Vim sign uses the compatibility view'
      return frame
    endif
  endfor
  # Opening/closing a fold does not change b:changedtick. The display-row map
  # above is rebuilt on every paint attempt, independently of the caches.
  var allProperties: list<dict<any>> = []
  if empty(foldEnds)
    allProperties = prop_list(first, {end_lnum: last})
  else
    # Fold rows show only their fold text. Query contiguous visible source
    # segments so diagnostics inside a large closed fold cost nothing.
    var segmentStart = -1
    var segmentEnd = -1
    for lineNumber in textRows
      if segmentStart > 0 && lineNumber == segmentEnd + 1
        segmentEnd = lineNumber
        continue
      endif
      if segmentStart > 0
        extend(allProperties, prop_list(segmentStart, {end_lnum: segmentEnd}))
      endif
      segmentStart = lineNumber
      segmentEnd = lineNumber
    endfor
    if segmentStart > 0
      extend(allProperties, prop_list(segmentStart, {end_lnum: segmentEnd}))
    endif
  endif
  var properties: list<dict<any>> = []
  # Index once per frame; scanning the whole property list for every source
  # row makes dense diagnostics cost O(visible_rows * properties). Definitions
  # are frame-local so prop_type_change()/deletion still invalidate immediately.
  var propertyLines: dict<list<any>> = {}
  var propertyDefinitions: dict<dict<any>> = {}
  var afterLines: dict<list<any>> = {}
  var inlineLines: dict<list<any>> = {}
  var inlineLayouts: dict<dict<any>> = {}
  var virtualCounts: dict<number> = {}
  var afterBytes = 0
  var matches = getmatches()
  if len(allProperties) > 2048
    frame.supported = false
    frame.fallback_reason = 'This property list exceeds the bounded native paint budget'
    return frame
  endif
  for property in allProperties
    var propertyType = get(property, 'type', '')
    var typeBuffer = get(property, 'type_bufnr', 0)
    var definitionKey = string([typeBuffer, propertyType])
    if !has_key(propertyDefinitions, definitionKey)
      propertyDefinitions[definitionKey] = empty(propertyType) ? {}
        : (typeBuffer > 0 ? prop_type_get(propertyType, {bufnr: typeBuffer}) : prop_type_get(propertyType))
    endif
    property.definition = propertyDefinitions[definitionKey]
    if has_key(property, 'text')
      var text = property.text
      var padding = get(property, 'text_padding_left', 0)
      afterBytes += strlen(text)
      if property.col < 0 || get(property, 'text_align', 'after') !=# 'after'
          || get(property, 'text_wrap', 'truncate') !=# 'truncate'
        reason = 'Aligned or wrapping Vim virtual text uses the compatibility view'
      elseif property.col > 0 && &wrap
        reason = 'Inline Vim virtual text with wrap uses the compatibility view'
      elseif index(['v', 'V', "\<C-V>"], mode(1)) >= 0
        reason = 'Visual selections with Vim virtual text use the compatibility view'
      elseif empty(property.definition) || strlen(text) > 4096 || strchars(text) > 1024
          || padding < 0 || padding > 400 || afterBytes > 32768
        reason = 'Vim virtual text exceeds the bounded native paint budget'
      elseif text =~# '[\x00-\x1f\x7f\u0590-\u08ff\u200b-\u200f\u202a-\u202e\u2066-\u2069\ufeff]'
        reason = 'Control and bidirectional Vim virtual text uses the compatibility view'
      else
        var key = string(property.lnum)
        var lines = property.col > 0 ? inlineLines : afterLines
        if !has_key(lines, key)
          lines[key] = []
        endif
        property.order = len(lines[key])
        add(lines[key], property)
        virtualCounts[key] = get(virtualCounts, key, 0) + 1
        if virtualCounts[key] > 128
          reason = 'This line exceeds the native virtual text paint budget'
        endif
      endif
    elseif property.col <= 0
      reason = 'This Vim property uses the compatibility view'
    else
      add(properties, property)
      var key = string(property.lnum)
      if !has_key(propertyLines, key)
        propertyLines[key] = []
      endif
      add(propertyLines[key], property)
    endif
    if !empty(reason)
      frame.supported = false
      frame.fallback_reason = reason
      return frame
    endif
  endfor
  for [key, labels] in items(inlineLines)
    var layout = InlineTextLayout(str2nr(key), labels)
    if !empty(layout.reason)
      frame.supported = false
      frame.fallback_reason = layout.reason
      return frame
    endif
    inlineLayouts[key] = layout
  endfor
  # A display-only hint is not an editable source range. Until a separate
  # hint-hit contract exists, Vim owns pointer clicks in this window. Source
  # scrolling is still exact: every visible/margin row retains its real line.
  if !empty(inlineLayouts)
    frame.native_pointer = false
  endif
  # A scroll changes screen rows, not the semantic paint of every surviving
  # buffer line. A buffer edit still invalidates all lines: syntax regions can
  # propagate arbitrarily far beyond the edited line.
  var generation = string([bufnr(), b:changedtick, savedView.leftcol,
    view.column, view.columns, info.textoff, &tabstop, &vartabstop, &wrap, &syntax, &synmaxcol,
    &number, &relativenumber, &numberwidth, &ambiwidth, &list, &listchars, renderThemeGeneration, windowNormal,
    &hlsearch, v:hlsearch, @/, &ignorecase, &smartcase, &magic, &iskeyword, &isprint, matches,
    wrapRows ? [&linebreak, &breakindent, &breakindentopt, RenderShowbreak(), &breakat, &display] : 0])
  if generation !=# renderLineGeneration
    renderLineGeneration = generation
    renderLineCache = {}
  endif
  # Folding changes which source lines own rows without changing any text.
  var baseKey = string([generation, first, last, view, properties, inlineLines, foldEnds])
  if baseKey !=# renderBaseKey
    renderBase = []
    var nextLines: dict<dict<any>> = {}
    var noListStyle: dict<any> = {}
    var wrapContext = {width: textWidth, oracle: &linebreak || &breakindent || !empty(RenderShowbreak()),
      showbreak: RenderShowbreak(), breakindent: &breakindent}
    for lineNumber in textRows
      var text = getline(lineNumber)
      var lineKeyName = string(lineNumber)
      var row = view.row + rowOffset[lineKeyName]
      var wrapLine = get(lineParts, lineKeyName, 1) > 1
      var partRange = sampledParts[lineKeyName]
      var lineProperties = get(propertyLines, string(lineNumber), [])
      var inlineLayout = get(inlineLayouts, string(lineNumber), {})
      var inlineAdvances: dict<number> = get(inlineLayout, 'advances', {})
      var displayWidth = get(inlineLayout, 'width', strdisplaywidth(text))
      var lineKey = string([text, lineProperties, get(inlineLines, string(lineNumber), [])])
      var cached = get(renderLineCache, string(lineNumber), {})
      if !empty(cached) && cached.key ==# lineKey
        # Cached glyphs are owned by this window's line cache and are only
        # read when wire runs are materialized, so a scroll retargets their
        # row in place instead of deep-copying every surviving glyph.
        if get(cached, 'wrapped', false)
          for stored in cached.base
            stored.row = row + stored.part
          endfor
          extend(renderBase, partRange[0] == 0 && partRange[1] == cached.parts - 1 ? cached.base
            : filter(copy(cached.base), (_, glyph) => glyph.part >= partRange[0] && glyph.part <= partRange[1]))
        else
          if !empty(cached.base) && cached.base[0].row != row
            for stored in cached.base
              stored.row = row
            endfor
          endif
          extend(renderBase, cached.base)
        endif
        nextLines[string(lineNumber)] = cached
        continue
      endif
      if wrapLine
        # Continuation rows of one buffer line. Their geometry is cached with
        # the line; rows are assigned from the line's current position.
        if &list
          reason = 'Wrapped Vim lines with list use the compatibility view'
          break
        elseif has_key(inlineLines, lineKeyName) || has_key(afterLines, lineKeyName)
          reason = 'Virtual text on wrapped Vim lines uses the compatibility view'
          break
        elseif strlen(text) > 16384 || strchars(text) > 4096
          reason = 'This long line exceeds the bounded native paint budget'
          break
        elseif text =~# '[\x00-\x08\x0a-\x1f\x7f\u0590-\u08ff\u200b-\u200f\u202a-\u202e\u2066-\u2069\ufeff]'
          reason = 'Control and bidirectional text use the compatibility view'
          break
        elseif len(lineProperties) > 128
          reason = 'This line exceeds the native property paint budget'
          break
        endif
        var layout = WrapLineGlyphs(lineNumber, text, extend({properties: lineProperties,
          matches: RenderMatchRanges(text, lineNumber, matches)}, wrapContext))
        if !empty(layout.reason)
          reason = layout.reason
          break
        elseif layout.parts != lineParts[lineKeyName]
          reason = 'This wrapped Vim line layout uses the compatibility view'
          break
        endif
        for glyph in layout.glyphs
          glyph.row = row + glyph.part
          glyph.column = view.column + info.textoff + glyph.offset
          var paintStyle = MergeRenderStyle(windowNormal, glyph.style)
          if !empty(glyph.match_style)
            paintStyle = MergeRenderStyle(paintStyle, glyph.match_style)
          endif
          if !empty(glyph.override_style)
            paintStyle = MergeRenderStyle(paintStyle, glyph.override_style)
          endif
          glyph.paint_style = paintStyle
        endfor
        var wrappedEntry = {key: lineKey, base: layout.glyphs, wrapped: true, parts: layout.parts,
          heads: layout.heads, fillers: layout.fillers}
        extend(renderBase, partRange[0] == 0 && partRange[1] == layout.parts - 1 ? layout.glyphs
          : filter(copy(layout.glyphs), (_, glyph) => glyph.part >= partRange[0] && glyph.part <= partRange[1]))
        nextLines[lineKeyName] = wrappedEntry
        continue
      endif
      if strlen(text) > 16384 || strchars(text) > 4096
        reason = 'This long line exceeds the bounded native paint budget'
        break
      elseif &wrap && displayWidth > textWidth
        reason = 'Wrapped Vim continuation rows use the compatibility view'
        break
      elseif &list && &wrap && has_key(listChars, 'eol') && displayWidth >= textWidth
        reason = 'A wrapped listchars EOL marker uses the compatibility view'
        break
      elseif &list && stridx(text, "\t") >= 0 && !has_key(listChars, 'tab')
        reason = 'Default ^I listchars tab geometry uses the compatibility view'
        break
      elseif &list && ((has_key(listChars, 'precedes') && savedView.leftcol > 0 && displayWidth > savedView.leftcol)
          || (has_key(listChars, 'extends') && !&wrap && displayWidth > savedView.leftcol + textWidth))
        reason = 'This active listchars horizontal-edge marker uses the compatibility view'
        break
      elseif text =~# '[\x00-\x08\x0a-\x1f\x7f\u0590-\u08ff\u200b-\u200f\u202a-\u202e\u2066-\u2069\ufeff]'
        reason = 'Control and bidirectional text use the compatibility view'
        break
      endif
      var matchRanges = RenderMatchRanges(text, lineNumber, matches)
      if len(lineProperties) > 128
        reason = 'This line exceeds the native property paint budget'
        break
      endif
      var runStart = len(renderBase)
      var byteColumn = 0
      var virtualColumn = 0
      var asciiLine = strlen(text) == strchars(text)
      var leadEnd = &list ? match(text, '[^ \t]') : 0
      var trailStart = &list ? match(text, '[ \t]*$') : strlen(text)
      if leadEnd < 0
        leadEnd = strlen(text)
      endif
      for charIndex in range(strchars(text, true))
        if !empty(inlineAdvances)
          virtualColumn += get(inlineAdvances, string(byteColumn), 0)
        endif
        var cluster = asciiLine ? strpart(text, charIndex, 1) : strcharpart(text, charIndex, 1, true)
        var plain = strlen(cluster) == 1 && cluster !=# "\t"
        var cells = plain ? 1 : strdisplaywidth(cluster, virtualColumn)
        var display = cluster
        var listStyle = noListStyle
        var listedTab = &list && cluster ==# "\t"
        if &list && cluster ==# ' '
          var field = byteColumn >= trailStart && has_key(listChars, 'trail') ? 'trail'
            : (byteColumn < leadEnd && has_key(listChars, 'lead') ? 'lead' : 'space')
          if has_key(listChars, field)
            display = listChars[field][0]
            listStyle = RenderStyle(hlID('SpecialKey'))
            plain = false
          endif
        elseif &list && (cluster ==# "\u00a0" || cluster ==# "\u202f") && has_key(listChars, 'nbsp')
          if cells != 1
            reason = 'This nonbreaking-space listchars width uses the compatibility view'
            break
          endif
          display = listChars.nbsp[0]
          listStyle = RenderStyle(hlID('SpecialKey'))
          plain = false
        elseif listedTab
          listStyle = RenderStyle(hlID('SpecialKey'))
        endif
        var nextByte = byteColumn + strlen(cluster)
        var start = virtualColumn - savedView.leftcol
        var finish = start + cells
        if finish > 0 && start < textWidth
          if cells <= 0 || ((start < 0 || finish > textWidth) && cluster !=# "\t")
            reason = 'A clipped or zero-width Vim glyph uses the compatibility view'
            break
          endif
          var visibleStart = max([0, start])
          var visibleEnd = min([textWidth, finish])
          var style = RenderStyle(synID(lineNumber, byteColumn + 1, true))
          var propertyStyle: dict<any> = {}
          var propertyPriority = -2147483648
          var propertyOverride = false
          var propertyCombine = true
          for property in lineProperties
            var definition = property.definition
            var priority = get(definition, 'priority', 0)
            if byteColumn < property.col - 1 + property.length && nextByte > property.col - 1
                && priority > propertyPriority && !empty(get(definition, 'highlight', ''))
              propertyStyle = RenderStyle(hlID(definition.highlight))
              propertyPriority = priority
              propertyOverride = !!get(definition, 'override', false)
              propertyCombine = !!get(definition, 'combine', true)
            endif
          endfor
          if !empty(propertyStyle)
            style = propertyCombine ? MergeRenderStyle(style, propertyStyle) : copy(propertyStyle)
          endif
          var matchStyle: dict<any> = {}
          for matchRange in matchRanges
            if byteColumn >= matchRange.start && byteColumn < matchRange.end
              matchStyle = matchRange.style
            endif
          endfor
          var previous = empty(renderBase) ? {} : renderBase[-1]
          if plain && !empty(previous) && previous.plain && previous.row == row
              && previous.byte_end == byteColumn && previous.style == style
              && previous.column + previous.cells == view.column + info.textoff + visibleStart
              && previous.override_style == (propertyOverride ? propertyStyle : {})
              && previous.match_style == matchStyle
            previous.text ..= cluster
            previous.cells += 1
            previous.byte_end = nextByte
          elseif listedTab
            # One explicit glyph per display cell keeps Unicode marker bytes
            # out of ASCII selection/column slicing. Every cell still names
            # the same original one-byte Tab, never the replacement text.
            var markers = listChars.tab
            for visibleColumn in range(visibleStart, visibleEnd - 1)
              var cell = visibleColumn - start
              var marker = len(markers) == 3 && cell == cells - 1 ? markers[2]
                : (cell == 0 ? markers[0] : markers[1])
              add(renderBase, {row: row, column: view.column + info.textoff + visibleColumn,
                text: marker, cells: 1, line: lineNumber, byte_start: byteColumn, byte_end: nextByte,
                virtual_column: virtualColumn + cell, plain: false, tab: true, list_style: listStyle,
                style: style, override_style: propertyOverride ? propertyStyle : {}, match_style: matchStyle})
            endfor
          else
            add(renderBase, {row: row, column: view.column + info.textoff + visibleStart,
              text: cluster ==# "\t" ? repeat(' ', visibleEnd - visibleStart) : display,
              cells: visibleEnd - visibleStart, line: lineNumber,
              byte_start: byteColumn, byte_end: nextByte,
              virtual_column: virtualColumn, plain: plain, tab: cluster ==# "\t",
              style: style, list_style: listStyle, override_style: propertyOverride ? propertyStyle : {}, match_style: matchStyle})
          endif
        endif
        byteColumn = nextByte
        virtualColumn += cells
        if virtualColumn >= savedView.leftcol + textWidth
          break
        endif
      endfor
      if !empty(reason)
        break
      endif
      var lineBase = runStart < len(renderBase) ? renderBase[runStart :] : []
      # Default/syntax/property/match composition is source-line data, not
      # viewport data. Surviving lines reuse it while cursor/Visual overlays
      # are composed from current Vim state below.
      for glyph in lineBase
        var paintStyle = MergeRenderStyle(windowNormal, glyph.style)
        if &list && !empty(glyph.list_style) && empty(glyph.match_style)
          paintStyle = MergeRenderStyle(paintStyle, glyph.list_style)
        endif
        if !empty(glyph.match_style)
          paintStyle = MergeRenderStyle(paintStyle, glyph.match_style)
        endif
        if !empty(glyph.override_style)
          paintStyle = MergeRenderStyle(paintStyle, glyph.override_style)
        endif
        glyph.paint_style = paintStyle
      endfor
      nextLines[string(lineNumber)] = {key: lineKey, base: lineBase}
    endfor
    if empty(reason)
      renderBaseKey = baseKey
      # Keep only the visible lines. Scrolling one row reuses every surviving
      # row without accumulating a second copy of a large Vim document.
      renderLineCache = nextLines
    endif
  endif
  if !empty(reason)
    renderBaseKey = ''
    frame.supported = false
    frame.fallback_reason = reason
    return frame
  endif
  if windowNormal != renderNormal
    # This existing run shape carries per-window Normal without a protocol
    # extension. It covers gutters and blank/EOF cells before their own groups
    # and source glyphs, and never advertises a fabricated buffer position.
    var lastBackground = max([view.row + len(displayEntries) - 1,
      view.row + view.rows + topIndex - 1])
    for row in range(view.row, lastBackground)
      add(paintRuns, {row: row, column: view.column, cells: view.columns,
        text: '', line: 0, byte_start: 0, byte_end: 0, style: windowNormal})
    endfor
  endif
  var visual = mode(1)
  if index(['v', 'V', "\<C-V>"], visual) < 0
    visual = ''
  endif
  var anchor = getpos('v')
  var current = getpos('.')
  var block = [0, 0]
  if visual ==# "\<C-V>"
    var a = virtcol('v', true)
    var c = virtcol('.', true)
    block = [min([a[0], c[0]]) - 1, max([a[1], c[1]])]
    if &selection ==# 'exclusive' && c[0] > a[0]
      block[1] = c[0] - 1
    endif
  endif
  var visualStyle = RenderStyle(hlID('Visual'))
  var cursorLineStyle = RenderStyle(hlID('CursorLine'))
  var position = screenpos(win_getid(), line('.'), col('.'))
  # virtcol('.') reports the last cell of a wide character. CursorColumn
  # follows Vim's actual cursor cell: first for wide text, last for a Normal
  # mode tab, and first for an Insert mode tab. Reuse the cursor paint oracle.
  var cursorColumn = &cursorcolumn
    ? (get(position, 'curscol', 0) > 0
      ? position.curscol - 1 - view.column - info.textoff + savedView.leftcol
      : virtcol('.', true)[0] - 1) : -1
  # With 'wrap' every screen row of a line spans exactly textWidth virtual
  # columns (showbreak/breakindent cells and linebreak padding included), so
  # a guide's virtual column names its continuation row and cell.
  var guideLimit = &wrap ? 1048576 : textWidth
  if &wrap && cursorColumn >= 0 && get(position, 'curscol', 0) > 0
      && has_key(rowOffset, string(line('.')))
    cursorColumn += (position.row - 1 - view.row + topIndex - rowOffset[string(line('.'))]) * textWidth
  endif
  var colorColumns = empty(&colorcolumn) ? [] : RenderColorColumns(savedView.leftcol, guideLimit)
  var guideEnabled = !empty(colorColumns)
    || (cursorColumn >= savedView.leftcol && cursorColumn < savedView.leftcol + guideLimit)
  # With both guides disabled, retain the ordinary single paint loop: no
  # per-line guide dictionaries and no per-glyph guide segmentation calls.
  var colorStyle = RenderStyle(hlID('ColorColumn'))
  var cursorGuideStyle = RenderStyle(hlID('CursorColumn'))
  var guideRows: dict<dict<any>> = {}
  var rowStyles: dict<dict<any>> = {}
  # Shared per frame: the color guides, and guide paint over plain Normal.
  var colorGuides: dict<any> = {}
  for column in colorColumns
    colorGuides[string(column)] = colorStyle
  endfor
  var plainGuideStyles = {color: MergeRenderStyle(windowNormal, colorStyle),
    cursor: MergeRenderStyle(windowNormal, cursorGuideStyle)}
  if wrapped
    # Blockwise selections address virtual columns that continue across a
    # line's screen rows; screenline highlights one of those rows.
    if visual ==# "\<C-V>"
      reason = 'Block selections on wrapped Vim lines use the compatibility view'
    elseif &cursorline && &cursorlineopt =~# 'screenline' && get(lineParts, string(line('.')), 1) > 1
      reason = 'A screenline cursorline on a wrapped Vim line uses the compatibility view'
    endif
    if !empty(reason)
      frame.supported = false
      frame.fallback_reason = reason
      frame.runs = []
      return frame
    endif
  endif
  for lineNumber in textRows
    var sign = get(signs, string(lineNumber), {})
    var lineStyle: dict<any> = {}
    if !empty(get(sign, 'linehl', ''))
      lineStyle = RenderStyle(hlID(sign.linehl))
    endif
    var currentQuickfix = quickfixLine > 0 && lineNumber == quickfixLine
    if currentQuickfix
      # Vim applies the current quickfix item independently of its cursor or
      # changedtick. It replaces sign linehl before CursorLine composition.
      lineStyle = RenderStyle(hlID('QuickFixLine'))
    endif
    var lineCursor = &cursorline && lineNumber == line('.') && &cursorlineopt !=# 'number'
    if lineCursor
      var lineWins = !empty(get(sign, 'linehl', '')) ? get(sign, 'priority', 0) >= 100 : currentQuickfix
      lineStyle = lineWins
        ? MergeRenderStyle(cursorLineStyle, lineStyle) : MergeRenderStyle(lineStyle, cursorLineStyle)
    endif
    if !empty(lineStyle)
      rowStyles[string(lineNumber)] = lineStyle
      # A whole-window Normal backdrop is identified by line=0/empty text.
      # QuickFixLine is one source row, not a new Normal for the entire pane.
      # Every sampled screen row of a wrapped line carries the line style.
      var sampled = sampledParts[string(lineNumber)]
      for part in range(sampled[0], sampled[1])
        add(frame.runs, {row: view.row + rowOffset[string(lineNumber)] + part, column: view.column + info.textoff,
          cells: textWidth, text: repeat(' ', textWidth), line: lineNumber,
          byte_start: 0, byte_end: 0, style: MergeRenderStyle(windowNormal, lineStyle)})
      endfor
    endif
    if guideEnabled
      var guides: dict<any> = copy(colorGuides)
      if cursorColumn >= savedView.leftcol && cursorColumn < savedView.leftcol + guideLimit
          && lineNumber != current[1]
        guides[string(cursorColumn)] = cursorGuideStyle
      endif
      guideRows[string(lineNumber)] = {styles: guides, columns: map(keys(guides), (_, column) => str2nr(column))}
      # Source-free runs paint guides beyond EOL. A one-column pane uses a
      # space to avoid the empty-text/full-width Normal backdrop signature.
      # A wrapped line shows a guide on the sampled row holding its column.
      var guideKey = string(lineNumber)
      var guideParts = get(lineParts, guideKey, 1)
      var guideSampled = get(sampledParts, guideKey, [0, 0])
      for [column, guideStyle] in items(guides)
        var offset = str2nr(column) - savedView.leftcol
        var part = offset / textWidth
        if part >= guideParts || part < guideSampled[0] || part > guideSampled[1]
          continue
        endif
        add(frame.runs, {row: view.row + rowOffset[guideKey] + part,
          column: view.column + info.textoff + offset % textWidth,
          text: view.columns == 1 ? ' ' : '', cells: 1, line: 0, byte_start: 0, byte_end: 0,
          style: !empty(lineStyle) ? MergeRenderStyle(MergeRenderStyle(windowNormal, lineStyle), guideStyle)
            : plainGuideStyles[guideStyle is cursorGuideStyle ? 'cursor' : 'color']})
      endfor
    endif
  endfor
  var previousPlain = false
  # Glyphs arrive grouped by line; resolve each line's guides once.
  var guideLine = -1
  var guideColumns: list<number> = []
  var guideStyles: dict<any> = {}
  for baseGlyph in renderBase
    if visual ==# "\<C-V>" && strpart(getline(baseGlyph.line), baseGlyph.byte_start, baseGlyph.byte_end - baseGlyph.byte_start) ==# "\t"
      frame.supported = false
      frame.fallback_reason = 'Block selections through Vim tabs use the compatibility view'
      frame.runs = []
      return frame
    endif
    var glyphs = empty(visual) ? [baseGlyph] : RenderSelectionSegments(baseGlyph, visual, anchor, current, block)
    var paintGuide = guideEnabled && empty(baseGlyph.match_style)
      && (empty(visual) || baseGlyph.line < min([anchor[1], current[1]])
        || baseGlyph.line > max([anchor[1], current[1]]))
    if paintGuide
      # Most glyphs touch no guide column: skip segmentation and lookups.
      if baseGlyph.line != guideLine
        guideLine = baseGlyph.line
        var guideRow = guideRows[string(guideLine)]
        guideColumns = guideRow.columns
        guideStyles = guideRow.styles
      endif
      var columns = guideColumns
      var guideFirst = max([baseGlyph.virtual_column, savedView.leftcol])
      paintGuide = false
      for column in columns
        if column >= guideFirst && column < guideFirst + baseGlyph.cells
          paintGuide = true
          break
        endif
      endfor
      if paintGuide
        var pieces: list<dict<any>> = []
        for selected in glyphs
          extend(pieces, RenderColumnSegments(selected, columns, savedView.leftcol))
        endfor
        glyphs = pieces
      endif
    endif
    for glyph in glyphs
      var style = glyph.paint_style
      var selectedCell = !empty(visual) && RenderSelected(glyph, visual, anchor, current, block)
      if !empty(visual) || has_key(rowStyles, string(glyph.line))
        style = MergeRenderStyle(windowNormal, glyph.style)
        if has_key(rowStyles, string(glyph.line))
          style = MergeRenderStyle(style, rowStyles[string(glyph.line)])
        endif
        if &list && !empty(glyph.list_style) && empty(glyph.match_style) && !selectedCell
          style = MergeRenderStyle(style, glyph.list_style)
        endif
        if !empty(glyph.match_style)
          style = MergeRenderStyle(style, glyph.match_style)
        endif
        if selectedCell
          style = MergeRenderStyle(style, visualStyle)
        endif
        if !empty(glyph.override_style)
          style = MergeRenderStyle(style, glyph.override_style)
        endif
      endif
      if paintGuide
        var guide = get(guideStyles, string(max([glyph.virtual_column, savedView.leftcol])), {})
        if !empty(guide)
          style = MergeRenderStyle(style, guide)
        endif
      endif
      previousPlain = AddRenderRun(paintRuns, glyph, style, previousPlain)
    endfor
  endfor
  if has_key(listChars, 'eol')
    for lineNumber in textRows
      var column = get(get(inlineLayouts, string(lineNumber), {}), 'width', strdisplaywidth(getline(lineNumber))) - savedView.leftcol
      if column >= 0 && column < textWidth
        var style = MergeRenderStyle(windowNormal, get(rowStyles, string(lineNumber), {}))
        style = MergeRenderStyle(style, RenderStyle(hlID('NonText')))
        var visualLine = !empty(visual) && lineNumber >= min([anchor[1], current[1]])
          && lineNumber <= max([anchor[1], current[1]])
        if guideEnabled && !visualLine
          var guide = get(guideRows[string(lineNumber)].styles, string(column + savedView.leftcol), {})
          if !empty(guide)
            style = MergeRenderStyle(style, guide)
          endif
        endif
        add(paintRuns, {row: view.row + rowOffset[string(lineNumber)],
          column: view.column + info.textoff + column, text: listChars.eol[0], cells: 1,
          line: 0, byte_start: 0, byte_end: 0, style: style})
      endif
    endfor
  endif
  # Vim selects one display cell for the newline, including an empty buffer
  # line. Painting only existing glyphs would silently erase that selection.
  if visual ==# 'V' || visual ==# 'v'
    var lowLine = min([anchor[1], current[1]])
    var highLine = max([anchor[1], current[1]])
    for lineNumber in filter(copy(textRows), (_, l) => l >= lowLine && l <= highLine)
      var text = getline(lineNumber)
      var endColumn = strdisplaywidth(text) - savedView.leftcol
      var endRow = view.row + rowOffset[string(lineNumber)]
      if get(lineParts, string(lineNumber), 1) > 1
        # The newline cell follows the last glyph on the line's last row; a
        # line that exactly fills its rows has no room for it, like Vim.
        var endVcol = virtcol([lineNumber, '$']) - 1
        var endPart = endVcol / textWidth
        var sampled = sampledParts[string(lineNumber)]
        endColumn = endPart < lineParts[string(lineNumber)] && endPart >= sampled[0] && endPart <= sampled[1]
          ? endVcol % textWidth : -1
        endRow += endPart
      endif
      if endColumn >= 0 && endColumn < textWidth
          && (visual ==# 'V' || lineNumber < highLine
            || (!has_key(listChars, 'eol') && max([anchor[2], current[2]]) > strlen(text)))
        var endStyle = MergeRenderStyle(windowNormal, visualStyle)
        add(frame.runs, {row: endRow,
          column: view.column + info.textoff + endColumn,
          text: has_key(listChars, 'eol') ? listChars.eol[0] : ' ', cells: 1, line: has_key(listChars, 'eol') ? 0 : lineNumber,
          byte_start: strlen(text), byte_end: strlen(text), style: endStyle})
      endif
    endfor
  endif
  for inline in [false, true]
    var lines = inline ? inlineLines : afterLines
    for [key, labels] in items(lines)
      var lineNumber = str2nr(key)
      var layout = get(inlineLayouts, key, {})
      var context = {line: lineNumber, row: view.row + rowOffset[key],
        column: view.column + info.textoff, width: textWidth, left: savedView.leftcol,
        width_before: get(layout, 'width', strdisplaywidth(getline(lineNumber))),
        inline: inline, eol: has_key(listChars, 'eol'),
        style: MergeRenderStyle(windowNormal, get(rowStyles, key, {})),
        guides: get(get(guideRows, key, {}), 'styles', {})}
      reason = RenderVirtualText(paintRuns, inline ? layout.labels : labels, context)
      if !empty(reason)
        frame.supported = false
        frame.fallback_reason = reason
        frame.runs = []
        return frame
      endif
    endfor
  endfor
  var cursorRowLine = foldclosed(line('.')) > 0 ? foldclosed(line('.')) : line('.')
  # Relative numbers count buffer lines with each closed fold once; a wrapped
  # line keeps one number however many screen rows it occupies.
  var lineIndex: dict<number> = {}
  for index in range(len(displayRows))
    lineIndex[string(displayRows[index])] = index
  endfor
  var cursorIndex = get(lineIndex, string(cursorRowLine), -1)
  # 'cursorlineopt' decides where CursorLineNr and CursorLineSign apply.
  var culFlags = split(&cursorlineopt, ',')
  var culNumber = &cursorline && (index(culFlags, 'both') >= 0 || index(culFlags, 'number') >= 0)
  var culAllRows = index(culFlags, 'both') >= 0 || index(culFlags, 'line') >= 0
  var nonTextStyle = MergeRenderStyle(windowNormal, RenderStyle(hlID('NonText')))
  var showbreak = RenderShowbreak()
  var foldContext: dict<any> = {}
  if !empty(foldEnds)
    # Like ordinary rows, only the active split paints the live selection.
    var sampling = renderSamplingVisual
    var selection = !empty(sampling) && win_getid() == renderSamplingWindow
      && sampling.buffer == bufnr()
    if selection && sampling.mode ==# "\<C-V>"
      frame.supported = false
      frame.fallback_reason = 'Block selections over closed Vim folds use the compatibility view'
      frame.runs = []
      return frame
    endif
    foldContext = {view: view, sign_width: signWidth, number: &number || &relativenumber,
      folded: MergeRenderStyle(windowNormal, RenderStyle(hlID('Folded'))),
      visual: MergeRenderStyle(windowNormal, visualStyle), leftcol: savedView.leftcol,
      color_columns: colorColumns, color_style: colorStyle,
      cursor_column: &cursorcolumn ? cursorColumn : -1, cursor_style: cursorGuideStyle,
      selection: selection ? sampling : {}}
  endif
  for lineNumber in displayRows
    var rowKey = string(lineNumber)
    var row = view.row + rowOffset[rowKey]
    # Vim's relative numbers count display rows, so a closed fold between the
    # cursor and this row counts once (get_cursor_rel_lnum()).
    var relative = 0
    if &relativenumber
      if cursorIndex >= 0
        relative = abs(lineIndex[rowKey] - cursorIndex)
      elseif cursorRowLine < first
        relative = DisplayRowsBetween(cursorRowLine, first) + lineIndex[rowKey]
      else
        relative = len(displayRows) - lineIndex[rowKey] + DisplayRowsBetween(last + 1, cursorRowLine)
      endif
    endif
    var numberValue = &relativenumber && (relative != 0 || !&number) ? relative : lineNumber
    # 'number' + 'relativenumber' left-aligns the absolute cursor row number.
    var numberLabel = printf(&number && &relativenumber && relative == 0 ? '%-*d ' : '%*d ',
      max([1, numberWidth - 1]), &number && !&relativenumber ? lineNumber : numberValue)
    if has_key(foldEnds, rowKey)
      var foldEnd = foldEnds[rowKey]
      var selected = false
      var selection = foldContext.selection
      if !empty(selection)
        var low = selection.low
        var high = selection.high
        selected = lineNumber >= low[1] && foldEnd <= high[1]
          && (selection.mode !=# 'v'
            || ((lineNumber > low[1] || low[2] == 1)
              && (foldEnd < high[1] || high[2] - 1 - (&selection ==# 'exclusive' ? 1 : 0) >= strlen(getline(foldEnd)))))
      endif
      reason = RenderFoldRow(paintRuns, extend({row: row, line: lineNumber, number_label: numberLabel,
        selected: selected}, foldContext))
      if !empty(reason)
        frame.supported = false
        frame.fallback_reason = reason
        frame.runs = []
        return frame
      endif
      continue
    endif
    var sign = get(signs, rowKey, {})
    var signText = get(sign, 'text', '')
    var cursorRow = lineNumber == line('.')
    var signHighlight = culNumber && cursorRow && !empty(get(sign, 'culhl', ''))
      ? sign.culhl : get(sign, 'texthl', '')
    var signGroup = culNumber && cursorRow ? 'CursorLineSign' : 'SignColumn'
    # Vim uses CursorLineNr only with 'cursorline' and a number cursorlineopt;
    # LineNrAbove/LineNrBelow replace LineNr when 'relativenumber' is set.
    var numberGroup = culNumber && cursorRow ? 'CursorLineNr' : 'LineNr'
    if &relativenumber && !cursorRow
      var relativeGroup = lineNumber < line('.') ? 'LineNrAbove' : 'LineNrBelow'
      if !empty(RenderStyle(hlID(relativeGroup)))
        numberGroup = relativeGroup
      endif
    endif
    if signWidth > 0
      var columnStyle = MergeRenderStyle(windowNormal, RenderStyle(hlID(signGroup)))
      var label = signText .. repeat(' ', max([0, signWidth - strdisplaywidth(signText)]))
      add(frame.runs, {row: row, column: view.column,
        text: label, cells: signWidth, line: 0, byte_start: 0, byte_end: 0,
        style: empty(signHighlight) ? columnStyle : MergeRenderStyle(columnStyle, RenderStyle(hlID(signHighlight)))})
    endif
    if &number || &relativenumber
      var label = numberLabel
      var style = MergeRenderStyle(windowNormal, RenderStyle(hlID(numberGroup)))
      if !empty(get(sign, 'numhl', ''))
        style = MergeRenderStyle(style, RenderStyle(hlID(sign.numhl)))
      endif
      if &signcolumn ==# 'number' && !empty(signText)
        label = repeat(' ', max([0, numberWidth - strdisplaywidth(signText) - 1])) .. signText .. ' '
        if !empty(signHighlight)
          style = MergeRenderStyle(style, RenderStyle(hlID(signHighlight)))
        endif
      endif
      add(frame.runs, {row: row, column: view.column + max([0, signWidth]),
        text: label, cells: strdisplaywidth(label), line: 0, byte_start: 0, byte_end: 0,
        style: style})
    endif
    if get(lineParts, rowKey, 1) > 1
      reason = RenderContinuationRows(paintRuns, {line: lineNumber, row: row,
        sampled: sampledParts[rowKey], layout: get(renderLineCache, rowKey, {}),
        skip_part: lineNumber == frame.topline ? skipPart : 0, view: view, textoff: info.textoff,
        sign_width: signWidth, number_width: numberWidth, numbers: &number || &relativenumber,
        sign_label: signText .. repeat(' ', max([0, signWidth - strdisplaywidth(signText)])),
        sign_style: MergeRenderStyle(MergeRenderStyle(windowNormal, RenderStyle(hlID(signGroup))),
          empty(signHighlight) ? {} : RenderStyle(hlID(signHighlight))),
        sign_column_style: MergeRenderStyle(windowNormal, RenderStyle(hlID(signGroup))),
        number_label: numberLabel, number_style: MergeRenderStyle(MergeRenderStyle(windowNormal,
          RenderStyle(hlID(numberGroup))), empty(get(sign, 'numhl', '')) ? {} : RenderStyle(hlID(sign.numhl))),
        continued_number_style: MergeRenderStyle(MergeRenderStyle(windowNormal, RenderStyle(hlID(
          numberGroup ==# 'CursorLineNr' && !culAllRows ? 'LineNr' : numberGroup))),
          empty(get(sign, 'numhl', '')) ? {} : RenderStyle(hlID(sign.numhl))),
        showbreak: showbreak, showbreak_first: &breakindentopt =~# 'sbr',
        non_text: nonTextStyle, cursor_line: &cursorline && cursorRow && &cursorlineopt !=# 'number'
          ? MergeRenderStyle(nonTextStyle, cursorLineStyle) : nonTextStyle,
        width: textWidth, guides: !guideEnabled || (!empty(visual)
            && lineNumber >= min([anchor[1], current[1]]) && lineNumber <= max([anchor[1], current[1]]))
          ? {} : guideRows[rowKey].styles})
      if !empty(reason)
        frame.supported = false
        frame.fallback_reason = reason
        frame.runs = []
        return frame
      endif
    endif
  endfor
  # Smoothscroll's first row: "<<<" covers three cells from the window edge
  # (after a leading line number with 'number' + 'relativenumber') unless
  # 'showbreak' or listchars "precedes" already marks the continuation.
  if skipPart > 0 && empty(showbreak) && !(&list && has_key(listChars, 'precedes'))
    var overlayRow = view.row + topIndex
    var skip = 0
    if &number && &relativenumber && signWidth == 0
      var topLine: number = frame.topline
      var skipLabel = substitute(printf('%-*d ', max([1, numberWidth - 1]), topLine), '^ \+', '\=repeat("-", strlen(submatch(0)))', '')
      if cursorRowLine != topLine
        skipLabel = substitute(printf('%*d ', max([1, numberWidth - 1]), abs(get(lineIndex, string(topLine), 0) - cursorIndex)),
          '^ \+', '\=repeat("-", strlen(submatch(0)))', '')
      endif
      skip = strlen(matchstr(skipLabel, '^\d\+'))
    endif
    var cells = min([3, view.columns - skip])
    if cells > 0
      ClearRunCells(paintRuns, overlayRow, view.column + skip, view.column + skip + cells)
      add(paintRuns, {row: overlayRow, column: view.column + skip, text: repeat('<', cells), cells: cells,
        line: 0, byte_start: 0, byte_end: 0, style: nonTextStyle})
    endif
  endif
  # 'display' lastline marks an unfinished last line with "@@@" at the end of
  # the last row; truncate replaces that row; neither shows "@" rows instead.
  var lastlineGlyph = RenderFillChar('lastline', '@')
  var eobGlyph = RenderFillChar('eob', '~')
  if empty(lastlineGlyph) || empty(eobGlyph)
    frame.supported = false
    frame.fallback_reason = 'This fillchars glyph uses the compatibility view'
    frame.runs = []
    return frame
  endif
  if bottom ==# 'lastline'
    var overlayRow = view.row + topIndex + view.rows - 1
    var cells = min([3, view.columns])
    ClearRunCells(paintRuns, overlayRow, view.column + view.columns - cells, view.column + view.columns)
    add(paintRuns, {row: overlayRow, column: view.column + view.columns - cells,
      text: repeat(lastlineGlyph, cells), cells: cells, line: 0, byte_start: 0, byte_end: 0, style: nonTextStyle})
  endif
  var fillStart = view.row + topIndex + len(visibleEntries)
  var fillEnd = view.row + topIndex + view.rows
  if bottom ==# 'truncate'
    add(frame.runs, {row: fillStart, column: view.column, cells: view.columns,
      text: repeat(lastlineGlyph, min([3, view.columns])) .. repeat(' ', max([0, view.columns - 3])),
      line: 0, byte_start: 0, byte_end: 0, style: nonTextStyle})
  elseif bottom ==# 'hidden'
    for row in range(fillStart, fillEnd - 1)
      if signWidth > 0
        add(frame.runs, {row: row, column: view.column, text: repeat(' ', signWidth), cells: signWidth,
          line: 0, byte_start: 0, byte_end: 0, style: MergeRenderStyle(windowNormal, RenderStyle(hlID('SignColumn')))})
      endif
      if &number || &relativenumber
        add(frame.runs, {row: row, column: view.column + max([0, signWidth]), text: repeat(' ', numberWidth),
          cells: numberWidth, line: 0, byte_start: 0, byte_end: 0,
          style: MergeRenderStyle(windowNormal, RenderStyle(hlID('LineNr')))})
      endif
      add(frame.runs, {row: row, column: view.column + info.textoff, text: lastlineGlyph .. repeat(' ', textWidth - 1),
        cells: textWidth, line: 0, byte_start: 0, byte_end: 0, style: nonTextStyle})
    endfor
  else
    # win_draw_end(): the eob glyph, then blanks, all in EndOfBuffer.
    for row in range(fillStart, fillEnd - 1)
      add(frame.runs, {row: row, column: view.column, text: eobGlyph .. repeat(' ', view.columns - 1),
        cells: view.columns, line: 0, byte_start: 0, byte_end: 0,
        style: MergeRenderStyle(windowNormal, RenderStyle(hlID('EndOfBuffer')))})
    endfor
  endif
  if margin > 0
    var marginRows: dict<dict<any>> = {}
    for index in range(len(displayEntries))
      var relative = index - topIndex
      if relative < 0 || relative >= view.rows
        var entry = displayEntries[index]
        var edge = {row: relative, line: entry[0], byte_length: strlen(getline(entry[0])), runs: []}
        if has_key(foldEnds, string(entry[0]))
          edge.fold_end = foldEnds[string(entry[0])]
        endif
        if wrapped
          edge.part = entry[1]
          edge.parts = entry[2]
        endif
        marginRows[string(relative)] = edge
        add(frame.overscan, edge)
      endif
    endfor
    var visibleRuns: list<dict<any>> = []
    for run in frame.runs
      var relative = run.row - view.row - topIndex
      if relative >= 0 && relative < view.rows
        run.row = view.row + relative
        add(visibleRuns, run)
      elseif has_key(marginRows, string(relative))
        run.row = 0
        add(marginRows[string(relative)].runs, run)
      endif
    endfor
    frame.runs = visibleRuns
  endif
  if get(position, 'row', 0) > view.row && position.row <= view.row + view.rows
      && get(position, 'curscol', 0) > 0
    var beforeHint = has_key(get(get(inlineLayouts, string(line('.')), {}), 'advances', {}), string(col('.') - 1))
      && mode(1) =~# '^[iR]'
    # screenpos().endcol includes virtual text before an Insert/Replace
    # caret and at EOL. It must not turn the native caret into a label-wide
    # block, nor advertise the hint's cells as editable source geometry.
    var narrowCursor = beforeHint || col('.') > strlen(getline('.'))
      || strpart(getline('.'), col('.') - 1, 1) ==# "\t"
    frame.cursor = {row: position.row - 1, column: position.curscol - 1,
      width: narrowCursor ? 1 : max([1, position.endcol - position.curscol + 1]), visible: true,
      line: line('.'), byte_column: col('.') - 1, appearance: RenderCursorAppearance()}
  endif
  return frame
enddef

# win_execute() switches only Vim's evaluation context: no WinEnter/BufEnter
# and no directory changes. The command itself is explicitly noautocmd and
# this callback only reads buffer/window state. Do not use win_gotoid(),
# :normal, cursor(), or a text widget to manufacture a second editor state.
def SampleRenderWindow()
  var key = string(win_getid())
  var cache = get(renderWindowCaches, key, {})
  renderBaseKey = get(cache, 'key', '')
  renderBase = get(cache, 'base', [])
  renderLineGeneration = get(cache, 'generation', '')
  renderLineCache = get(cache, 'lines', {})
  try
    renderWindowSample = RenderWindowFrame(renderProtocol >= 4 ? 8 : (renderProtocol >= 3 ? 2 : 0))
    # An unsupported hidden row must not disable a supported visible viewport.
    # Retry without margins; never downgrade a real visible failure silently.
    if renderProtocol >= 3 && !renderWindowSample.supported
      renderBaseKey = ''
      renderBase = []
      renderWindowSample = RenderWindowFrame()
    endif
    renderWindowCaches[key] = renderWindowSample.supported
      ? {key: renderBaseKey, base: renderBase, generation: renderLineGeneration, lines: renderLineCache}
      : {key: '', base: [], generation: '', lines: {}}
    if win_getid() != renderSamplingWindow
      renderWindowSample.cursor.visible = false
    endif
    for run in renderWindowSample.runs
      run.window = win_getid()
    endfor
    for edge in get(renderWindowSample, 'overscan', [])
      for run in edge.runs
        run.window = win_getid()
      endfor
    endfor
  finally
    renderBaseKey = ''
    renderBase = []
    renderLineGeneration = ''
    renderLineCache = {}
  endtry
enddef

# Completion remains Vim-owned. Public APIs do not expose pum_first, so never
# guess which candidates a scrolling/fuzzy menu is showing. Render only a
# complete, unclipped ordinary list with exact Vim row/column geometry.
def CompletionText(runs: list<dict<any>>, text: string, row: number, column: number, style: dict<any>)
  var col = column
  for index in range(strchars(text, true))
    var cluster = strcharpart(text, index, 1, true)
    var cells = strdisplaywidth(cluster)
    if cells <= 0 || cells > 2
      throw 'Complex Vim completion text uses the compatibility view'
    endif
    if strlen(cluster) == 1 && !empty(runs) && runs[-1].row == row
        && runs[-1].column + runs[-1].cells == col && runs[-1].style == style
        && strlen(runs[-1].text) == strchars(runs[-1].text)
        && runs[-1].text =~# '^[\x20-\x7e]*$'
      runs[-1].text ..= cluster
      runs[-1].cells += cells
    else
      add(runs, {window: 0, row: row, column: col, text: cluster, cells: cells,
        line: 0, byte_start: 0, byte_end: 0, style: style})
    endif
    col += cells
  endfor
enddef

def RenderCompletion(): dict<any>
  var position = pum_getpos()
  if mode(1) !~# '^i' || empty(position) || position.size != position.height
      || position.scrollbar || position.height <= 0 || position.height > 64
      || position.width <= 0 || position.width > 511
    throw 'Scrolling Vim completion menus use the compatibility view'
  endif
  for option in ['pumborder', 'pumshadow', 'pumopt']
    if exists('+' .. option) && !empty(eval('&' .. option))
      throw 'Decorated Vim completion menus use the compatibility view'
    endif
  endfor
  if (exists('+pumopacity') && index([0, 100], eval('&pumopacity')) < 0)
      || (exists('+completeitemalign') && index(['', 'abbr,kind,menu'], eval('&completeitemalign')) < 0)
      || &completeopt =~# '\<fuzzy\>'
    throw 'Custom Vim completion layout uses the compatibility view'
  endif
  for pair in [['PmenuMatch', 'Pmenu'], ['PmenuMatchSel', 'PmenuSel']]
    var matchStyle = RenderStyle(hlID(pair[0]))
    if matchStyle != RenderStyle(0) && matchStyle != RenderStyle(hlID(pair[1]))
      throw 'Vim completion match highlighting uses the compatibility view'
    endif
  endfor
  var info = complete_info(['items', 'selected'])
  var candidates = get(info, 'items', [])
  if len(candidates) != position.size || info.selected < -1 || info.selected >= len(candidates)
    throw 'Filtered Vim completion menus use the compatibility view'
  endif
  var widths = [0, 0, 0]
  var labels: list<list<string>> = []
  for item in candidates
    var word = empty(get(item, 'abbr', '')) ? item.word : item.abbr
    var fields = [word, get(item, 'kind', ''), get(item, 'menu', '')]
    for field in range(3)
      var text = fields[field]
      if strlen(text) > 2048 || text =~# '[\x00-\x1f\x7f\u0590-\u08ff\u200b-\u200f\u202a-\u202e\u2066-\u2069\ufeff]'
        throw 'Complex Vim completion labels use the compatibility view'
      endif
      widths[field] = max([widths[field], strdisplaywidth(text) + (field > 0 && !empty(text) ? 1 : 0)])
    endfor
    add(labels, fields)
  endfor
  var starts = [position.col, position.col + widths[0] + 1,
    position.col + widths[0] + 1 + widths[1]]
  for field in range(3)
    var needed = widths[field] - (field > 0 && widths[field] > 0 ? 1 : 0)
    if needed > 0 && starts[field] + needed > position.col + position.width
      throw 'Clipped Vim completion labels use the compatibility view'
    endif
  endfor
  var left = position.col > 0 ? 1 : 0
  var view = {row: position.row, column: position.col - left,
    rows: position.height, columns: position.width + left}
  if view.row < 0 || view.column < 0 || view.row + view.rows > &lines
      || view.column + view.columns > &columns
    throw 'Vim completion geometry uses the compatibility view'
  endif
  var windowNormal = WindowNormalStyle()
  var normal = MergeRenderStyle(windowNormal, RenderStyle(hlID('Pmenu')))
  var runs: list<dict<any>> = []
  for index in range(len(candidates))
    var selected = index == info.selected
    var rowStyle = selected ? MergeRenderStyle(windowNormal, RenderStyle(hlID('PmenuSel'))) : normal
    var row = position.row + index
    CompletionText(runs, repeat(' ', view.columns), row, view.column, rowStyle)
    for field in range(3)
      var label = labels[index][field]
      if empty(label)
        continue
      endif
      var group = field == 0 ? (selected ? 'PmenuSel' : 'Pmenu')
        : (field == 1 ? (selected ? 'PmenuKindSel' : 'PmenuKind') : (selected ? 'PmenuExtraSel' : 'PmenuExtra'))
      var style = MergeRenderStyle(rowStyle, RenderStyle(hlID(group)))
      var custom = get(candidates[index], field == 0 ? 'abbr_hlgroup' : (field == 1 ? 'kind_hlgroup' : ''), '')
      if !empty(custom)
        style = MergeRenderStyle(style, RenderStyle(hlID(custom)))
      endif
      CompletionText(runs, label, row, starts[field], style)
    endfor
  endfor
  if len(runs) > 4096
    throw 'Vim completion exceeds the native paint budget'
  endif
  return {view: view, default_style: normal, runs: runs}
enddef

# Vim does not expose popup masks through popup_getoptions(). Only a provider
# that owns an opaque, rectangular, read-only text popup may opt in by setting
# w:jterm_native_popup = 1. It must remove that marker before adding a mask or
# any other transparency. Unregistered plugins retain Vim compatibility paint.
# Exposed geometry/options are still validated on every sample; this marker is
# a presentation contract, never permission to synthesize editor input.
var renderPopupSample: dict<any> = {}

def PopupBox(options: dict<any>, key: string): list<number>
  if !has_key(options, key)
    return [0, 0, 0, 0]
  endif
  var values: any = options[key]
  if type(values) != v:t_list
    throw 'Invalid Vim popup decoration uses the compatibility view'
  endif
  if empty(values)
    return [1, 1, 1, 1]
  endif
  if len(values) != 4
    throw 'Complex Vim popup decoration uses the compatibility view'
  endif
  var result: list<number> = []
  for value in values
    if type(value) != v:t_number || value < 0 || value > 64
      throw 'Invalid Vim popup decoration uses the compatibility view'
    endif
    add(result, key ==# 'border' ? (value > 0 ? 1 : 0) : value)
  endfor
  return result
enddef

def PopupNormalStyle(): dict<any>
  var group = WindowNormalGroup()
  if !group.supported
    throw 'Vim popup highlight remapping uses the compatibility view'
  endif
  # An empty popup wincolor means Pmenu, not the parent split's Normal.
  var style = copy(RenderStyle(hlID(empty(group.name) ? 'Pmenu' : group.name)))
  for color in ['foreground', 'background', 'special']
    if type(style[color]) != v:t_number
      style[color] = renderNormal[color]
    endif
  endfor
  return style
enddef

def SampleRenderPopup()
  var id = win_getid()
  var registered: any = getwinvar(id, 'jterm_native_popup', 0)
  if type(registered) != v:t_number || registered != 1
    throw 'Unregistered Vim popups use the compatibility view'
  endif
  var position = popup_getpos(id)
  var options = popup_getoptions(id)
  if empty(position) || empty(options) || !get(position, 'visible', 0)
    throw 'A Vim popup changed during native sampling'
  endif
  if has_key(options, 'filter') || !empty(get(options, 'mask', []))
      || !empty(get(options, 'title', '')) || get(options, 'close', 'none') ==# 'button'
      || get(options, 'cursorline', 0) || get(options, 'drag', 0)
      || get(options, 'dragall', 0) || get(options, 'resize', 0)
      || (has_key(options, 'opacity') && options.opacity != 100)
    throw 'Interactive or decorated Vim popups use the compatibility view'
  endif
  var view = {row: position.line - 1, column: position.col - 1,
    rows: position.height, columns: position.width + position.scrollbar}
  var zindex = get(options, 'zindex', 50)
  if view.row < 0 || view.column < 0 || view.rows < 1 || view.rows > 64
      || view.columns < 1 || view.columns > 512 || view.row + view.rows > &lines
      || view.column + view.columns > &columns || zindex < 1 || zindex > 32000
    throw 'Vim popup geometry exceeds the native paint budget'
  endif
  if position.core_width < 1 || position.core_height < 1
      || (renderProtocol < 7 && (position.scrollbar || position.firstline != 1 || position.core_height < line('$')))
      || (get(options, 'wrap', 1) && (position.scrollbar || position.firstline != 1 || position.core_height < line('$')))
    throw 'Scrolling or clipped Vim popups use the compatibility view'
  endif
  var border = PopupBox(options, 'border')
  var padding = PopupBox(options, 'padding')
  if position.core_line != position.line + border[0] + padding[0]
      || position.core_col != position.col + border[3] + padding[3]
      || position.width != position.core_width + border[1] + border[3] + padding[1] + padding[3]
      || position.height != position.core_height + border[0] + border[2] + padding[0] + padding[2]
    throw 'Clipped Vim popup decorations use the compatibility view'
  endif
  if (&buftype !=# 'popup' && !NativeTextBuffer(&buftype))
      || &rightleft || &arabic || &spell || &conceallevel > 0 || &list || &diff
      || &number || &relativenumber || &foldcolumn != 0
      || getwininfo(id)[0].textoff != 0 || !empty(getmatches())
    throw 'This Vim popup display option uses the compatibility view'
  endif
  var normal = PopupNormalStyle()
  var runs: list<dict<any>> = []
  # Opaque background includes padding and empty/minheight rows.
  for row in range(view.row, view.row + view.rows - 1)
    CompletionText(runs, repeat(' ', view.columns), row, view.column, normal)
  endfor
  var chars: list<string> = &encoding ==# 'utf-8' && &ambiwidth ==# 'single'
    ? ['═', '║', '═', '║', '╔', '╗', '╝', '╚']
    : ['-', '|', '-', '|', '+', '+', '+', '+']
  var supplied: any = get(options, 'borderchars', [])
  if !empty(supplied)
    if type(supplied) != v:t_list || len(supplied) != 8
      throw 'Complex Vim popup border characters use the compatibility view'
    endif
    for glyph in supplied
      if type(glyph) != v:t_string || strchars(glyph, true) != 1
          || strdisplaywidth(glyph) != 1 || glyph =~# '[\x00-\x1f\x7f]'
        throw 'Complex Vim popup border characters use the compatibility view'
      endif
    endfor
    chars = supplied
  endif
  var borderStyles: list<dict<any>> = []
  var groups: any = get(options, 'borderhighlight', ['', '', '', ''])
  if type(groups) != v:t_list || len(groups) != 4
    throw 'Complex Vim popup border highlights use the compatibility view'
  endif
  for group in groups
    if type(group) != v:t_string
      throw 'Invalid Vim popup border highlight uses the compatibility view'
    endif
    add(borderStyles, empty(group) ? normal : MergeRenderStyle(normal, RenderStyle(hlID(group))))
  endfor
  var bottom = view.row + view.rows - 1
  var right = view.column + view.columns - 1
  for side in [0, 2]
    if border[side] != 0
      var row = side == 0 ? view.row : bottom
      CompletionText(runs, repeat(chars[side], view.columns), row, view.column, borderStyles[side])
    endif
  endfor
  for row in range(view.row + border[0], bottom - border[2])
    if border[3] != 0
      CompletionText(runs, chars[3], row, view.column, borderStyles[3])
    endif
    if border[1] != 0
      CompletionText(runs, chars[1], row, right, borderStyles[1])
    endif
  endfor
  for corner in [[0, 3, view.row, view.column, 4], [0, 1, view.row, right, 5],
      [2, 1, bottom, right, 6], [2, 3, bottom, view.column, 7]]
    if border[corner[0]] && border[corner[1]]
      CompletionText(runs, chars[corner[4]], corner[2], corner[3], borderStyles[corner[0]])
    endif
  endfor
  var first = position.firstline
  var last = min([line('$'), first + position.core_height - 1])
  var properties = prop_list(first, {end_lnum: last})
  if len(properties) > 2048
    throw 'Vim popup properties exceed the native paint budget'
  endif
  # Keep lookups local to this sample: providers may change a type without
  # editing the popup buffer. Preserve prop_list() order for priority ties.
  var propertyLines: dict<list<any>> = {}
  var propertyDefinitions: dict<dict<any>> = {}
  for property in properties
    if has_key(property, 'text') || property.col <= 0
      throw 'Vim popup virtual text uses the compatibility view'
    endif
    var name = get(property, 'type', '')
    var typeBuffer = get(property, 'type_bufnr', 0)
    var definitionKey = string([typeBuffer, name])
    if !has_key(propertyDefinitions, definitionKey)
      propertyDefinitions[definitionKey] = empty(name) ? {} : (typeBuffer > 0
        ? prop_type_get(name, {bufnr: typeBuffer}) : prop_type_get(name))
    endif
    property.definition = propertyDefinitions[definitionKey]
    var lineKey = string(property.lnum)
    if !has_key(propertyLines, lineKey)
      propertyLines[lineKey] = []
    endif
    add(propertyLines[lineKey], property)
  endfor
  for lnum in range(first, last)
    var text = getline(lnum)
    if strlen(text) > 16384 || strdisplaywidth(text) > position.core_width
        || foldclosed(lnum) >= 0 || text =~# '[\x00-\x08\x0a-\x1f\x7f\u0590-\u08ff\u200b-\u200f\u202a-\u202e\u2066-\u2069\ufeff]'
      throw 'Wrapped, clipped or complex Vim popup text uses the compatibility view'
    endif
    var lineProperties = get(propertyLines, string(lnum), [])
    if len(lineProperties) > 128
      throw 'Vim popup line properties exceed the native paint budget'
    endif
    var byteColumn = 0
    var column = 0
    for index in range(strchars(text, true))
      var glyph = strcharpart(text, index, 1, true)
      var width = strdisplaywidth(glyph, column)
      if width <= 0 || (width > 2 && glyph !=# "\t")
        throw 'Complex Vim popup glyphs use the compatibility view'
      endif
      var style = RenderStyle(synID(lnum, byteColumn + 1, true))
      var propertyStyle: dict<any> = {}
      var priority = -2147483648
      var combine = true
      for property in lineProperties
        var definition = property.definition
        if byteColumn < property.col - 1 + property.length
            && byteColumn + strlen(glyph) > property.col - 1
            && get(definition, 'priority', 0) > priority && !empty(get(definition, 'highlight', ''))
          propertyStyle = RenderStyle(hlID(definition.highlight))
          priority = get(definition, 'priority', 0)
          combine = !!get(definition, 'combine', true)
        endif
      endfor
      if !empty(propertyStyle)
        style = combine ? MergeRenderStyle(style, propertyStyle) : propertyStyle
      endif
      CompletionText(runs, glyph ==# "\t" ? repeat(' ', width) : glyph,
        position.core_line + lnum - first - 1, position.core_col + column - 1,
        MergeRenderStyle(normal, style))
      byteColumn += strlen(glyph)
      column += width
    endfor
  endfor
  if len(runs) > 4096
    throw 'Vim popup runs exceed the native paint budget'
  endif
  if position.scrollbar
    # Mirror popupwin.c's source-based thumb calculation, never terminal cells.
    var height = position.core_height
    var count = line('$')
    var thumbHeight = (height * height + count / 2) / count
    if first > 1 && thumbHeight == height
      thumbHeight -= 1
    endif
    thumbHeight = max([1, thumbHeight])
    var thumbTop = count <= height ? 0 : (first - 1 + (count / height) / 2) * (height - thumbHeight) / (count - height)
    if first > 1 && thumbTop == 0 && height > 1
      thumbTop = 1
    endif
    thumbTop = min([thumbTop, height + padding[2] - 1])
    var track = MergeRenderStyle(normal, RenderStyle(hlID(get(options, 'scrollbarhighlight', 'PmenuSbar'))))
    var thumb = MergeRenderStyle(normal, RenderStyle(hlID(get(options, 'thumbhighlight', 'PmenuThumb'))))
    for offset in range(height)
      CompletionText(runs, ' ', position.core_line - 1 + offset,
        view.column + view.columns - 1 - border[1],
        offset >= thumbTop && offset < thumbTop + thumbHeight ? thumb : track)
    endfor
  endif
  var kind = ''
  var requestedKind: any = getwinvar(id, 'jterm_native_popup_kind', '')
  if renderProtocol >= 7 && type(requestedKind) == v:t_string
      && index(['hover', 'signature', 'diagnostic', 'completion_documentation'], requestedKind) >= 0
      && border == [0, 0, 0, 0] && min(padding) >= 1
    kind = requestedKind
  endif
  renderPopupSample = {id: id, zindex: zindex, view: view, default_style: normal, runs: runs}
  if renderProtocol >= 7
    renderPopupSample.kind = kind
  endif
enddef

def RenderPopups(): list<dict<any>>
  var ids = VisiblePopups()
  if len(ids) > 8
    throw 'Vim popups exceed the native surface budget'
  endif
  var popups: list<dict<any>> = []
  var count = 0
  for id in ids
    renderPopupSample = {}
    win_execute(id, 'noautocmd call ' .. expand('<SID>') .. 'SampleRenderPopup()')
    if empty(renderPopupSample)
      throw 'A Vim popup changed during native sampling'
    endif
    count += len(renderPopupSample.runs)
    if count > 4096
      throw 'Vim popups exceed the native paint budget'
    endif
    add(popups, renderPopupSample)
  endfor
  # Vim paints the older popup above a newer popup at the same zindex.
  return sort(popups, (a, b) => a.zindex == b.zindex ? b.id - a.id : a.zindex - b.zindex)
enddef

def RenderFrame(): dict<any>
  if workbenchActionDepth > 0
    return {event: 'render', supported: false,
      fallback_reason: 'A Vim workbench plugin is using the compatibility view',
      buffer: bufnr(), window: win_getid(), changedtick: b:changedtick, mode: mode(1),
      rows: &lines, columns: &columns, runs: [], completion: v:null, popups: []}
  endif
  var active = win_getid()
  var activeMode = mode(1)
  var activeView = winsaveview()
  var activeBuffer = bufnr()
  renderSamplingWindow = active
  renderSamplingVisual = {}
  if index(['v', 'V', "\<C-V>"], activeMode) >= 0
    var anchor = getpos('v')
    var current = getpos('.')
    var ordered = anchor[1] < current[1] || (anchor[1] == current[1] && anchor[2] <= current[2])
    renderSamplingVisual = {mode: activeMode, buffer: activeBuffer,
      low: ordered ? anchor : current, high: ordered ? current : anchor}
  endif
  # Sampling the active window directly is essential: win_execute() makes
  # an inactive window Normal temporarily while preserving the caller's
  # Visual mode. This also prevents Visual selections leaking into siblings.
  SampleRenderWindow()
  var frame = renderWindowSample
  frame.windows = []
  if !frame.supported
    return frame
  endif
  var ids = gettabinfo(tabpagenr())[0].windows
  if len(ids) > 16
    frame.supported = false
    frame.fallback_reason = 'This Vim layout exceeds the bounded native window budget'
    frame.runs = []
    return frame
  endif
  var caches: dict<dict<any>> = {}
  var runs: list<dict<any>> = []
  var sampleCommand = 'noautocmd call ' .. expand('<SID>') .. 'SampleRenderWindow()'
  for id in ids
    if id == active
      renderWindowSample = frame
    else
      renderWindowSample = {}
      win_execute(id, sampleCommand)
    endif
    if empty(renderWindowSample) || !renderWindowSample.supported
      frame.supported = false
      frame.fallback_reason = empty(renderWindowSample)
        ? 'A Vim window changed during native sampling'
        : 'Window ' .. id .. ': ' .. renderWindowSample.fallback_reason
      frame.runs = []
      frame.windows = []
      return frame
    endif
    var sample = renderWindowSample
    var metadata = {window: sample.window, buffer: sample.buffer,
      changedtick: sample.changedtick, view: sample.view, cursor: sample.cursor,
      topline: sample.topline, botline: sample.botline,
      textoff: sample.textoff, leftcol: sample.leftcol,
      line_count: sample.line_count, overscan: sample.overscan,
      native_pointer: sample.native_pointer, native_scroll: sample.native_scroll,
      scroll_ack: sample.scroll_ack,
      line_lengths: sample.line_lengths}
    if renderProtocol >= 8
      # Display rows actually moved by the acknowledged request. Without folds
      # this equals the topline delta; across a closed fold it is smaller.
      metadata.scroll_rows = get(scrollAcknowledgedRows, string(sample.window), 0)
      if has_key(sample, 'display_lines')
        metadata.display_lines = sample.display_lines
        metadata.fold_ends = sample.fold_ends
      endif
      if has_key(sample, 'wrap_parts')
        metadata.wrap_parts = sample.wrap_parts
        metadata.wrap_rows = sample.wrap_rows
      endif
      if has_key(sample, 'skipcol')
        metadata.skipcol = sample.skipcol
      endif
    endif
    add(frame.windows, metadata)
    extend(runs, sample.runs)
    caches[string(id)] = renderWindowCaches[string(id)]
  endfor
  renderWindowCaches = caches
  frame.runs = runs
  remove(frame, 'overscan')
  remove(frame, 'line_lengths')
  remove(frame, 'native_pointer')
  remove(frame, 'native_scroll')
  remove(frame, 'scroll_ack')
  for name in ['display_lines', 'fold_ends', 'wrap_parts', 'wrap_rows', 'skipcol']
    if has_key(frame, name)
      remove(frame, name)
    endif
  endfor
  if win_getid() != active || bufnr() != activeBuffer || mode(1) !=# activeMode || winsaveview() != activeView
    frame.supported = false
    frame.fallback_reason = 'Vim changed its active view during native sampling'
    frame.runs = []
    frame.windows = []
  endif
  if frame.supported
    try
      if pumvisible()
        frame.completion = RenderCompletion()
      endif
      if renderProtocol >= 6
        frame.popups = RenderPopups()
      endif
    catch
      frame.supported = false
      frame.fallback_reason = v:exception
      frame.runs = []
      frame.windows = []
      frame.completion = v:null
      frame.popups = []
    endtry
  endif
  return frame
enddef

def RenderLayoutKey(frame: dict<any>): string
  var windows = map(copy(get(frame, 'windows', [])), (_, item) => [item.window, item.buffer, item.view])
  return string([frame.rows, frame.columns, frame.window, frame.buffer,
    frame.view, frame.default_style, windows])
enddef

# The frame's JSON with its runs grouped by screen row (paint order is kept
# within a row; runs on different rows never overlap). Fills rowJson with
# each row's encoded run list for the delta.
def EncodeRenderRows(frame: dict<any>, rowJson: dict<string>): string
  var rowRuns: dict<list<dict<any>>> = {}
  for run in frame.runs
    var key = string(run.row)
    if !has_key(rowRuns, key)
      rowRuns[key] = []
    endif
    add(rowRuns[key], run)
  endfor
  # Rows in screen order, so equal frames always encode to equal strings.
  var parts: list<string> = []
  for row in sort(map(keys(rowRuns), (_, key) => str2nr(key)), 'n')
    var key = string(row)
    var data = json_encode(rowRuns[key])
    rowJson[key] = data
    add(parts, strpart(data, 1, strlen(data) - 2))
  endfor
  var runs = remove(frame, 'runs')
  var meta = json_encode(frame)
  frame.runs = runs
  return strpart(meta, 0, strlen(meta) - 1) .. ',"runs":[' .. join(parts, ',') .. ']}'
enddef

def EmitRender(force: bool = false)
  if !renderEnabled || !authenticated || shuttingDown || ch_status(bridge) !=# 'open'
    return
  endif
  # Source-bound scrolling publishes before its response. That paint already
  # consumes the work queued by Changed()/WinScrolled; leaving the 16ms timer
  # alive would sample and compose the same viewport again after every ack.
  if renderTimer >= 0
    timer_stop(renderTimer)
    renderTimer = -1
  endif
  try
    if renderThemePending
      # ModeChanged fires before an Ex command finishes. Resolve its theme
      # after the input batch, not while :highlight still has its old value.
      renderThemePending = false
      RefreshRenderTheme()
    endif
    var frame = RenderFrame()
    # Delta hosts receive runs grouped by row; each row is encoded once and
    # reused for the keyframe, the change test and the delta.
    var rowJson: dict<string> = {}
    var byRow = renderProtocol >= 2 && frame.supported
    var encoded = byRow ? EncodeRenderRows(frame, rowJson) : json_encode(frame)
    if strlen(encoded) > 900000
      for window in get(frame, 'windows', [])
        window.overscan = []
      endfor
      encoded = byRow ? EncodeRenderRows(frame, rowJson) : json_encode(frame)
    endif
    if strlen(encoded) > 900000
      frame.supported = false
      frame.fallback_reason = 'Native paint data exceeds the bounded frame budget'
      frame.runs = []
      frame.completion = v:null
      frame.popups = []
      encoded = json_encode(frame)
      rowJson = {}
    endif
    if force || encoded !=# previousRender
      previousRender = encoded
      var baseRevision = renderRevision
      renderRevision += 1
      frame.revision = renderRevision
      var layout = renderProtocol >= 2 && frame.supported ? RenderLayoutKey(frame) : ''
      var rows: dict<string> = {}
      var updates: list<string> = []
      # Legacy full-frame hosts never consume row deltas. Supported keyframes
      # still seed a delta baseline; unsupported frames retire it entirely.
      if renderProtocol >= 2 && frame.supported
        # Replace complete screen rows, preserving within-row paint order.
        # This includes siblings in a vertical split and explicit empty clears.
        for row in range(frame.rows)
          var key = string(row)
          var rowData = get(rowJson, key, '[]')
          if rowData !=# '[]'
            rows[key] = rowData
          endif
          if rowData !=# get(previousRenderRows, key, '[]')
            add(updates, '{"row":' .. row .. ',"runs":' .. rowData .. '}')
          endif
        endfor
      endif
      var sentDelta = false
      if renderProtocol >= 2 && !force && frame.supported && layout ==# previousRenderLayout
          && renderRevision - renderKeyframeRevision < 120
        var delta = copy(frame)
        remove(delta, 'runs')
        delta.event = 'render_delta'
        delta.base_revision = baseRevision
        # Scrolling a whole viewport can be cheaper as a complete keyframe.
        var deltaMeta = json_encode(delta)
        var deltaJson = strpart(deltaMeta, 0, strlen(deltaMeta) - 1)
          .. ',"row_updates":[' .. join(updates, ',') .. ']}'
        if strlen(deltaJson) < strlen(encoded)
          SendRenderJson(deltaJson)
          sentDelta = true
        endif
      endif
      if !sentDelta
        SendRenderJson(encoded, renderRevision)
        renderKeyframeRevision = renderRevision
      endif
      previousRenderLayout = layout
      previousRenderRows = rows
    endif
  catch
    # Rendering must never break actual editing or disconnect metadata/actions.
    renderBaseKey = ''
    previousRender = ''
    previousRenderLayout = ''
    previousRenderRows = {}
    renderRevision += 1
    Send({event: 'render', revision: renderRevision, supported: false,
      rows: &lines, columns: &columns, completion: v:null, popups: [],
      fallback_reason: 'Native paint unavailable: ' .. strcharpart(v:exception, 0, 512)})
  endtry
enddef

def FlushRender(_: number)
  renderTimer = -1
  EmitRender()
enddef

def RenderChanged()
  if renderEnabled && authenticated && !shuttingDown && renderTimer < 0
    renderTimer = timer_start(16, FlushRender)
  endif
enddef

def RenderThemeChanged()
  # :syntax clear/match can change syntax without changing b:changedtick,
  # &syntax or any highlight group. A command-line transition is therefore
  # a semantic cache boundary, including commands executed in another window.
  if get(v:event, 'old_mode', '') =~# '^c' || get(v:event, 'new_mode', '') =~# '^c'
    renderWindowCaches = {}
  endif
  # Do not sample before a command-line transition's Ex command executes.
  # The next actual paint consumes this flag, including immediate scroll/resync.
  renderThemePending = true
  RenderChanged()
enddef

def InvalidateRender()
  renderWindowCaches = {}
  renderBaseKey = ''
  renderBase = []
  renderLineGeneration = ''
  renderLineCache = {}
  RefreshRenderTheme()
  RenderChanged()
enddef

def Kind(value: string): string
  var kind = toupper(value)
  if kind ==# 'W'
    return 'warning'
  elseif kind ==# 'I'
    return 'info'
  elseif kind ==# 'N' || kind ==# 'H'
    return 'hint'
  endif
  return 'error'
enddef

# LSP's default character unit is UTF-16; Vim cursor columns are UTF-8 bytes.
# This avoids depending on the newer three-argument byteidx() API.
def Utf16ByteColumn(text: string, units: number): number
  if units <= 0
    return 1
  endif
  var consumed = 0
  var bytes = 0
  # Decode once. Repeated strchars()/strgetchar() rescans UTF-8 prefixes and
  # makes diagnostics near the end of long source lines quadratic. Iterate
  # codepoints, not display clusters: combining marks each consume one LSP
  # unit, and a position inside a surrogate pair stays before that codepoint.
  for point in str2list(text, true)
    var width = point > 0xffff ? 2 : 1
    if consumed + width > units
      break
    endif
    consumed += width
    bytes += strlen(nr2char(point))
    if consumed >= units
      break
    endif
  endfor
  return bytes + 1
enddef

def WorkbenchDiagnostics(): dict<any>
  var result: dict<any> = {items: [], total: 0}
  if !exists('*g:VimrcWorkbenchDiagnostics') || empty(expand('%:p'))
    return result
  endif
  try
    var provided: any = call('g:VimrcWorkbenchDiagnostics', [])
    if type(provided) != v:t_dict || type(get(provided, 'items', 0)) != v:t_list
      return result
    endif
    # Only current-buffer positions and display text may cross this boundary.
    # The bridge owns the filename; hooks cannot publish another file's cache
    # or serialize arbitrary plugin state, callbacks or recursive dictionaries.
    var entries: list<any> = provided.items
    for entry in entries[: 255]
      if type(entry) != v:t_dict
        continue
      endif
      var lnum: any = get(entry, 'line', 0)
      var column: any = get(entry, 'column', 0)
      var kind: any = get(entry, 'kind', '')
      if type(lnum) != v:t_number || lnum <= 0
          || type(column) != v:t_number || column <= 0
          || type(kind) != v:t_string || index(['error', 'warning', 'info', 'hint'], kind) < 0
          || type(get(entry, 'text', 0)) != v:t_string
        continue
      endif
      add(result.items, {line: lnum, column: column, kind: kind,
        text: WorkbenchText(entry, 'text', 2048)})
    endfor
    # Invalid sampled entries are ignored. Uninspected/omitted provider rows
    # still count against the shared diagnostic budget, with a bounded total.
    result.total = len(result.items) + min([1000000,
      max([len(entries), WorkbenchCount(provided, 'total')])]) - min([256, len(entries)])
  catch
    # A missing/reloading provider must also expire its previous cached rows.
    return {items: [], total: 0}
  endtry
  return result
enddef

def Diagnostics(): dict<any>
  var workbench = WorkbenchDiagnostics()
  var keyNow = string([getqflist({id: 0, changedtick: 0}),
    getloclist(0, {id: 0, changedtick: 0}), bufnr(), b:changedtick, lspDiagnosticsTick, workbench])
  if keyNow ==# diagnosticsKey
    return diagnosticsCache
  endif
  var result: list<dict<any>> = []
  var seen: dict<bool> = {}
  var total = 0
  var entries: list<dict<any>> = getqflist()
  # A Vim LSP or other plugin may use the current window's location list.
  extend(entries, getloclist(0))
  for entry in entries
    if !get(entry, 'valid', 0)
      continue
    endif
    var number: number = get(entry, 'bufnr', 0)
    var bufferInfo = number > 0 ? getbufinfo(number) : []
    var filename: string = empty(bufferInfo) ? '' : bufferInfo[0].name
    var lineNumber: number = max([1, get(entry, 'lnum', 1)])
    var column: number = max([1, get(entry, 'col', 1)])
    if get(entry, 'vcol', 0)
      var windows = number > 0 ? win_findbuf(number) : []
      # Convert using Vim's own rendering rules, including tabs and wide text.
      # An undisplayed buffer has no rendering context; navigate to its line
      # beginning until the user opens it, rather than sending a wrong byte.
      column = empty(windows) ? 1 : max([1, virtcol2col(windows[0], lineNumber, column)])
    endif
    var message: string = strcharpart(get(entry, 'text', ''), 0, 2048)
    var key = string([filename, lineNumber, column, message])
    if has_key(seen, key)
      continue
    endif
    seen[key] = true
    total += 1
    if len(result) < 256
      add(result, {filename: filename, line: lineNumber, column: column,
        text: message, kind: Kind(get(entry, 'type', '')), column_kind: 'byte'})
    endif
  endfor
  # Yegappan's Vim9 LSP exposes diagnostics without opening its location list.
  # The hook is optional; an unavailable or failing plugin must not stop Vim.
  if exists('*lsp#diag#GetDiagsForBuf')
    try
      var filename = expand('%:p')
      var lspEntries: list<dict<any>> = call('lsp#diag#GetDiagsForBuf', [bufnr()])
      for entry in lspEntries
        var position: dict<any> = get(get(entry, 'range', {}), 'start', {})
        var lineNumber: number = get(position, 'line', 0) + 1
        var lines = getbufline(bufnr(), lineNumber)
        var column = Utf16ByteColumn(empty(lines) ? '' : lines[0], get(position, 'character', 0))
        var message: string = strcharpart(get(entry, 'message', ''), 0, 2048)
        var key = string([filename, lineNumber, column, message])
        if has_key(seen, key)
          continue
        endif
        seen[key] = true
        total += 1
        if len(result) < 256
          var severity: number = get(entry, 'severity', 1)
          add(result, {filename: filename, line: lineNumber, column: column,
            text: message, kind: get(['error', 'warning', 'info', 'hint'], severity - 1, 'error')})
        endif
      endfor
    catch
      # Plugins own their initialization and server lifecycle.
    endtry
  endif
  # Simple workbench diagnostics do not create/replace a quickfix or location
  # list. All four hosts consume the same existing native problem-row schema.
  var filename = expand('%:p')
  for entry in workbench.items
    var key = string([filename, entry.line, entry.column, entry.text])
    if has_key(seen, key)
      continue
    endif
    seen[key] = true
    total += 1
    if len(result) < 256
      add(result, {filename: filename, line: entry.line, column: entry.column,
        text: entry.text, kind: entry.kind, column_kind: 'byte'})
    endif
  endfor
  total += workbench.total - len(workbench.items)
  diagnosticsKey = keyNow
  diagnosticsCache = {items: result, total: total}
  return diagnosticsCache
enddef

def Navigation(): dict<bool>
  # Vim owns this bounded, per-window history, including plugin and keyboard
  # jumps. The native controls never maintain a second stale cursor stack.
  var [jumps, current] = getjumplist()
  var back = false
  var forward = false
  for index in range(len(jumps))
    var entry: dict<any> = jumps[index]
    if get(entry, 'lnum', 0) <= 0
        || (get(entry, 'bufnr', 0) == bufnr() && entry.lnum == line('.')
          && get(entry, 'col', 0) == col('.') - 1)
      continue
    endif
    back = back || index < current
    forward = forward || index > current
  endfor
  return {can_go_back: back, can_go_forward: forward}
enddef

def State(): dict<any>
  var infos = getbufinfo({buflisted: 1})
  # Keep the selected tab discoverable even when the list reaches its cap.
  # Preserve Vim's buffer ordering, replacing only the final retained entry.
  if len(infos) > 256
    var current = filter(copy(infos), (_, info) => info.bufnr == bufnr())
    if !empty(current) && index(mapnew(infos[0 : 255], (_, info) => info.bufnr), bufnr()) < 0
      infos[255] = current[0]
    endif
  endif
  var buffers: list<dict<any>> = []
  for info in infos
    if len(buffers) >= 256
      break
    endif
    # Never serialize getbufinfo() wholesale: variables may contain Funcrefs,
    # channels, cyclic objects or private data owned by a user's plugins.
    add(buffers, {id: info.bufnr, name: info.name, modified: info.changed != 0,
      current: info.bufnr == bufnr()})
  endfor
  var diagnostics = Diagnostics()
  var quickfix = getqflist({context: 0, title: 0, idx: 0, size: 0})
  var context: any = get(quickfix, 'context', {})
  var source = 'quickfix'
  var searchOmitted = 0
  var owned: any = type(context) == v:t_dict ? get(context, 'jterm_vim9', false) : false
  if type(owned) == v:t_bool && owned
    var origin: any = get(context, 'source', '')
    if type(origin) == v:t_string && index(['search', 'build'], origin) >= 0
      source = origin
    endif
    var omitted: any = get(context, 'omitted', 0)
    if source ==# 'search' && type(omitted) == v:t_number
      searchOmitted = max([0, omitted])
    endif
  endif
  var state: dict<any> = {event: 'state', mode: mode(1), file: expand('%:p'),
    buffer: bufnr(), window: win_getid(),
    root: projectRoot, cwd: getcwd(), line: line('.'), column: col('.'),
    line_count: line('$'), window_count: winnr('$'), waiting_for_input: !empty(deferredSave),
    modified: &modified, changedtick: b:changedtick, filetype: &filetype,
    encoding: empty(&fileencoding) ? &encoding : &fileencoding,
    buffers: buffers, buffers_truncated: len(infos) > len(buffers),
    buffers_omitted: len(infos) - len(buffers),
    diagnostics: copy(diagnostics.items),
    diagnostics_truncated: diagnostics.total > len(diagnostics.items) || searchOmitted > 0,
    diagnostics_omitted: diagnostics.total - len(diagnostics.items) + searchOmitted,
    navigation: Navigation(),
    quickfix: {source: source, title: strcharpart(get(quickfix, 'title', ''), 0, 2048),
      index: get(quickfix, 'idx', 0), count: get(quickfix, 'size', 0)},
    capabilities: Capabilities(),
    workbench: WorkbenchState(),
    build: {running: buildRunning, command: buildCommand, exit_code: buildExit,
      cancelled: buildCancelled, output: copy(buildTail),
      truncated: len(buildLines) + buildDropped - len(buildTail)},
    search: {running: searchRunning, query: searchQuery, count: len(searchRows),
      truncated: searchDropped, exit_code: searchExit, errors: searchErrors,
      options: searchOptions, cancelled: searchCancelled}}
  # Leave headroom inside the host's 1 MiB framing limit even for pathological
  # path names or error messages that require substantial JSON escaping.
  while strlen(json_encode(state)) > 900000
    if !empty(state.diagnostics)
      remove(state.diagnostics, -1)
      state.diagnostics_truncated = true
      state.diagnostics_omitted += 1
    elseif !empty(state.buffers)
      var discard = len(state.buffers) - 1
      # Prefer retaining the current tab, but the wire budget remains a hard
      # bound. A synthetic buffer name can itself occupy most of the frame.
      if discard > 0 && state.buffers[discard].current
        discard -= 1
      endif
      remove(state.buffers, discard)
      state.buffers_truncated = true
      state.buffers_omitted += 1
    else
      state.build.truncated += len(state.build.output)
      state.build.output = []
      break
    endif
  endwhile
  return state
enddef

def EmitState(force: bool = false)
  if !authenticated || shuttingDown || sending || ch_status(bridge) !=# 'open'
    return
  endif
  sending = true
  try
    var snapshot = State()
    var encoded = json_encode(snapshot)
    if force || encoded !=# previousState
      previousState = encoded
      Send(snapshot)
    endif
  finally
    sending = false
  endtry
enddef

def Flush(_: number)
  flushTimer = -1
  EmitState()
enddef

def Changed()
  RenderChanged()
  if authenticated && !shuttingDown && flushTimer < 0
    flushTimer = timer_start(40, Flush)
  endif
enddef

def Poll(_: number)
  # setqflist() itself has no QuickFixCmdPost event.  This bounded, low-rate
  # reconciliation also observes plugin capabilities loaded after VimEnter.
  EmitState()
  RefreshRenderTheme()
  EmitRender()
enddef

def LspDiagnosticsChanged()
  lspDiagnosticsTick += 1
  Changed()
enddef

def RememberView()
  if NativeTextBuffer(&buftype)
    bufferViews[string(bufnr())] = winsaveview()
  endif
enddef

def RestoreView(number: number)
  if has_key(bufferViews, string(number))
    winrestview(bufferViews[string(number)])
  endif
enddef

def ForgetView(number: number)
  if has_key(bufferViews, string(number))
    remove(bufferViews, string(number))
  endif
enddef

def SafeToChange()
  var currentMode = mode(1)
  if workbenchActionDepth > 0 || currentMode =~# '^no' || currentMode =~# '^[cr!t]'
      || !empty(state('moaSw'))
    throw 'Vim is busy with a command, operator or completion; finish it before this action'
  endif
enddef

def ClearDeferredSave()
  deferredSave = {}
  deferredSaveBuffer = 0
  if deferredSaveTimer >= 0
    timer_stop(deferredSaveTimer)
    deferredSaveTimer = -1
  endif
  augroup JTermVim9DeferredSave
    autocmd!
  augroup END
enddef

def ExpireDeferredSave(_: number)
  var request = deferredSave
  ClearDeferredSave()
  if !empty(request)
    Reply(request.id, false, 'Vim is still finishing input; finish the command and save again')
    Changed()
  endif
enddef

def SaveInputPending(): bool
  # getchar(1) can invoke queued channel callbacks before peeking. Preserve
  # this save's ordering while those callbacks run, including SafeStateAgain.
  var pending = false
  checkingSaveInput = true
  try
    pending = !empty(getchar(1))
  finally
    checkingSaveInput = false
  endtry
  return pending
enddef

def ResumeDeferredSave()
  if empty(deferredSave) || !authenticated || shuttingDown || checkingSaveInput
    return
  endif
  var currentMode = mode(1)
  if currentMode =~# '^no' || currentMode =~# '^[cr!t]' || !empty(state('moaSw'))
      || SaveInputPending()
    return
  endif
  # A callback invoked by the peek may have disconnected the bridge.
  if empty(deferredSave) || !authenticated || shuttingDown
    return
  endif
  var request = deferredSave
  var buffer = deferredSaveBuffer
  ClearDeferredSave()
  try
    if bufnr() != buffer
      throw 'The current buffer changed while waiting to save; save again in the intended buffer'
    endif
    Dispatch(request, request.id)
  catch
    Reply(request.id, false, v:exception)
  endtry
  Changed()
enddef

def DeferSaveIfNeeded(request: dict<any>, id: number): bool
  var action = RequiredString(request, 'action', 64)
  if workbenchActionDepth > 0 && index(['snapshot', 'render_resync', 'set_render', 'cancel_build', 'cancel_search'], action) < 0
    throw 'A Vim workbench plugin is waiting for input; finish it before another IDE action'
  endif
  if (!empty(deferredSave) || checkingSaveInput)
      && index(['snapshot', 'cancel_build', 'cancel_search'], action) < 0
    throw 'A save is waiting for Vim to finish input; wait for it before another IDE action'
  endif
  if index(['save', 'save_all', 'save_and_build'], action) < 0
    return false
  endif
  var currentMode = mode(1)
  var busy = state('moaSw')
  # A completed host PTY write can still be waiting in Vim's input stream.
  # Peek without consuming text, keycodes or Escape, and let SafeState resume
  # after Vim handles it. S also occurs while queued Escape is being decoded;
  # only reject S with no typeahead (an unfinished count/find awaiting a key).
  # Operators, command lines and completion remain immediate refusals.
  if currentMode =~# '^no' || currentMode =~# '^[cr!t]' || busy =~# '[oa]'
    return false
  endif
  var buffer = bufnr()
  var pendingInput = SaveInputPending()
  if !authenticated || shuttingDown
    throw 'Vim disconnected while checking input for this save'
  endif
  if bufnr() != buffer
    throw 'The current buffer changed while checking input; save again in the intended buffer'
  endif
  if !pendingInput && (empty(busy) || busy =~# 'S')
    return false
  endif
  if action ==# 'save_and_build'
    BuildCommand(request)
  endif
  deferredSave = copy(request)
  deferredSave.id = id
  deferredSaveBuffer = buffer
  deferredSaveTimer = timer_start(2000, ExpireDeferredSave)
  augroup JTermVim9DeferredSave
    autocmd!
    autocmd SafeState,SafeStateAgain * ResumeDeferredSave()
  augroup END
  Changed()
  return true
enddef

def RequiredString(request: dict<any>, key: string, limit: number = 16384): string
  var value: any = get(request, key, '')
  if type(value) != v:t_string || empty(value) || strlen(value) > limit
    throw 'A non-empty ' .. key .. ' string is required'
  endif
  return value
enddef

def PositiveNumber(request: dict<any>, key: string, fallback: number = 1): number
  var value: any = get(request, key, fallback)
  if type(value) != v:t_number || value < 1 || value > 2147483647
    throw key .. ' must be a positive integer'
  endif
  return value
enddef

def FinishBuild(generation: number)
  if generation != buildGeneration || !buildClosed || !buildExited
    return
  endif
  buildRunning = false
  # Seed Vim's errorformat directory stack so paths emitted by the build stay
  # relative to its cwd even if the user changed Vim's cwd while it was running.
  var directoryLine = 'JTERM_DIRECTORY ' .. projectRoot
  var parsed = getqflist({lines: [directoryLine] + buildLines,
    efm: '%DJTERM_DIRECTORY %f,' .. buildErrorFormat}).items
  # Vim retains directory markers as invalid quickfix rows even with %-D.
  # Remove only our seed after parsing; preserve the user's remaining output.
  if !empty(parsed) && !get(parsed[0], 'valid', 0)
      && get(parsed[0], 'text', '') ==# directoryLine
    remove(parsed, 0)
  endif
  setqflist([], ' ', {title: 'Build: ' .. buildCommand, items: parsed,
    context: {jterm_vim9: true, source: 'build'}})
  Changed()
enddef

def BuildOutput(generation: number, _: channel, message: string)
  if generation != buildGeneration
    return
  endif
  var text = strcharpart(message, 0, 2048)
  add(buildTail, text)
  if len(buildTail) > 80
    remove(buildTail, 0)
  endif
  if len(buildLines) < 10000
    add(buildLines, text)
  else
    buildDropped += 1
  endif
  Changed()
enddef

def BuildClosed(generation: number, _: channel)
  if generation == buildGeneration
    buildClosed = true
    FinishBuild(generation)
  endif
enddef

def BuildExited(generation: number, _: job, status: number)
  if generation == buildGeneration
    buildExited = true
    buildExit = status
    FinishBuild(generation)
  endif
enddef

def BuildCommand(request: dict<any>): string
  if buildRunning
    throw 'A build is already running; cancel it before starting another'
  endif
  var supplied: any = get(request, 'command', '')
  if type(supplied) != v:t_string || strlen(supplied) > 16384
    throw 'Build command must be a string of at most 16384 bytes'
  endif
  var command: string = empty(trim(supplied)) ? expandcmd(&makeprg) : supplied
  if empty(trim(command))
    throw 'Configure makeprg in Vim or enter a build command'
  endif
  return command
enddef

def StartBuild(request: dict<any>)
  var command = BuildCommand(request)
  buildGeneration += 1
  const generation = buildGeneration
  buildCommand = command
  buildLines = []
  buildTail = []
  buildDropped = 0
  buildExit = v:null
  buildClosed = false
  buildExited = false
  buildCancelled = false
  buildRunning = true
  buildErrorFormat = &errorformat
  # A build is the one explicitly authorized shell action.  File names and
  # search queries never take this path.  No implicit save is performed.
  buildJob = job_start([&shell, &shellcmdflag, command], {cwd: projectRoot,
    in_io: 'null', out_mode: 'nl', err_mode: 'nl', noblock: true,
    out_cb: (ch: channel, msg: string) => BuildOutput(generation, ch, msg),
    err_cb: (ch: channel, msg: string) => BuildOutput(generation, ch, msg),
    close_cb: (ch: channel) => BuildClosed(generation, ch),
    exit_cb: (process: job, status: number) => BuildExited(generation, process, status),
    stoponexit: 'term'})
  if job_status(buildJob) ==# 'fail'
    buildRunning = false
    buildExit = -1
    throw 'Vim could not start the build process'
  endif
  Changed()
enddef

def FinishSearch(generation: number)
  if generation != searchGeneration || !searchClosed || !searchExited
    return
  endif
  searchRunning = false
  if searchExit >= 0 && searchExit <= 1
    setqflist([], ' ', {title: 'Search: ' .. searchQuery, items: searchRows,
      context: {jterm_vim9: true, source: 'search', omitted: searchDropped}})
  else
    Send({event: 'error', error: 'Project search failed (exit ' .. searchExit .. '): '
      .. (empty(searchErrors) ? 'ripgrep returned an error' : join(searchErrors, ' '))})
  endif
  Changed()
enddef

def SearchOutput(generation: number, _: channel, message: string)
  if generation != searchGeneration
    return
  endif
  try
    var entry: dict<any> = json_decode(message)
    if get(entry, 'type', '') !=# 'match'
      return
    endif
    if len(searchRows) >= 256
      searchDropped += 1
      return
    endif
    var data: dict<any> = get(entry, 'data', {})
    var filename: string = get(get(data, 'path', {}), 'text', '')
    if empty(filename)
      searchDropped += 1
      return
    endif
    if filename !~# '^/'
      filename = fnamemodify(searchRoot .. '/' .. filename, ':p')
    endif
    var matches: list<dict<any>> = get(data, 'submatches', [])
    var column: number = empty(matches) ? 1 : get(matches[0], 'start', 0) + 1
    var text: string = get(get(data, 'lines', {}), 'text', '')
    add(searchRows, {filename: filename, lnum: get(data, 'line_number', 1),
      col: column, text: strcharpart(substitute(text, '[\r\n]\+$', '', ''), 0, 2048), type: 'I'})
  catch
    if len(searchErrors) < 8
      add(searchErrors, 'Could not decode an rg result: ' .. strcharpart(v:exception, 0, 256))
    endif
  endtry
enddef

def SearchError(generation: number, _: channel, message: string)
  if generation == searchGeneration && len(searchErrors) < 8
    add(searchErrors, strcharpart(message, 0, 1024))
  endif
enddef

def SearchClosed(generation: number, _: channel)
  if generation == searchGeneration
    searchClosed = true
    FinishSearch(generation)
  endif
enddef

def SearchExited(generation: number, _: job, status: number)
  if generation == searchGeneration
    searchExited = true
    searchExit = status
    FinishSearch(generation)
  endif
enddef

def SearchOptions(request: dict<any>): dict<any>
  var options: any = get(request, 'options', {})
  if type(options) != v:t_dict
    throw 'Project search options must be an object'
  endif
  var caseMode: any = get(options, 'case', 'smart')
  var regex: any = get(options, 'regex', false)
  var wholeWord: any = get(options, 'whole_word', false)
  var glob: any = get(options, 'glob', '')
  if type(caseMode) != v:t_string || index(['smart', 'sensitive', 'ignore'], caseMode) < 0
    throw 'Project search case must be smart, sensitive or ignore'
  endif
  if type(regex) != v:t_bool || type(wholeWord) != v:t_bool
    throw 'Project search regex and whole_word options must be Boolean'
  endif
  if type(glob) != v:t_string || strlen(glob) > 4096 || glob =~# '[\r\n]'
    throw 'Project search expects a single-line file glob of at most 4096 bytes'
  endif
  return {case: caseMode, regex: regex, whole_word: wholeWord, glob: glob}
enddef

def CancelSearch()
  if searchRunning
    # Invalidate callbacks before stopping the process. Neither a late success
    # nor partially collected rows can replace the previously visible list.
    searchGeneration += 1
    searchCancelled = true
    searchRunning = false
    searchExit = 130
    job_stop(searchJob)
    Changed()
  endif
enddef

def StartSearch(request: dict<any>)
  var query = RequiredString(request, 'query', 4096)
  var options = SearchOptions(request)
  if !executable('rg')
    throw 'Project search requires ripgrep (rg) on PATH'
  endif
  if query =~# '[\r\n]'
    throw 'Project search expects a single-line query'
  endif
  searchGeneration += 1
  const generation = searchGeneration
  if searchRunning
    job_stop(searchJob)
  endif
  searchQuery = query
  searchRoot = projectRoot
  searchRows = []
  searchErrors = []
  searchOptions = options
  searchCancelled = false
  searchDropped = 0
  searchExit = 0
  searchClosed = false
  searchExited = false
  searchRunning = true
  # Every option and query has its own argv boundary. A user ripgrep config
  # must not change the selected semantics, output framing or spawn a pre-tool.
  # Project ignore files still apply, with .git always excluded.
  var args = ['rg', '--no-config', '--json', '--line-number', '--column', '--color', 'never', '--hidden']
  if !options.regex
    add(args, '--fixed-strings')
  endif
  add(args, get({smart: '--smart-case', sensitive: '--case-sensitive', ignore: '--ignore-case'}, options.case))
  if options.whole_word
    add(args, '--word-regexp')
  endif
  if !empty(options.glob)
    extend(args, ['--glob', options.glob])
  endif
  extend(args, ['--glob', '!.git', '--', query, '.'])
  searchJob = job_start(args,
    {cwd: searchRoot, in_io: 'null', out_mode: 'nl', err_mode: 'nl', noblock: true,
      out_cb: (ch: channel, msg: string) => SearchOutput(generation, ch, msg),
      err_cb: (ch: channel, msg: string) => SearchError(generation, ch, msg),
      close_cb: (ch: channel) => SearchClosed(generation, ch),
      exit_cb: (process: job, status: number) => SearchExited(generation, process, status),
      stoponexit: 'term'})
  if job_status(searchJob) ==# 'fail'
    searchRunning = false
    searchExit = -1
    throw 'Vim could not start ripgrep'
  endif
  Changed()
enddef

def InvokeWorkbench(action: string)
  # Some real providers run getcharstr()/input() inside this channel callback.
  # They can prevent timer/channel callbacks from running until input arrives.
  # Retire the native overlay BEFORE entering that loop, and flush any batching
  # so the PTY popup is visible while the user is choosing. Timer paints must
  # not put the old overlay back during the provider's initial delay either.
  workbenchActionDepth += 1
  try
    EmitRender(true)
    FlushSendBatch()
    call('g:VimrcWorkbenchAction', [action])
  finally
    workbenchActionDepth -= 1
    renderWindowCaches = {}
    EmitRender(true)
    Changed()
  endtry
enddef

def LspAction(action: string, request: dict<any>)
  if index(WorkbenchCapabilities(), action) >= 0
    InvokeWorkbench(action)
    return
  endif
  var commands = {definition: 'LspGotoDefinition', hover: 'LspHover',
    references: 'LspShowReferences', rename: 'LspRename', format: 'LspFormat'}
  var command: string = get(commands, action, '')
  if action ==# 'definition' && exists(':' .. command) != 2
    var word = expand('<cword>')
    if empty(word)
      throw 'There is no symbol under the Vim cursor'
    endif
    execute 'tag ' .. fnameescape(word)
    return
  endif
  if empty(command) || exists(':' .. command) != 2
    throw 'This action needs a configured Vim LSP provider exposing :' .. command
  endif
  if action ==# 'rename'
    var name = RequiredString(request, 'name', 1024)
    if name =~# '[[:space:]|\r\n]'
      throw 'A symbol name must not contain whitespace or command separators'
    endif
    execute command .. ' ' .. fnameescape(name)
  else
    execute command
  endif
enddef

def RunWorkbench(request: dict<any>)
  var command = RequiredString(request, 'command', 64)
  if index(WORKBENCH_ACTIONS, command) < 0
    throw 'Unsupported workbench action: ' .. command
  endif
  var window = PositiveNumber(request, 'window')
  var buffer = PositiveNumber(request, 'buffer')
  var tick: any = get(request, 'changedtick', -1)
  if type(tick) != v:t_number || tick < 0
    throw 'Workbench actions require a valid source changedtick'
  endif
  if window != win_getid() || buffer != bufnr() || tick != b:changedtick
    throw 'The workbench source changed; reopen the command palette'
  endif
  # Older hosts omitted both coordinates. New requests bind every action to
  # the exact one-based Vim line/UTF-8 byte column observed at activation.
  if has_key(request, 'line') || has_key(request, 'column')
    var sourceLine: any = get(request, 'line', v:null)
    var sourceColumn: any = get(request, 'column', v:null)
    if type(sourceLine) != v:t_number || sourceLine <= 0
        || type(sourceColumn) != v:t_number || sourceColumn <= 0
      throw 'Workbench actions require a valid source cursor line and byte column'
    endif
    if sourceLine != line('.') || sourceColumn != col('.')
      throw 'The workbench source cursor changed; reopen the command palette'
    endif
  endif
  # Recheck after preceding queued requests and all mode/source checks. An
  # action removed by reload must never execute through stale picker metadata.
  if index(WorkbenchCapabilities(), command) < 0
    throw 'This workbench action is unavailable for the current buffer'
  endif
  InvokeWorkbench(command)
enddef

def ScrollWindow(request: dict<any>)
  SafeToChange()
  const window = PositiveNumber(request, 'window')
  const count: any = get(request, 'lines', 0)
  if type(count) != v:t_number || count == 0 || count < -120 || count > 120
    throw 'Scroll requires between 1 and 120 signed lines'
  endif
  # win_id2win() only accepts a window in the active tab. A delayed wheel event
  # must never move a closed split or silently scroll the currently focused one.
  if win_id2win(window) == 0 || !NativeTextBuffer(getwinvar(window, '&buftype'))
    throw 'The requested editor window is no longer available'
  endif
  # Numeric validation makes this a fixed command, not an Ex/eval interface.
  # win_execute preserves focus/cwd and avoids WinEnter/BufEnter side effects.
  const key = count > 0 ? "\<C-E>" : "\<C-Y>"
  win_execute(window, 'noautocmd keepjumps normal! ' .. abs(count) .. key)
  Changed()
enddef

def Dispatch(request: dict<any>, id: number)
  var action = RequiredString(request, 'action', 64)
  if action ==# 'set_render'
    var enabled: any = get(request, 'enabled', v:null)
    if type(enabled) != v:t_bool
      throw 'set_render requires a Boolean enabled value'
    endif
    renderEnabled = enabled
    if renderEnabled
      # Terminal Vim may retain GUI color names instead of resolving fg# to
      # hex. Use Vim's own customizable name table; never a terminal palette.
      runtime! colors/lists/default.vim
      RefreshRenderTheme()
      EmitRender(true)
    else
      previousRender = ''
      previousRenderLayout = ''
      previousRenderRows = {}
      renderBaseKey = ''
      renderBase = []
      renderWindowCaches = {}
      if renderTimer >= 0
        timer_stop(renderTimer)
        renderTimer = -1
      endif
      Send({event: 'render_disabled'})
    endif
  elseif action ==# 'render_resync'
    # Read-only recovery after a missing/invalid host paint baseline. Do not
    # feed input or touch Vim's undo, buffer, mode, selection or view state.
    EmitRender(true)
  elseif action ==# 'snapshot'
    EmitState(true)
    RefreshRenderTheme()
    EmitRender()
  elseif action ==# 'scroll'
    ScrollWindow(request)
  elseif action ==# 'scroll_view'
    ScrollSourceWindow(request, id)
    return  # The ordered response was included with the semantic ack.
  elseif action ==# 'pointer'
    SourcePointer(request)
  elseif action ==# 'build'
    StartBuild(request)
  elseif action ==# 'cancel_build'
    if buildRunning
      buildCancelled = true
      job_stop(buildJob)
    endif
  elseif action ==# 'search' || action ==# 'search_with_options'
    StartSearch(request)
  elseif action ==# 'cancel_search'
    CancelSearch()
  else
    SafeToChange()
    if action ==# 'open'
      var path = RequiredString(request, 'path')
      if path =~# '[\r\n]'
        throw 'Opening filenames containing newlines is not supported'
      endif
      var hasPosition = has_key(request, 'line') || has_key(request, 'column')
      var lineNumber = has_key(request, 'line') ? PositiveNumber(request, 'line') : 0
      var column = has_key(request, 'column') ? PositiveNumber(request, 'column') : 1
      # Use :buffer for an exact existing file, preserving its cursor and undo
      # state.  Avoid bufnr(path)'s pattern fallback for unusual file names.
      # Both commands retain Vim's unsaved-buffer protection and the user's
      # 'hidden', autocommands, swap handling and file hooks.
      var existing = -1
      var absolute = fnamemodify(path, ':p')
      for info in getbufinfo()
        if info.name ==# absolute && getbufvar(info.bufnr, '&buftype') ==# ''
          existing = info.bufnr
          break
        endif
      endfor
      # :buffer records cross-file jumps itself. An explicit location in the
      # already-current file also needs its origin on Vim's own jumplist.
      if existing == bufnr() && hasPosition
          && ((lineNumber > 0 && lineNumber != line('.')) || column != col('.'))
        normal! m'
      endif
      if existing > 0
        var previous = bufnr()
        execute 'buffer ' .. existing
        if !hasPosition && existing != previous
          RestoreView(existing)
        endif
      else
        execute 'edit ' .. fnameescape(path)
      endif
      if hasPosition
        cursor(lineNumber > 0 ? lineNumber : line('.'), column)
      endif
    elseif action ==# 'buffer'
      var number = PositiveNumber(request, 'buffer')
      if !bufexists(number)
        throw 'The requested Vim buffer no longer exists'
      endif
      var previous = bufnr()
      execute 'buffer ' .. number
      if number != previous
        RestoreView(number)
      endif
    elseif action ==# 'goto'
      var lineNumber = PositiveNumber(request, 'line', 0)
      var column = PositiveNumber(request, 'column')
      # Keep this in the current buffer, including unnamed/modified buffers.
      # Vim clamps out-of-range positions and keeps its byte-column convention.
      if lineNumber != line('.') || column != col('.')
        normal! m'
        cursor(lineNumber, column)
      endif
    elseif action ==# 'navigate_back' || action ==# 'navigate_forward'
      var navigation = Navigation()
      var backward = action ==# 'navigate_back'
      if !(backward ? navigation.can_go_back : navigation.can_go_forward)
        throw backward ? 'No earlier position in this Vim window' : 'No later position in this Vim window'
      endif
      # Ctrl-I is a tab byte, which :normal trims as leading whitespace.
      # An explicit count preserves it as a command rather than an empty Ex.
      execute backward ? "normal! 1\<C-O>" : "normal! 1\<C-I>"
    elseif action ==# 'next_buffer' || action ==# 'previous_buffer'
      var previous = bufnr()
      if action ==# 'next_buffer'
        bnext
      else
        bprevious
      endif
      if bufnr() != previous
        RestoreView(bufnr())
      endif
    elseif action ==# 'close_buffer' || action ==# 'close_current_buffer'
      # UI snapshots can lag queued navigation. Keyboard close must resolve
      # the target here; an explicit tab close retains its requested identity.
      var number = action ==# 'close_current_buffer' ? bufnr() : PositiveNumber(request, 'buffer', 0)
      if !bufexists(number) || !buflisted(number)
        throw 'The requested Vim buffer is no longer open'
      endif
      # Refuse modified buffers even when the user's hidden option is enabled.
      # Native close never means discard, and must not silently save either.
      if getbufvar(number, '&modified')
        throw 'Unsaved changes: save this buffer before closing it'
      endif
      if exists('*g:VimrcCloseBuffer')
        g:VimrcCloseBuffer(number)
      else
        # Keep generic Vim sessions' splits even without the user's provider.
        var replacement = filter(getbufinfo({buflisted: 1}), (_, b) => b.bufnr != number
          && index(['', 'acwrite'], getbufvar(b.bufnr, '&buftype')) >= 0)
        var other = empty(replacement) ? bufadd('') : replacement[0].bufnr
        setbufvar(other, '&buflisted', 1)
        for window in win_findbuf(number)
          win_execute(window, 'keepalt keepjumps buffer ' .. other)
        endfor
        execute 'bdelete ' .. number
      endif
    elseif action ==# 'reopen_buffer'
      if !exists('*g:VimrcReopenBuffer')
        throw 'Reopen is available with the Vimrc buffer workbench'
      endif
      g:VimrcReopenBuffer()
    elseif action ==# 'split'
      var vertical: any = get(request, 'vertical', v:null)
      if type(vertical) != v:t_bool
        throw 'split requires a Boolean vertical value'
      endif
      if vertical
        vsplit
      else
        split
      endif
    elseif action ==# 'save'
      if exists('*g:VimrcSave')
        g:VimrcSave()
      else
        update
      endif
    elseif action ==# 'save_all'
      if exists('*g:VimrcSaveAllWait')
        var saved = g:VimrcSaveAllWait(5000)
        if saved.status !=# 'success'
          throw saved.message
        endif
      else
        wall
      endif
    elseif action ==# 'save_and_build'
      # Validate before any write. :wall errors (including readonly/unnamed
      # buffers and failing write hooks) prevent StartBuild from being reached.
      var command = BuildCommand(request)
      if exists('*g:VimrcSaveAllWait')
        var saved = g:VimrcSaveAllWait(5000)
        if saved.status !=# 'success'
          throw saved.message
        endif
      else
        wall
      endif
      if !empty(filter(getbufinfo({buflisted: 1}), (_, info) => info.changed != 0))
        throw 'Some buffers remain modified; save them before building'
      endif
      StartBuild({command: command})
    elseif action ==# 'next_diagnostic'
      cnext
    elseif action ==# 'previous_diagnostic'
      cprevious
    elseif action ==# 'workbench'
      RunWorkbench(request)
    elseif index(['definition', 'hover', 'references', 'rename', 'format'], action) >= 0
      LspAction(action, request)
    elseif action ==# 'quit'
      pendingQuit = id
      qall
      return
    else
      throw 'Unsupported IDE action: ' .. action
    endif
    Changed()
  endif
  Reply(id, true)
enddef

def Receive(_: channel, message: string)
  var id = 0
  try
    if strlen(message) > 65536
      throw 'IDE request exceeds the 64 KiB limit'
    endif
    var request: dict<any> = json_decode(message)
    var requestId: any = get(request, 'id', 0)
    if type(requestId) != v:t_number || requestId < 0
      throw 'IDE request id must be a nonnegative integer'
    endif
    id = requestId
    if !authenticated
      if get(request, 'action', '') !=# 'auth'
        throw 'IDE authentication is required'
      endif
      var suppliedToken: any = get(request, 'token', '')
      var suppliedProtocol: any = get(request, 'protocol', 0)
      if type(suppliedToken) != v:t_string || suppliedToken !=# authToken
          || type(suppliedProtocol) != v:t_number || suppliedProtocol != 1
        Reply(id, false, 'IDE authentication failed')
        ch_close(bridge)
        return
      endif
      var requestedRender: any = get(request, 'render_protocol', 1)
      if type(requestedRender) != v:t_number || index([1, 2, 3, 4, 5, 6, 7, 8, 9], requestedRender) < 0
        throw 'Unsupported native render protocol'
      endif
      renderProtocol = requestedRender
      authenticated = true
      authToken = ''
      WorkbenchLifecycle(true)
      pollTimer = timer_start(750, Poll, {repeat: -1})
      EmitState(true)
      return
    endif
    if !DeferSaveIfNeeded(request, id)
      Dispatch(request, id)
    endif
  catch
    pendingQuit = 0
    Reply(id, false, v:exception)
  endtry
enddef

def Disconnected(_: channel)
  var wasConnected = authenticated
  authenticated = false
  if wasConnected
    WorkbenchLifecycle(false)
  endif
  ClearDeferredSave()
  if flushTimer >= 0
    timer_stop(flushTimer)
    flushTimer = -1
  endif
  if pollTimer >= 0
    timer_stop(pollTimer)
    pollTimer = -1
  endif
  if renderTimer >= 0
    timer_stop(renderTimer)
    renderTimer = -1
  endif
enddef

def Leaving()
  if authenticated
    WorkbenchLifecycle(false)
  endif
  ClearDeferredSave()
  if pendingQuit > 0
    Reply(pendingQuit, true)
  endif
  Send({event: 'bye'})
  # A nested shutdown must not strand a scroll's already-encoded messages.
  FlushSendBatch()
  shuttingDown = true
  if buildRunning
    job_stop(buildJob)
  endif
  if searchRunning
    job_stop(searchJob)
  endif
enddef

augroup JTermVim9Bridge
  autocmd!
  autocmd BufEnter,BufAdd,BufDelete,BufWritePost,FileType,WinEnter,TabEnter,DirChanged * Changed()
  autocmd BufLeave * RememberView()
  autocmd BufWipeout * ForgetView(str2nr(expand('<abuf>')))
  autocmd TextChanged,TextChangedI,TextChangedP,CursorMoved,CursorMovedI,ModeChanged * Changed()
  autocmd ModeChanged,ColorScheme * RenderThemeChanged()
  autocmd Syntax,FileType * InvalidateRender()
  # Stock Vim has no universal event for a plugin changing :syntax rules
  # asynchronously. Providers can explicitly invalidate after such updates.
  autocmd User JTermVim9RenderInvalidate InvalidateRender()
  autocmd User JTermVim9PopupChanged RenderChanged()
  autocmd User SimpleCCDecorationsChanged RenderChanged()
  autocmd WinScrolled,VimResized,OptionSet * RenderChanged()
  autocmd CompleteChanged,CompleteDone * RenderChanged()
  autocmd QuickFixCmdPost * Changed()
  autocmd User LspDiagsUpdated,LspAttached,LspDetached,SimpleCCDiagnosticsChanged,VimrcWorkbenchChanged LspDiagnosticsChanged()
  autocmd User SimpleGitUpdate,SimpleRemoteConnected,SimpleRemoteDisconnected,SimpleRemoteWorkspaceChanged Changed()
  autocmd User SimplePlugStateChanged Changed()
  autocmd VimLeavePre * Leaving()
augroup END

defcompile
bridge = ch_open(address, {mode: 'nl', callback: Receive, close_cb: Disconnected,
  waittime: 250, timeout: 0, noblock: true})
if ch_status(bridge) ==# 'open'
  Send({event: 'hello', token: authToken, protocol: 1, version: v:version,
    vim9: has('vim9script') != 0, pid: getpid()})
endif
