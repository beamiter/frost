//! Runtime owner for provider-native Agent sessions.
//!
//! [`TaskManager`] remains the authoritative lifecycle reducer. This module
//! owns the live provider adapters, drains their already-bounded event queues
//! with an additional frame budget, and retains the adapter's bounded view
//! after its worker has stopped. No method here waits for a running worker.

#[path = "runtime_remote.rs"]
mod remote;
use super::drivers::claude_stream_json::ClaudeStreamJsonDriver;
use super::drivers::codex_app_server::{
    CodexAppServerDriver, CodexAppServerExitCause, CodexAppServerExitReport, CodexAppServerPhase,
    CodexAppServerViewSnapshot,
};
use super::drivers::kimi_stream_json::KimiStreamJsonDriver;
use super::native::{
    build_native_follow_up_prompt, build_native_task_prompt, prepare_native_agent_workspace,
    NativePromptError, NativePromptPolicy, NativeWorkspaceError, PreparedNativeCodexHome,
    PreparedNativeWorkspace,
};
use super::{
    AgentCommand, AgentDriver, AgentDriverError, AgentEvent, AgentEventError, AgentEventStream,
    AgentLaunchError, AgentLaunchSpec, AgentPrompt, AgentProvider, AgentSessionOutcome,
    AgentStartRequest, AgentTask, ApprovalDecision, ApprovalId, NativeCodexHomeError, TaskId,
    TaskManager, TaskRuntimeKind, TaskStatus, TaskValidationStatus,
};
use std::collections::HashMap;
use std::fmt;
use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::mpsc::{self, Receiver, TryRecvError};
use std::sync::Arc;
use std::thread::JoinHandle;

/// Global event-work limit for one UI frame.
///
/// Driver events are independently capped at 64 KiB, so this also places a
/// conservative 4 MiB upper bound on provider event data inspected per frame.
pub const NATIVE_AGENT_EVENTS_PER_FRAME: usize = 64;
/// Prevent one noisy provider from consuming the whole global frame budget.
pub const NATIVE_AGENT_EVENTS_PER_TASK_PER_FRAME: usize = 16;
/// Bound simultaneous native preparations and live provider sessions.
/// Idle multi-turn sessions retain a process, cgroup, credential grant, and
/// pinned workspace, so they count against the same product-wide resource cap.
pub const NATIVE_AGENT_PREPARATIONS_MAX: usize = 8;

struct RunningCodexAgent {
    driver: NativeRunningDriver,
    /// Keeps Claude MVP workspace capabilities alive for the session. Codex
    /// ownership moves into the driver instead.
    #[allow(dead_code)]
    retained_workspace: Option<PreparedNativeWorkspace>,
    stream: AgentEventStream,
    worker_joined: bool,
    forced_failure: Option<String>,
    exit_report: Option<CodexAppServerExitReport>,
    pending_prompt: Option<super::AgentTurnId>,
    finish_requested: bool,
}

impl RunningCodexAgent {
    fn record_exit_report(
        &mut self,
        exit: CodexAppServerExitReport,
        report: &mut AgentRuntimePollReport,
    ) {
        if self.exit_report.is_some() {
            return;
        }
        if exit.process.spawned && !(exit.process.reaped && exit.process.containment_verified_empty)
        {
            let detail = bounded_runtime_detail(format!(
                "Native Agent cleanup could not be confirmed; task actions remain locked: {}",
                exit.detail
                    .as_deref()
                    .unwrap_or("provider stop evidence is incomplete")
            ));
            self.forced_failure.get_or_insert_with(|| detail.clone());
            report.issues.push(AgentRuntimeIssue {
                task_id: self.stream.task_id(),
                detail,
            });
        }
        self.exit_report = Some(exit);
    }
}

enum NativeRunningDriver {
    Codex(Box<CodexAppServerDriver>),
    Claude(ClaudeStreamJsonDriver),
    Kimi(KimiStreamJsonDriver),
}

impl NativeRunningDriver {
    fn try_next_event(&mut self) -> Result<Option<AgentEvent>, AgentDriverError> {
        match self {
            Self::Codex(driver) => driver.try_next_event(),
            Self::Claude(driver) => driver.try_next_event(),
            Self::Kimi(driver) => driver.try_next_event(),
        }
    }

    fn cancel(&mut self) {
        match self {
            Self::Codex(driver) => driver.cancel(),
            Self::Claude(driver) => driver.cancel(),
            Self::Kimi(driver) => driver.cancel(),
        }
    }

    fn worker_is_finished(&self) -> bool {
        match self {
            Self::Codex(driver) => driver.worker_is_finished(),
            Self::Claude(driver) => driver.worker_is_finished(),
            Self::Kimi(driver) => driver.worker_is_finished(),
        }
    }

    fn join_finished_worker(&mut self) -> Result<bool, AgentDriverError> {
        match self {
            Self::Codex(driver) => driver.join_finished_worker(),
            Self::Claude(driver) => driver.join_finished_worker(),
            Self::Kimi(driver) => driver.join_finished_worker(),
        }
    }

    fn take_exit_report(&self) -> Option<CodexAppServerExitReport> {
        match self {
            Self::Codex(driver) => driver.take_exit_report(),
            Self::Claude(driver) => driver.take_exit_report(),
            Self::Kimi(driver) => driver.take_exit_report(),
        }
    }

    fn view_snapshot(&self) -> CodexAppServerViewSnapshot {
        match self {
            Self::Codex(driver) => driver.view_snapshot(),
            Self::Claude(driver) => driver.view_snapshot(),
            Self::Kimi(driver) => driver.view_snapshot(),
        }
    }

    fn view_revision(&self) -> u64 {
        match self {
            Self::Codex(driver) => driver.view_revision(),
            Self::Claude(driver) => driver.view_revision(),
            Self::Kimi(driver) => driver.view_revision(),
        }
    }

    fn view_snapshot_with_revision(&self) -> (u64, CodexAppServerViewSnapshot) {
        match self {
            Self::Codex(driver) => driver.view_snapshot_with_revision(),
            Self::Claude(driver) => driver.view_snapshot_with_revision(),
            Self::Kimi(driver) => driver.view_snapshot_with_revision(),
        }
    }

    fn phase(&self) -> CodexAppServerPhase {
        match self {
            Self::Codex(driver) => driver.phase(),
            Self::Claude(driver) => driver.phase(),
            Self::Kimi(driver) => driver.phase(),
        }
    }

    fn send(&mut self, command: AgentCommand) -> Result<(), AgentDriverError> {
        match self {
            Self::Codex(driver) => driver.send(command),
            Self::Claude(driver) => driver.send(command),
            Self::Kimi(driver) => driver.send(command),
        }
    }
}

enum PreparedNativeStart {
    Codex(PreparedCodexStart),
    Claude(PreparedClaudeStart),
    Kimi(PreparedKimiStart),
}

struct PreparedCodexStart {
    task: AgentTask,
    workspace: PreparedNativeWorkspace,
    prompt: Option<AgentPrompt>,
    launch_argv: Vec<String>,
    native_home: PreparedNativeCodexHome,
}

struct PreparedClaudeStart {
    task: AgentTask,
    #[allow(dead_code)] // retained for future Claude containment parity with Codex
    workspace: PreparedNativeWorkspace,
    prompt: AgentPrompt,
    launch_argv: Vec<String>,
}

struct PreparedKimiStart {
    task: AgentTask,
    #[allow(dead_code)] // retained for future Kimi containment parity with Codex
    workspace: PreparedNativeWorkspace,
    prompt: AgentPrompt,
    launch_argv: Vec<String>,
}

struct PreparationResult {
    generation: u64,
    result: Result<PreparedNativeStart, AgentRuntimeError>,
}

struct RetainedCodexAgent {
    view: Arc<CodexAppServerViewSnapshot>,
    /// Revision of the final live view; retained content never changes.
    view_revision: u64,
    exit_report: Option<CodexAppServerExitReport>,
    effective_outcome: AgentSessionOutcome,
}

struct PendingCodexPreparation {
    generation: u64,
    policy: NativePromptPolicy,
    receiver: Receiver<PreparationResult>,
    cancel: Arc<AtomicBool>,
    worker: Option<JoinHandle<()>>,
}

/// Process-local owner of native provider adapters and their bounded UI views.
///
/// Runtime instances are deliberately not serialized. Stable task metadata is
/// owned by [`TaskManager`]; provider workers and descriptor capabilities must
/// be recreated explicitly after process restart.
#[derive(Default)]
pub struct AgentRuntimeManager {
    remote: Option<Box<remote::NativeRemote>>,
    host_context: Option<crate::agent_workspace::NativeLaunchContext>,
    execution_lease: Option<Arc<crate::agent_workspace::NativeSessionLease>>,
    native_codex_homes: HashMap<TaskId, std::path::PathBuf>,
    explicit_codex_restores: std::collections::HashSet<TaskId>,
    preparing: HashMap<TaskId, PendingCodexPreparation>,
    cancelled_preparations: Vec<PendingCodexPreparation>,
    running: HashMap<TaskId, RunningCodexAgent>,
    retained: HashMap<TaskId, RetainedCodexAgent>,
    next_preparation_generation: u64,
    next_poll_index: usize,
    /// Latest shared live snapshot per task, keyed by view revision. Hosts
    /// that render every frame reuse it until the provider view changes.
    shared_snapshots: parking_lot::Mutex<HashMap<TaskId, (u64, Arc<CodexAppServerViewSnapshot>)>>,
}

#[derive(Debug)]
pub enum AgentRuntimeError {
    UnknownTask(TaskId),
    AlreadyRunning(TaskId),
    NotRunning(TaskId),
    UnsupportedProvider {
        task_id: TaskId,
        provider: AgentProvider,
    },
    Workspace(NativeWorkspaceError),
    Prompt(NativePromptError),
    NativeHome(NativeCodexHomeError),
    Launch(AgentLaunchError),
    Driver(AgentDriverError),
    Event(AgentEventError),
    Preparation(String),
    StartRollback {
        start: Box<AgentRuntimeError>,
        rollback: AgentEventError,
    },
}

impl fmt::Display for AgentRuntimeError {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::UnknownTask(task_id) => write!(formatter, "Agent task {task_id} is unavailable"),
            Self::AlreadyRunning(task_id) => {
                write!(
                    formatter,
                    "native Agent task {task_id} is already preparing or running"
                )
            }
            Self::NotRunning(task_id) => {
                write!(
                    formatter,
                    "native Agent task {task_id} is not preparing or running"
                )
            }
            Self::UnsupportedProvider { task_id, provider } => write!(
                formatter,
                "native Agent task {task_id} uses unsupported provider {}",
                provider.display_name()
            ),
            Self::Workspace(error) => error.fmt(formatter),
            Self::Prompt(error) => error.fmt(formatter),
            Self::NativeHome(error) => error.fmt(formatter),
            Self::Launch(error) => error.fmt(formatter),
            Self::Driver(error) => error.fmt(formatter),
            Self::Event(error) => error.fmt(formatter),
            Self::Preparation(detail) => {
                write!(formatter, "native Agent preparation failed: {detail}")
            }
            Self::StartRollback { start, rollback } => write!(
                formatter,
                "{start}; native stream rollback also failed: {rollback}"
            ),
        }
    }
}

impl std::error::Error for AgentRuntimeError {
    fn source(&self) -> Option<&(dyn std::error::Error + 'static)> {
        match self {
            Self::Workspace(error) => Some(error),
            Self::Prompt(error) => Some(error),
            Self::NativeHome(error) => Some(error),
            Self::Launch(error) => Some(error),
            Self::Driver(error) => Some(error),
            Self::Event(error) => Some(error),
            Self::StartRollback { start, .. } => Some(start.as_ref()),
            Self::UnknownTask(_)
            | Self::AlreadyRunning(_)
            | Self::NotRunning(_)
            | Self::Preparation(_)
            | Self::UnsupportedProvider { .. } => None,
        }
    }
}

impl From<NativeWorkspaceError> for AgentRuntimeError {
    fn from(error: NativeWorkspaceError) -> Self {
        Self::Workspace(error)
    }
}

impl From<NativePromptError> for AgentRuntimeError {
    fn from(error: NativePromptError) -> Self {
        Self::Prompt(error)
    }
}

impl From<NativeCodexHomeError> for AgentRuntimeError {
    fn from(error: NativeCodexHomeError) -> Self {
        Self::NativeHome(error)
    }
}

impl From<AgentLaunchError> for AgentRuntimeError {
    fn from(error: AgentLaunchError) -> Self {
        Self::Launch(error)
    }
}

impl From<AgentDriverError> for AgentRuntimeError {
    fn from(error: AgentDriverError) -> Self {
        Self::Driver(error)
    }
}

impl From<AgentEventError> for AgentRuntimeError {
    fn from(error: AgentEventError) -> Self {
        Self::Event(error)
    }
}

#[derive(Clone, Debug)]
pub struct NativePromptOutcome {
    pub task_id: TaskId,
    pub receipt: String,
    pub result: Result<(), String>,
}

#[derive(Clone, Debug, PartialEq, Eq, serde::Serialize, serde::Deserialize)]
pub struct AgentRuntimeIssue {
    pub task_id: TaskId,
    pub detail: String,
}

/// Lightweight turn boundary from an event accepted by TaskManager. Unlike
/// the asynchronous presentation snapshot, this identity is aligned with the
/// reducer's applied status. No prompt, output, provider ID or error is copied.
#[derive(Clone, Copy, Debug, PartialEq, Eq, serde::Serialize, serde::Deserialize)]
pub struct AppliedAgentTurn {
    pub task_id: TaskId,
    pub epoch: super::AgentEventEpoch,
    pub turn_id: super::AgentTurnId,
    pub completed: bool,
    pub status: TaskStatus,
}

#[derive(Clone, Debug, Default, PartialEq, Eq, serde::Serialize, serde::Deserialize)]
pub struct AgentRuntimePollReport {
    pub preparations_finished: usize,
    pub preparations_started: usize,
    pub events_drained: usize,
    pub events_applied: usize,
    /// Ordered accepted TurnStarted/TurnCompleted boundaries only. At most
    /// NATIVE_AGENT_EVENTS_PER_FRAME entries; token events allocate nothing.
    pub applied_turns: Vec<AppliedAgentTurn>,
    pub workers_finished: usize,
    pub budget_exhausted: bool,
    pub issues: Vec<AgentRuntimeIssue>,
    pub completions: Vec<AgentRuntimeCompletion>,
}

impl AgentRuntimePollReport {
    fn apply_event(
        &mut self,
        tasks: &mut TaskManager,
        event: AgentEvent,
    ) -> Result<TaskStatus, AgentEventError> {
        let boundary = match event.kind() {
            super::AgentEventKind::TurnStarted { turn_id } => Some((*turn_id, false)),
            super::AgentEventKind::TurnCompleted { turn_id } => Some((*turn_id, true)),
            _ => None,
        };
        let task_id = event.stream().task_id();
        let epoch = event.stream().epoch();
        let status = tasks.apply_agent_event(event)?;
        self.events_applied += 1;
        if let Some((turn_id, completed)) = boundary {
            self.applied_turns.push(AppliedAgentTurn {
                task_id,
                epoch,
                turn_id,
                completed,
                status,
            });
        }
        Ok(status)
    }

    pub fn made_progress(&self) -> bool {
        self.preparations_finished > 0
            || self.preparations_started > 0
            || self.events_drained > 0
            || self.workers_finished > 0
            || !self.issues.is_empty()
    }
}

#[derive(Clone, Debug, PartialEq, Eq, serde::Serialize, serde::Deserialize)]
pub struct AgentRuntimeCompletion {
    pub task_id: TaskId,
    pub outcome: AgentSessionOutcome,
    pub cause: CodexAppServerExitCause,
    pub detail: Option<String>,
}

impl AgentRuntimeManager {
    pub fn new() -> Self {
        Self::default()
    }
    /// A native view whose provider processes are owned by jterm-sessiond.
    pub fn hosted(namespace: impl Into<String>) -> Self {
        let mut runtime = Self::default();
        runtime.remote = Some(Box::new(remote::NativeRemote::new(namespace.into())));
        runtime
    }
    pub fn hosted_with_client(
        namespace: impl Into<String>,
        client: crate::agent_workspace::WorkspaceClient,
    ) -> Self {
        let mut runtime = Self::default();
        runtime.remote = Some(Box::new(remote::NativeRemote::with_client(
            namespace.into(),
            client,
        )));
        runtime
    }
    pub fn needs_host_poll(&self) -> bool {
        self.remote.is_some()
    }
    /// Latest host-owned catalog facts, without acquiring control or starting
    /// execution. Prefer this to reconstructing lifecycle from rendered text.
    pub fn workspace_row(&self, task_id: TaskId) -> Option<crate::agent_workspace::WorkspaceRow> {
        self.remote
            .as_ref()?
            .state(task_id)
            .map(|snapshot| snapshot.row())
    }
    pub fn conversation_id(
        &self,
        task_id: TaskId,
    ) -> Option<&crate::agent_workspace::ConversationId> {
        self.remote.as_ref()?.state(task_id).map(|s| &s.id)
    }
    pub fn detach_view(&mut self, task_id: TaskId) {
        if let Some(remote) = &mut self.remote {
            remote.detach(task_id);
        }
    }
    pub fn select_hosted_view(&mut self, selected: Option<TaskId>) {
        if let Some(remote) = &mut self.remote {
            remote.select_view(selected);
        }
    }
    pub fn take_terminal_handoffs(&mut self) -> Vec<(TaskId, crate::agent_sessions::AgentSession)> {
        self.remote
            .as_mut()
            .map(|r| r.take_handoffs())
            .unwrap_or_default()
    }
    /// Request an explicit validation in the host. Success here means queued;
    /// the accepted task snapshot and terminal descriptor arrive through poll.
    pub fn hosted_manual_review(&self, id: TaskId) -> Option<bool> {
        self.remote
            .as_ref()?
            .state(id)
            .map(|state| state.manual_review)
    }
    pub fn can_start_hosted_validation(&self, id: TaskId) -> bool {
        self.remote
            .as_ref()
            .and_then(|remote| remote.state(id))
            .is_some_and(|state| state.can_start_validation)
    }
    pub fn start_hosted_validation(&mut self, id: TaskId) -> Result<(), AgentRuntimeError> {
        self.remote
            .as_mut()
            .ok_or_else(|| AgentRuntimeError::Preparation("This task is not hosted".into()))?
            .start_validation(id)
    }
    pub fn mutate_hosted_task(
        &mut self,
        id: TaskId,
        mutation: crate::agent_workspace::NativeTaskMutation,
    ) -> Result<(), AgentRuntimeError> {
        self.remote
            .as_mut()
            .ok_or_else(|| AgentRuntimeError::Preparation("This task is not hosted".into()))?
            .mutate_task(id, mutation)
    }
    pub fn take_owned_terminal_launches(
        &mut self,
    ) -> Vec<(TaskId, crate::agent_workspace::OwnedTerminalDescriptor)> {
        self.remote
            .as_mut()
            .map(|r| r.take_owned_launches())
            .unwrap_or_default()
    }
    pub fn hosted_validation_terminal(
        &self,
        id: TaskId,
    ) -> Option<&crate::agent_workspace::OwnedTerminalDescriptor> {
        self.hosted_validation_snapshot(id)?.terminal.as_ref()
    }
    /// Bounded, policy-redacted validation output remains readable after its
    /// PTY view detaches or the persistent host restarts.
    pub fn hosted_validation_snapshot(
        &self,
        id: TaskId,
    ) -> Option<&crate::agent_workspace::HostedValidationSnapshot> {
        self.remote.as_ref()?.state(id)?.validation.as_ref()
    }
    pub fn handoff_to_terminal(&mut self, task_id: TaskId) -> Result<(), AgentRuntimeError> {
        let remote = self
            .remote
            .as_mut()
            .ok_or_else(|| AgentRuntimeError::Preparation("This runtime is not hosted".into()))?;
        let provider = remote
            .state(task_id)
            .ok_or(AgentRuntimeError::UnknownTask(task_id))?
            .task
            .provider;
        let context = crate::agent_workspace::NativeLaunchContext::capture(provider)
            .map_err(AgentRuntimeError::Preparation)?;
        remote.action(
            task_id,
            crate::agent_workspace::NativeAction::Handoff { context },
        )
    }
    pub fn hosted_terminal(&self, task_id: TaskId) -> Option<&crate::agent_sessions::AgentSession> {
        self.remote.as_ref()?.state(task_id)?.terminal.as_ref()
    }

    /// Register an explicit historical restore after the host reacquired the
    /// task kernel lease. Preparation still verifies profile provenance and
    /// resumes its exact thread with no initial prompt.
    pub(crate) fn restore_hosted_codex(
        &mut self,
        id: TaskId,
        path: std::path::PathBuf,
        mut view: CodexAppServerViewSnapshot,
    ) {
        view.pending_approvals.clear();
        view.history_loading = false;
        self.native_codex_homes.insert(id, path);
        self.explicit_codex_restores.insert(id);
        self.retained.insert(
            id,
            RetainedCodexAgent {
                view: Arc::new(view),
                view_revision: 1,
                exit_report: None,
                effective_outcome: AgentSessionOutcome::Failed,
            },
        );
    }
    pub(crate) fn configure_host(
        &mut self,
        context: crate::agent_workspace::NativeLaunchContext,
        lease: Arc<crate::agent_workspace::NativeSessionLease>,
    ) {
        self.host_context = Some(context);
        self.execution_lease = Some(lease);
    }
    pub(crate) fn native_home(&self, task_id: TaskId) -> Option<&std::path::Path> {
        self.native_codex_homes.get(&task_id).map(|p| p.as_path())
    }

    /// Begin preparing a real Codex app-server session without blocking the UI.
    ///
    /// Workspace identity, prompt consent, launcher trust, and the private
    /// Codex home are resolved on a background worker. The task remains
    /// Created/Unassigned until [`Self::poll`] receives the matching generation,
    /// rechecks the immutable task snapshot, and atomically selects native
    /// authority. Dropping a cancelled/stale receiver drops every prepared FD,
    /// credential buffer, and private directory when the worker finishes.
    pub fn start_codex(
        &mut self,
        task_manager: &mut TaskManager,
        task_id: TaskId,
        policy: NativePromptPolicy,
    ) -> Result<(), AgentRuntimeError> {
        if let Some(remote) = &mut self.remote {
            return remote.start(task_manager, task_id, policy);
        }
        if self.running.contains_key(&task_id) || self.preparing.contains_key(&task_id) {
            return Err(AgentRuntimeError::AlreadyRunning(task_id));
        }
        self.reap_cancelled_preparations();
        if self
            .preparing
            .len()
            .saturating_add(self.cancelled_preparations.len())
            .saturating_add(self.running.len())
            >= NATIVE_AGENT_PREPARATIONS_MAX
        {
            return Err(AgentRuntimeError::Preparation(format!(
                "at most {NATIVE_AGENT_PREPARATIONS_MAX} native tasks may prepare or remain live concurrently"
            )));
        }
        let task = task_manager
            .get(task_id)
            .cloned()
            .ok_or(AgentRuntimeError::UnknownTask(task_id))?;
        if task.provider != AgentProvider::Codex {
            return Err(AgentRuntimeError::UnsupportedProvider {
                task_id,
                provider: task.provider,
            });
        }
        if !policy.share_command_context {
            return Err(AgentRuntimeError::Prompt(
                NativePromptError::SharingDisabled,
            ));
        }
        let resume_home = self
            .can_resume_codex(task_id)
            .then(|| self.native_codex_homes.get(&task_id).cloned())
            .flatten();
        let resume = resume_home.is_some()
            && task.status == TaskStatus::ReadyForReview
            && task.runtime_kind == TaskRuntimeKind::Native;
        if (!resume
            && (task.status != TaskStatus::Created
                || task.runtime_kind != TaskRuntimeKind::Unassigned))
            || task.terminal_session_id.is_some()
            || task.validation.status == TaskValidationStatus::Running
            || task_manager.has_active_agent_event_stream(task_id)
        {
            return Err(AgentRuntimeError::Preparation(format!(
                "task must remain Created and unassigned (currently {} / {:?})",
                task.status.label(),
                task.runtime_kind
            )));
        }

        let generation = self
            .next_preparation_generation
            .checked_add(1)
            .ok_or_else(|| AgentRuntimeError::Preparation("generation counter exhausted".into()))?;
        let (sender, receiver) = mpsc::sync_channel(1);
        let cancel = Arc::new(AtomicBool::new(false));
        let worker_cancel = Arc::clone(&cancel);
        let context = self.host_context.clone();
        let execution_lease = self.execution_lease.clone();
        let worker = std::thread::Builder::new()
            .name(format!(
                "{}-codex-prepare-{task_id}-{generation}",
                crate::agent_task::app_slug()
            ))
            .spawn(move || {
                let result = prepare_codex_start(
                    task,
                    policy,
                    worker_cancel,
                    resume_home,
                    context,
                    execution_lease,
                );
                let _ = sender.send(PreparationResult { generation, result });
            })
            .map_err(|error| {
                AgentRuntimeError::Preparation(format!(
                    "could not start background preparation worker: {error}"
                ))
            })?;
        self.next_preparation_generation = generation;
        self.preparing.insert(
            task_id,
            PendingCodexPreparation {
                generation,
                policy,
                receiver,
                cancel,
                worker: Some(worker),
            },
        );
        Ok(())
    }

    fn start_prepared_codex(
        &mut self,
        task_manager: &mut TaskManager,
        prepared: PreparedCodexStart,
    ) -> Result<(), AgentRuntimeError> {
        let task_id = prepared.task.id;
        let current = task_manager
            .get(task_id)
            .ok_or(AgentRuntimeError::UnknownTask(task_id))?;
        if current != &prepared.task {
            return Err(AgentRuntimeError::Preparation(
                "task changed while native prerequisites were being prepared".into(),
            ));
        }
        let resume_from = prepared.native_home.resume_thread().cloned();
        let stream = if resume_from.is_some() {
            task_manager.resume_agent_event_stream_after_stop(task_id)?
        } else {
            task_manager.start_agent_event_stream(task_id)?
        };
        let native_home_path = prepared.native_home.path().to_path_buf();
        let worktree_path = prepared.task.worktree_path;
        let mut driver = CodexAppServerDriver::new(
            prepared.launch_argv,
            prepared.workspace,
            prepared.native_home,
        );
        let request = AgentStartRequest {
            provider: AgentProvider::Codex,
            stream: stream.clone(),
            worktree_path,
            // The prompt contains the policy-approved, redacted evidence. Do
            // not also hand the adapter the raw semantic snapshot.
            source_context: None,
            initial_prompt: prepared.prompt,
            resume_from: resume_from.clone(),
        };
        if let Err(error) = driver.start(request) {
            // CodexAppServerDriver::start has a strict pre-spawn error
            // contract: once it has created a worker it returns Ok and reports
            // every later spawn/protocol/process failure asynchronously. That
            // makes this stopped-runtime rollback authoritative.
            driver.cancel();
            if resume_from.is_some() {
                let _ = task_manager.finish_agent_event_stream_after_stop(
                    &stream,
                    AgentSessionOutcome::Failed,
                    Some(error.to_string()),
                );
                return Err(AgentRuntimeError::Driver(error));
            }
            return Err(rollback_failed_start(
                task_manager,
                &stream,
                AgentRuntimeError::Driver(error),
            ));
        }

        self.retained.remove(&task_id);
        self.explicit_codex_restores.remove(&task_id);
        self.native_codex_homes.insert(task_id, native_home_path);
        self.running.insert(
            task_id,
            RunningCodexAgent {
                driver: NativeRunningDriver::Codex(Box::new(driver)),
                retained_workspace: None,
                stream,
                worker_joined: false,
                forced_failure: None,
                exit_report: None,
                pending_prompt: None,
                finish_requested: false,
            },
        );
        Ok(())
    }

    /// Begin preparing a Claude Code print/stream-json session without blocking.
    ///
    /// Each turn uses an exact provider ID in the pinned profile. Between
    /// turns, the worker retains its session lease while all tool processes
    /// are stopped. Tool permission prompts require the interactive PTY path.
    pub fn start_claude(
        &mut self,
        task_manager: &mut TaskManager,
        task_id: TaskId,
        policy: NativePromptPolicy,
    ) -> Result<(), AgentRuntimeError> {
        if let Some(remote) = &mut self.remote {
            return remote.start(task_manager, task_id, policy);
        }
        if self.running.contains_key(&task_id) || self.preparing.contains_key(&task_id) {
            return Err(AgentRuntimeError::AlreadyRunning(task_id));
        }
        self.reap_cancelled_preparations();
        if self
            .preparing
            .len()
            .saturating_add(self.cancelled_preparations.len())
            .saturating_add(self.running.len())
            >= NATIVE_AGENT_PREPARATIONS_MAX
        {
            return Err(AgentRuntimeError::Preparation(format!(
                "at most {NATIVE_AGENT_PREPARATIONS_MAX} native tasks may prepare or remain live concurrently"
            )));
        }
        let task = task_manager
            .get(task_id)
            .cloned()
            .ok_or(AgentRuntimeError::UnknownTask(task_id))?;
        if task.provider != AgentProvider::Claude {
            return Err(AgentRuntimeError::UnsupportedProvider {
                task_id,
                provider: task.provider,
            });
        }
        if !policy.share_command_context {
            return Err(AgentRuntimeError::Prompt(
                NativePromptError::SharingDisabled,
            ));
        }
        if task.status != TaskStatus::Created
            || task.runtime_kind != TaskRuntimeKind::Unassigned
            || task.terminal_session_id.is_some()
            || task.validation.status == TaskValidationStatus::Running
            || task_manager.has_active_agent_event_stream(task_id)
        {
            return Err(AgentRuntimeError::Preparation(format!(
                "task must remain Created and unassigned (currently {} / {:?})",
                task.status.label(),
                task.runtime_kind
            )));
        }

        let generation = self
            .next_preparation_generation
            .checked_add(1)
            .ok_or_else(|| AgentRuntimeError::Preparation("generation counter exhausted".into()))?;
        let (sender, receiver) = mpsc::sync_channel(1);
        let cancel = Arc::new(AtomicBool::new(false));
        let worker_cancel = Arc::clone(&cancel);
        let context = self.host_context.clone();
        let worker = std::thread::Builder::new()
            .name(format!(
                "{}-claude-prepare-{task_id}-{generation}",
                crate::agent_task::app_slug()
            ))
            .spawn(move || {
                let result = prepare_claude_start(task, policy, worker_cancel, context);
                let _ = sender.send(PreparationResult { generation, result });
            })
            .map_err(|error| {
                AgentRuntimeError::Preparation(format!(
                    "could not start background preparation worker: {error}"
                ))
            })?;
        self.next_preparation_generation = generation;
        self.preparing.insert(
            task_id,
            PendingCodexPreparation {
                generation,
                policy,
                receiver,
                cancel,
                worker: Some(worker),
            },
        );
        Ok(())
    }

    fn start_prepared_claude(
        &mut self,
        task_manager: &mut TaskManager,
        prepared: PreparedClaudeStart,
    ) -> Result<(), AgentRuntimeError> {
        let task_id = prepared.task.id;
        let current = task_manager
            .get(task_id)
            .ok_or(AgentRuntimeError::UnknownTask(task_id))?;
        if current != &prepared.task {
            return Err(AgentRuntimeError::Preparation(
                "task changed while native prerequisites were being prepared".into(),
            ));
        }
        let stream = task_manager.start_agent_event_stream(task_id)?;
        let worktree_path = prepared.task.worktree_path.clone();
        let mut driver =
            ClaudeStreamJsonDriver::new_conversation(prepared.launch_argv, worktree_path.clone());
        if let (Some(context), Some(lease)) = (&self.host_context, &self.execution_lease) {
            driver.configure_host(context.clone(), lease.clone());
        }
        let request = AgentStartRequest {
            provider: AgentProvider::Claude,
            stream: stream.clone(),
            worktree_path,
            source_context: None,
            initial_prompt: Some(prepared.prompt),
            resume_from: None,
        };
        if let Err(error) = driver.start(request) {
            driver.cancel();
            return Err(rollback_failed_start(
                task_manager,
                &stream,
                AgentRuntimeError::Driver(error),
            ));
        }

        self.retained.remove(&task_id);
        self.running.insert(
            task_id,
            RunningCodexAgent {
                driver: NativeRunningDriver::Claude(driver),
                retained_workspace: Some(prepared.workspace),
                stream,
                worker_joined: false,
                forced_failure: None,
                exit_report: None,
                pending_prompt: None,
                finish_requested: false,
            },
        );
        Ok(())
    }

    /// Begin preparing a Kimi Code print/stream-json session without blocking.
    ///
    /// Like Claude, this MVP skips private home and cgroup containment. Prefer
    /// the opaque PTY path when stronger isolation is required.
    pub fn start_kimi(
        &mut self,
        task_manager: &mut TaskManager,
        task_id: TaskId,
        policy: NativePromptPolicy,
    ) -> Result<(), AgentRuntimeError> {
        if let Some(remote) = &mut self.remote {
            return remote.start(task_manager, task_id, policy);
        }
        if self.running.contains_key(&task_id) || self.preparing.contains_key(&task_id) {
            return Err(AgentRuntimeError::AlreadyRunning(task_id));
        }
        self.reap_cancelled_preparations();
        if self
            .preparing
            .len()
            .saturating_add(self.cancelled_preparations.len())
            .saturating_add(self.running.len())
            >= NATIVE_AGENT_PREPARATIONS_MAX
        {
            return Err(AgentRuntimeError::Preparation(format!(
                "at most {NATIVE_AGENT_PREPARATIONS_MAX} native tasks may prepare or remain live concurrently"
            )));
        }
        let task = task_manager
            .get(task_id)
            .cloned()
            .ok_or(AgentRuntimeError::UnknownTask(task_id))?;
        if task.provider != AgentProvider::Kimi {
            return Err(AgentRuntimeError::UnsupportedProvider {
                task_id,
                provider: task.provider,
            });
        }
        if !policy.share_command_context {
            return Err(AgentRuntimeError::Prompt(
                NativePromptError::SharingDisabled,
            ));
        }
        if task.status != TaskStatus::Created
            || task.runtime_kind != TaskRuntimeKind::Unassigned
            || task.terminal_session_id.is_some()
            || task.validation.status == TaskValidationStatus::Running
            || task_manager.has_active_agent_event_stream(task_id)
        {
            return Err(AgentRuntimeError::Preparation(format!(
                "task must remain Created and unassigned (currently {} / {:?})",
                task.status.label(),
                task.runtime_kind
            )));
        }

        let generation = self
            .next_preparation_generation
            .checked_add(1)
            .ok_or_else(|| AgentRuntimeError::Preparation("generation counter exhausted".into()))?;
        let (sender, receiver) = mpsc::sync_channel(1);
        let cancel = Arc::new(AtomicBool::new(false));
        let worker_cancel = Arc::clone(&cancel);
        let context = self.host_context.clone();
        let worker = std::thread::Builder::new()
            .name(format!(
                "{}-kimi-prepare-{task_id}-{generation}",
                crate::agent_task::app_slug()
            ))
            .spawn(move || {
                let result = prepare_kimi_start(task, policy, worker_cancel, context);
                let _ = sender.send(PreparationResult { generation, result });
            })
            .map_err(|error| {
                AgentRuntimeError::Preparation(format!(
                    "could not start background preparation worker: {error}"
                ))
            })?;
        self.next_preparation_generation = generation;
        self.preparing.insert(
            task_id,
            PendingCodexPreparation {
                generation,
                policy,
                receiver,
                cancel,
                worker: Some(worker),
            },
        );
        Ok(())
    }

    fn start_prepared_kimi(
        &mut self,
        task_manager: &mut TaskManager,
        prepared: PreparedKimiStart,
    ) -> Result<(), AgentRuntimeError> {
        let task_id = prepared.task.id;
        let current = task_manager
            .get(task_id)
            .ok_or(AgentRuntimeError::UnknownTask(task_id))?;
        if current != &prepared.task {
            return Err(AgentRuntimeError::Preparation(
                "task changed while native prerequisites were being prepared".into(),
            ));
        }
        let stream = task_manager.start_agent_event_stream(task_id)?;
        let worktree_path = prepared.task.worktree_path.clone();
        let mut driver = KimiStreamJsonDriver::new(prepared.launch_argv, worktree_path.clone());
        if let (Some(context), Some(lease)) = (&self.host_context, &self.execution_lease) {
            driver.configure_host(context.clone(), lease.clone());
        }
        let request = AgentStartRequest {
            provider: AgentProvider::Kimi,
            stream: stream.clone(),
            worktree_path,
            source_context: None,
            initial_prompt: Some(prepared.prompt),
            resume_from: None,
        };
        if let Err(error) = driver.start(request) {
            driver.cancel();
            return Err(rollback_failed_start(
                task_manager,
                &stream,
                AgentRuntimeError::Driver(error),
            ));
        }

        self.retained.remove(&task_id);
        self.running.insert(
            task_id,
            RunningCodexAgent {
                driver: NativeRunningDriver::Kimi(driver),
                retained_workspace: Some(prepared.workspace),
                stream,
                worker_joined: false,
                forced_failure: None,
                exit_report: None,
                pending_prompt: None,
                finish_requested: false,
            },
        );
        Ok(())
    }

    /// Drain native events without waiting for future provider work.
    ///
    /// A completed worker is joined only after `worker_is_finished` reports
    /// true and its event queue has been drained for this frame. The exit report
    /// is accepted as stop authority only when no child was spawned or the
    /// spawned child was reaped.
    pub fn poll(
        &mut self,
        task_manager: &mut TaskManager,
        current_policy: NativePromptPolicy,
    ) -> AgentRuntimePollReport {
        if let Some(remote) = &mut self.remote {
            return remote.poll(task_manager, current_policy);
        }
        let mut report = AgentRuntimePollReport::default();
        self.reap_cancelled_preparations();
        self.poll_preparations(task_manager, current_policy, &mut report);
        let mut task_ids: Vec<_> = self.running.keys().copied().collect();
        if task_ids.is_empty() {
            self.next_poll_index = 0;
            return report;
        }

        let start = self.next_poll_index % task_ids.len();
        task_ids.rotate_left(start);
        self.next_poll_index = (start + 1) % task_ids.len();
        let mut remaining = NATIVE_AGENT_EVENTS_PER_FRAME;

        for task_id in task_ids {
            if remaining == 0 {
                report.budget_exhausted = true;
                break;
            }
            let allowance = remaining.min(NATIVE_AGENT_EVENTS_PER_TASK_PER_FRAME);
            let mut queue_drained = false;
            let mut completion = None;

            {
                let Some(runtime) = self.running.get_mut(&task_id) else {
                    continue;
                };
                for _ in 0..allowance {
                    match runtime.driver.try_next_event() {
                        Ok(Some(event)) => {
                            remaining -= 1;
                            report.events_drained += 1;

                            // Once a terminal event has removed the stream,
                            // discard any provider protocol tail. It has no
                            // remaining lifecycle authority.
                            if runtime.forced_failure.is_some()
                                || !task_manager.has_active_agent_event_stream(task_id)
                            {
                                continue;
                            }
                            let started_turn = match event.kind() {
                                super::AgentEventKind::TurnStarted { turn_id } => Some(*turn_id),
                                _ => None,
                            };
                            match report.apply_event(task_manager, event) {
                                Ok(_) => {
                                    if started_turn.is_some()
                                        && runtime.pending_prompt == started_turn
                                    {
                                        runtime.pending_prompt = None;
                                    }
                                }
                                Err(error) => {
                                    let detail = bounded_runtime_detail(format!(
                                        "native Agent event was rejected: {error}"
                                    ));
                                    if runtime.forced_failure.is_none() {
                                        runtime.forced_failure = Some(detail.clone());
                                    }
                                    runtime.driver.cancel();
                                    report.issues.push(AgentRuntimeIssue { task_id, detail });
                                }
                            }
                        }
                        Ok(None) | Err(AgentDriverError::Closed) => {
                            queue_drained = true;
                            break;
                        }
                        Err(error) => {
                            let detail = bounded_runtime_detail(format!(
                                "native Agent event transport failed: {error}"
                            ));
                            if runtime.forced_failure.is_none() {
                                runtime.forced_failure = Some(detail.clone());
                            }
                            runtime.driver.cancel();
                            report.issues.push(AgentRuntimeIssue { task_id, detail });
                            queue_drained = true;
                            break;
                        }
                    }
                }

                let worker_stopped = runtime.worker_joined || runtime.driver.worker_is_finished();
                if queue_drained && worker_stopped {
                    if !runtime.worker_joined {
                        match runtime.driver.join_finished_worker() {
                            Ok(true) => runtime.worker_joined = true,
                            Ok(false) => {}
                            Err(error) => {
                                runtime.worker_joined = true;
                                let detail = bounded_runtime_detail(format!(
                                    "native Agent worker join failed: {error}"
                                ));
                                if runtime.forced_failure.is_none() {
                                    runtime.forced_failure = Some(detail.clone());
                                }
                                report.issues.push(AgentRuntimeIssue { task_id, detail });
                            }
                        }
                    }
                    if runtime.worker_joined && runtime.exit_report.is_none() {
                        if let Some(exit) = runtime.driver.take_exit_report() {
                            runtime.record_exit_report(exit, &mut report);
                        }
                    }
                    if runtime.exit_report.as_ref().is_some_and(|exit| {
                        !exit.process.spawned
                            || (exit.process.reaped && exit.process.containment_verified_empty)
                    }) {
                        let exit = runtime
                            .exit_report
                            .take()
                            .expect("exit report was checked above");
                        let outcome = if runtime.forced_failure.is_some() {
                            AgentSessionOutcome::Failed
                        } else {
                            exit.outcome
                        };
                        let detail = runtime
                            .forced_failure
                            .clone()
                            .or_else(|| exit.detail.clone());
                        completion = Some((
                            runtime.stream.clone(),
                            runtime.driver.view_snapshot_with_revision(),
                            exit,
                            outcome,
                            detail,
                        ));
                    }
                }
            }

            let Some((stream, (view_revision, view), exit_report, outcome, detail)) = completion
            else {
                continue;
            };
            // The report proves the worker has stopped and its child either was
            // never spawned or was reaped. Only now may validation be unlocked.
            if task_manager.has_active_agent_event_stream(task_id) {
                if let Err(error) = task_manager.finish_agent_event_stream_after_stop(
                    &stream,
                    outcome,
                    detail.clone(),
                ) {
                    report.issues.push(AgentRuntimeIssue {
                        task_id,
                        detail: bounded_runtime_detail(format!(
                            "native Agent exit could not update its task: {error}"
                        )),
                    });
                }
            }
            self.running.remove(&task_id);
            report.completions.push(AgentRuntimeCompletion {
                task_id,
                outcome,
                cause: exit_report.cause,
                detail: detail.clone(),
            });
            self.retained.insert(
                task_id,
                RetainedCodexAgent {
                    view: Arc::new(view),
                    view_revision,
                    exit_report: Some(exit_report),
                    effective_outcome: outcome,
                },
            );
            report.workers_finished += 1;
        }

        // Consuming the full global allowance means more provider work may be
        // queued even if the final dequeue happened to empty a queue exactly.
        report.budget_exhausted |= remaining == 0;
        report
    }

    pub fn cancel(&mut self, task_id: TaskId) -> Result<(), AgentRuntimeError> {
        if let Some(remote) = &mut self.remote {
            return remote.action(task_id, crate::agent_workspace::NativeAction::Cancel);
        }
        if let Some(preparation) = self.preparing.remove(&task_id) {
            preparation.cancel.store(true, Ordering::Release);
            // Keep ownership of the receiver until the worker acknowledges
            // cancellation or exits. This bounds rapid Start/Cancel cycles to
            // the same global worker cap instead of detaching unlimited Git
            // and credential-preparation threads.
            self.cancelled_preparations.push(preparation);
            return Ok(());
        }
        let runtime = self
            .running
            .get_mut(&task_id)
            .ok_or(AgentRuntimeError::NotRunning(task_id))?;
        runtime.driver.cancel();
        Ok(())
    }

    pub fn decide_approval(
        &mut self,
        task_id: TaskId,
        approval_id: ApprovalId,
        decision: ApprovalDecision,
    ) -> Result<(), AgentRuntimeError> {
        if let Some(remote) = &mut self.remote {
            return remote.action(
                task_id,
                crate::agent_workspace::NativeAction::Approval {
                    id: approval_id,
                    decision,
                },
            );
        }
        let runtime = self
            .running
            .get_mut(&task_id)
            .ok_or(AgentRuntimeError::NotRunning(task_id))?;
        runtime
            .driver
            .send(AgentCommand::DecideApproval {
                id: approval_id,
                decision,
            })
            .map_err(AgentRuntimeError::Driver)
    }

    /// Start another bounded user turn on the same native conversation.
    ///
    /// The task reducer and driver both repeat the idle-session gate. The
    /// driver's nonblocking command boundary reserves the idle phase before
    /// returning so duplicate UI actions cannot queue overlapping turns.
    pub fn prompt_codex(
        &mut self,
        task_manager: &TaskManager,
        task_id: TaskId,
        text: &str,
        policy: NativePromptPolicy,
    ) -> Result<(), AgentRuntimeError> {
        self.prompt_native(task_manager, task_id, text, policy)
    }

    /// Submit a follow-up to an idle Codex or Claude conversation. The legacy
    /// `prompt_codex` entry point remains source-compatible for existing hosts.
    /// Async hosted sends are cleared by a matching host acknowledgment,
    /// never by admission to this process's RPC queue.
    pub fn prompt_native_tracked(
        &mut self,
        tasks: &TaskManager,
        id: TaskId,
        text: &str,
        policy: NativePromptPolicy,
        receipt: String,
    ) -> Result<(), AgentRuntimeError> {
        if uuid::Uuid::parse_str(&receipt).is_err() {
            return Err(AgentRuntimeError::Preparation(
                "Invalid native draft receipt".into(),
            ));
        }
        if let Some(remote) = &mut self.remote {
            let task = tasks.get(id).ok_or(AgentRuntimeError::UnknownTask(id))?;
            if task.validation.status == TaskValidationStatus::Running {
                return Err(AgentRuntimeError::Preparation(
                    "Finish validation before sending a native turn".into(),
                ));
            }
            build_native_follow_up_prompt(text, policy)?;
            return remote.action(
                id,
                crate::agent_workspace::NativeAction::Prompt {
                    text: text.into(),
                    policy,
                    receipt: Some(receipt),
                },
            );
        }
        self.prompt_native(tasks, id, text, policy)
    }
    pub fn take_prompt_outcomes(&mut self) -> Vec<NativePromptOutcome> {
        self.remote
            .as_mut()
            .map(|r| std::mem::take(&mut r.prompt_outcomes))
            .unwrap_or_default()
    }

    pub fn prompt_native(
        &mut self,
        task_manager: &TaskManager,
        task_id: TaskId,
        text: &str,
        policy: NativePromptPolicy,
    ) -> Result<(), AgentRuntimeError> {
        if let Some(remote) = &mut self.remote {
            return remote.action(
                task_id,
                crate::agent_workspace::NativeAction::Prompt {
                    text: text.into(),
                    policy,
                    receipt: None,
                },
            );
        }
        let task = task_manager
            .get(task_id)
            .ok_or(AgentRuntimeError::UnknownTask(task_id))?;
        if task.status != TaskStatus::ReadyForReview
            || task.runtime_kind != TaskRuntimeKind::Native
            || !task_manager.has_active_agent_event_stream(task_id)
        {
            return Err(AgentRuntimeError::Preparation(format!(
                "task must be at a live native review point (currently {} / {:?})",
                task.status.label(),
                task.runtime_kind
            )));
        }
        let prompt = build_native_follow_up_prompt(text, policy)?;
        let turn_id = prompt.turn_id;
        let runtime = self
            .running
            .get_mut(&task_id)
            .ok_or(AgentRuntimeError::NotRunning(task_id))?;
        if matches!(runtime.driver, NativeRunningDriver::Kimi(_)) {
            return Err(AgentRuntimeError::Preparation(
                "this provider does not support native follow-up turns".into(),
            ));
        }
        if runtime.pending_prompt.is_some() || runtime.finish_requested {
            return Err(AgentRuntimeError::Preparation(
                "native session already has a queued turn or finish request".into(),
            ));
        }
        runtime
            .driver
            .send(AgentCommand::Prompt(prompt))
            .map_err(AgentRuntimeError::Driver)?;
        runtime.pending_prompt = Some(turn_id);
        Ok(())
    }

    /// UI capability and current readiness; sending repeats the gate atomically.
    pub fn can_prompt_native(&self, task_id: TaskId) -> bool {
        if let Some(remote) = &self.remote {
            return remote.state(task_id).is_some_and(|s| s.can_prompt);
        }
        self.running.get(&task_id).is_some_and(|runtime| {
            !matches!(runtime.driver, NativeRunningDriver::Kimi(_))
                && runtime.driver.phase() == CodexAppServerPhase::Ready
                && runtime.pending_prompt.is_none()
                && !runtime.finish_requested
                && !runtime.worker_joined
        })
    }

    /// An exact app-owned Codex profile may be reopened only after the runtime
    /// has proved its previous worker and containment stopped cleanly.
    pub fn can_resume_codex(&self, task_id: TaskId) -> bool {
        if let Some(remote) = &self.remote {
            return remote.state(task_id).is_some_and(|s| s.can_resume);
        }
        !self.running.contains_key(&task_id)
            && !self.preparing.contains_key(&task_id)
            && self.native_codex_homes.contains_key(&task_id)
            && (self.explicit_codex_restores.contains(&task_id)
                || self.retained.get(&task_id).is_some_and(|retained| {
                    retained.effective_outcome == AgentSessionOutcome::Clean
                        && retained.view.provider_thread_id.is_some()
                }))
    }

    /// Page provider-owned history without turning old events into new work.
    pub fn load_native_history(
        &mut self,
        task_id: TaskId,
        reset: bool,
    ) -> Result<(), AgentRuntimeError> {
        if let Some(remote) = &mut self.remote {
            return remote.action(
                task_id,
                crate::agent_workspace::NativeAction::History { reset },
            );
        }
        let runtime = self
            .running
            .get_mut(&task_id)
            .ok_or(AgentRuntimeError::NotRunning(task_id))?;
        if !matches!(runtime.driver, NativeRunningDriver::Codex(_)) {
            return Err(AgentRuntimeError::Preparation(
                "This provider exposes history through its Terminal view".into(),
            ));
        }
        runtime
            .driver
            .send(AgentCommand::History { reset })
            .map_err(AgentRuntimeError::Driver)
    }

    /// Finish an idle live session. Validation remains locked until the worker
    /// has stopped, containment is empty, and the provider leader is reaped.
    pub fn finish_codex(
        &mut self,
        task_manager: &TaskManager,
        task_id: TaskId,
    ) -> Result<(), AgentRuntimeError> {
        if let Some(remote) = &mut self.remote {
            return remote.action(task_id, crate::agent_workspace::NativeAction::Finish);
        }
        let task = task_manager
            .get(task_id)
            .ok_or(AgentRuntimeError::UnknownTask(task_id))?;
        if task.status != TaskStatus::ReadyForReview
            || task.runtime_kind != TaskRuntimeKind::Native
            || !task_manager.has_active_agent_event_stream(task_id)
        {
            return Err(AgentRuntimeError::Preparation(format!(
                "task must be at a live native review point (currently {} / {:?})",
                task.status.label(),
                task.runtime_kind
            )));
        }
        let runtime = self
            .running
            .get_mut(&task_id)
            .ok_or(AgentRuntimeError::NotRunning(task_id))?;
        if runtime.pending_prompt.is_some() || runtime.finish_requested {
            return Err(AgentRuntimeError::Preparation(
                "native Codex session already has a queued turn or finish request".into(),
            ));
        }
        runtime
            .driver
            .send(AgentCommand::FinishSession)
            .map_err(AgentRuntimeError::Driver)?;
        runtime.finish_requested = true;
        Ok(())
    }

    /// Return the current bounded view, or the final view retained after exit.
    pub fn snapshot(&self, task_id: TaskId) -> Option<CodexAppServerViewSnapshot> {
        if let Some(remote) = &self.remote {
            return remote.snapshot(task_id).map(|v| v.as_ref().clone());
        }
        self.running
            .get(&task_id)
            .map(|runtime| runtime.driver.view_snapshot())
            .or_else(|| {
                self.retained
                    .get(&task_id)
                    .map(|retained| retained.view.as_ref().clone())
            })
    }

    /// Process-unique identity of the view `snapshot` would return. It changes
    /// whenever the provider view changes, never repeats for a later run, and
    /// stays fixed for a retained final view. Reading it never clones content.
    pub fn snapshot_revision(&self, task_id: TaskId) -> Option<u64> {
        if let Some(remote) = &self.remote {
            return remote.revision(task_id);
        }
        self.running
            .get(&task_id)
            .map(|runtime| runtime.driver.view_revision())
            .or_else(|| {
                self.retained
                    .get(&task_id)
                    .map(|retained| retained.view_revision)
            })
    }

    /// The same view as `snapshot`, shared until the provider changes it.
    /// Repeated calls for an unchanged view return the same allocation, so a
    /// host can render every frame without copying assistant text, command
    /// output and file diffs each time. The content is identical to `snapshot`.
    pub fn shared_snapshot(&self, task_id: TaskId) -> Option<Arc<CodexAppServerViewSnapshot>> {
        if let Some(remote) = &self.remote {
            return remote.snapshot(task_id);
        }
        if let Some(retained) = self.retained.get(&task_id) {
            if !self.running.contains_key(&task_id) {
                self.shared_snapshots.lock().remove(&task_id);
                return Some(retained.view.clone());
            }
        }
        let Some(runtime) = self.running.get(&task_id) else {
            self.shared_snapshots.lock().remove(&task_id);
            return None;
        };
        let revision = runtime.driver.view_revision();
        let mut shared = self.shared_snapshots.lock();
        if let Some((cached, view)) = shared.get(&task_id) {
            if *cached == revision {
                return Some(view.clone());
            }
        }
        let (revision, view) = runtime.driver.view_snapshot_with_revision();
        let view = Arc::new(view);
        // Bound the cache to live runtimes; finished ones use retained views.
        shared.retain(|id, _| self.running.contains_key(id));
        shared.insert(task_id, (revision, view.clone()));
        Some(view)
    }

    pub fn exit_report(&self, task_id: TaskId) -> Option<&CodexAppServerExitReport> {
        if let Some(remote) = &self.remote {
            return remote.exit(task_id);
        }
        self.retained
            .get(&task_id)
            .and_then(|retained| retained.exit_report.as_ref())
    }

    pub fn take_exit_report(&mut self, task_id: TaskId) -> Option<CodexAppServerExitReport> {
        if let Some(remote) = &mut self.remote {
            return remote.take_exit(task_id);
        }
        self.retained
            .get_mut(&task_id)
            .and_then(|retained| retained.exit_report.take())
    }

    /// True only when a fully stopped native session ended unsuccessfully and
    /// its retained process evidence can authorize an explicit PTY recovery.
    /// Clean Finish remains a review/validation path, not a silent authority
    /// switch to the opaque provider CLI.
    pub fn can_continue_in_terminal(&self, task_id: TaskId) -> bool {
        if let Some(remote) = &self.remote {
            return remote
                .state(task_id)
                .is_some_and(|s| s.can_continue_in_terminal);
        }
        !self.running.contains_key(&task_id)
            && self.retained.get(&task_id).is_some_and(|retained| {
                matches!(
                    retained.effective_outcome,
                    AgentSessionOutcome::Failed | AgentSessionOutcome::Cancelled
                ) && retained.exit_report.as_ref().is_some_and(|exit| {
                    !exit.process.spawned
                        || (exit.process.reaped && exit.process.containment_verified_empty)
                })
            })
    }

    pub fn has_running(&self, task_id: TaskId) -> bool {
        if let Some(remote) = &self.remote {
            return remote.state(task_id).is_some_and(|s| s.live);
        }
        self.running.contains_key(&task_id)
    }

    pub fn has_preparing(&self, task_id: TaskId) -> bool {
        if let Some(remote) = &self.remote {
            return remote.is_preparing(task_id);
        }
        self.preparing.contains_key(&task_id)
    }

    pub fn has_any_running(&self) -> bool {
        if let Some(remote) = &self.remote {
            return remote.any_running();
        }
        !self.running.is_empty()
    }

    /// True while a provider is starting, executing or stopping. A loaded
    /// thread parked at an idle review point, or one blocked on a pending
    /// approval, produces nothing until the user responds; low-frequency
    /// lifecycle polling observes those phases without a high-rate loop. The
    /// host's own approval or follow-up action triggers an immediate poll.
    pub fn needs_fast_poll(&self) -> bool {
        if let Some(remote) = &self.remote {
            return remote.fast_poll();
        }
        self.running.values().any(|runtime| {
            !runtime.worker_joined
                && !matches!(
                    runtime.driver.phase(),
                    CodexAppServerPhase::Ready | CodexAppServerPhase::WaitingForApproval
                )
        })
    }

    pub fn has_any_activity(&self) -> bool {
        if let Some(remote) = &self.remote {
            return remote.active();
        }
        !self.preparing.is_empty()
            || !self.cancelled_preparations.is_empty()
            || !self.running.is_empty()
    }

    pub fn clear_retained(&mut self, task_id: TaskId) {
        if let Some(remote) = &mut self.remote {
            remote.detach(task_id);
            return;
        }
        self.retained.remove(&task_id);
        self.shared_snapshots.lock().remove(&task_id);
    }
}

impl Drop for AgentRuntimeManager {
    fn drop(&mut self) {
        for preparation in self.preparing.values_mut() {
            preparation.cancel.store(true, Ordering::Release);
        }
        for preparation in &mut self.cancelled_preparations {
            preparation.cancel.store(true, Ordering::Release);
        }
        for runtime in self.running.values_mut() {
            runtime.driver.cancel();
        }
        for preparation in self.preparing.values_mut() {
            if let Some(worker) = preparation.worker.take() {
                let _ = worker.join();
            }
        }
        for preparation in &mut self.cancelled_preparations {
            if let Some(worker) = preparation.worker.take() {
                let _ = worker.join();
            }
        }
    }
}

impl AgentRuntimeManager {
    fn reap_cancelled_preparations(&mut self) {
        self.cancelled_preparations.retain_mut(|pending| {
            if matches!(pending.receiver.try_recv(), Err(TryRecvError::Empty)) {
                return true;
            }
            if let Some(worker) = pending.worker.take() {
                let _ = worker.join();
            }
            false
        });
    }

    fn poll_preparations(
        &mut self,
        task_manager: &mut TaskManager,
        current_policy: NativePromptPolicy,
        report: &mut AgentRuntimePollReport,
    ) {
        let task_ids: Vec<_> = self.preparing.keys().copied().collect();
        for task_id in task_ids {
            let policy_changed = self
                .preparing
                .get(&task_id)
                .is_some_and(|pending| pending.policy != current_policy);
            if policy_changed {
                let pending = self
                    .preparing
                    .remove(&task_id)
                    .expect("preparation was checked above");
                pending.cancel.store(true, Ordering::Release);
                self.cancelled_preparations.push(pending);
                report.preparations_finished += 1;
                report.issues.push(AgentRuntimeIssue {
                    task_id,
                    detail: bounded_runtime_detail(
                        "native Agent preparation was cancelled because the AI sharing policy changed"
                            .to_string(),
                    ),
                });
                continue;
            }
            let received = self
                .preparing
                .get(&task_id)
                .map(|pending| pending.receiver.try_recv());
            let message = match received {
                Some(Ok(message)) => message,
                Some(Err(TryRecvError::Empty)) | None => continue,
                Some(Err(TryRecvError::Disconnected)) => PreparationResult {
                    generation: self
                        .preparing
                        .get(&task_id)
                        .map_or(0, |pending| pending.generation),
                    result: Err(AgentRuntimeError::Preparation(
                        "background preparation worker stopped unexpectedly".into(),
                    )),
                },
            };
            let Some(mut pending) = self.preparing.remove(&task_id) else {
                continue;
            };
            if let Some(worker) = pending.worker.take() {
                if worker.join().is_err() {
                    report.preparations_finished += 1;
                    report.issues.push(AgentRuntimeIssue {
                        task_id,
                        detail: bounded_runtime_detail(
                            "native Agent preparation worker panicked".to_string(),
                        ),
                    });
                    continue;
                }
            }
            report.preparations_finished += 1;
            if message.generation != pending.generation {
                report.issues.push(AgentRuntimeIssue {
                    task_id,
                    detail: bounded_runtime_detail(
                        "native Agent preparation generation did not match its request".to_string(),
                    ),
                });
                continue;
            }
            let result = message.result.and_then(|prepared| match prepared {
                PreparedNativeStart::Codex(prepared) => {
                    self.start_prepared_codex(task_manager, prepared)
                }
                PreparedNativeStart::Claude(prepared) => {
                    self.start_prepared_claude(task_manager, prepared)
                }
                PreparedNativeStart::Kimi(prepared) => {
                    self.start_prepared_kimi(task_manager, prepared)
                }
            });
            match result {
                Ok(()) => report.preparations_started += 1,
                Err(error) => report.issues.push(AgentRuntimeIssue {
                    task_id,
                    detail: bounded_runtime_detail(error.to_string()),
                }),
            }
        }
    }
}

fn preparation_cancelled(cancel: &AtomicBool) -> Result<(), AgentRuntimeError> {
    if cancel.load(Ordering::Acquire) {
        Err(AgentRuntimeError::Preparation("cancelled".into()))
    } else {
        Ok(())
    }
}

fn resolve_host_native_argv(
    provider: AgentProvider,
    task: &AgentTask,
    context: Option<&crate::agent_workspace::NativeLaunchContext>,
) -> Result<Vec<String>, AgentLaunchError> {
    match context {
        Some(context) => AgentLaunchSpec::resolve_native_with_path(
            provider,
            &task.repo_root,
            &task.worktree_path,
            context.search_path.as_deref().map(std::ffi::OsStr::new),
        ),
        None => AgentLaunchSpec::resolve_native(provider, &task.repo_root, &task.worktree_path),
    }
}

fn prepare_codex_start(
    task: AgentTask,
    policy: NativePromptPolicy,
    cancel: Arc<AtomicBool>,
    resume_home: Option<std::path::PathBuf>,
    context: Option<crate::agent_workspace::NativeLaunchContext>,
    execution_lease: Option<Arc<crate::agent_workspace::NativeSessionLease>>,
) -> Result<PreparedNativeStart, AgentRuntimeError> {
    preparation_cancelled(cancel.as_ref())?;
    // The capability owns its pinned directory descriptors. It stays in this
    // result until the UI thread either consumes it or drops a stale result.
    let workspace = if resume_home.is_some() {
        super::native::prepare_native_agent_workspace_for_resume(&task, Arc::clone(&cancel))?
    } else {
        prepare_native_agent_workspace(&task, Arc::clone(&cancel))?
    };
    preparation_cancelled(cancel.as_ref())?;
    let prompt = if resume_home.is_some() {
        None
    } else {
        Some(build_native_task_prompt(
            &task,
            workspace.relative_cwd(),
            policy,
        )?)
    };
    preparation_cancelled(cancel.as_ref())?;
    let launch_argv = resolve_host_native_argv(AgentProvider::Codex, &task, context.as_ref())?;
    preparation_cancelled(cancel.as_ref())?;
    let mut native_home = match (resume_home, context.as_ref()) {
        (Some(path), Some(context)) => PreparedNativeCodexHome::reopen_persistent_with_source(
            &task,
            &path,
            &context.codex_home,
        )?,
        (None, Some(context)) => PreparedNativeCodexHome::prepare_persistent_with_source(
            &task,
            workspace.relative_cwd(),
            &context.codex_home,
        )?,
        (Some(path), None) => PreparedNativeCodexHome::reopen_persistent(&task, &path)?,
        (None, None) => {
            PreparedNativeCodexHome::prepare_persistent(&task, workspace.relative_cwd())?
        }
    };
    if let Some(lease) = execution_lease {
        native_home.hold_execution_lease(lease);
    }
    preparation_cancelled(cancel.as_ref())?;
    Ok(PreparedNativeStart::Codex(PreparedCodexStart {
        task,
        workspace,
        prompt,
        launch_argv,
        native_home,
    }))
}

fn prepare_claude_start(
    task: AgentTask,
    policy: NativePromptPolicy,
    cancel: Arc<AtomicBool>,
    context: Option<crate::agent_workspace::NativeLaunchContext>,
) -> Result<PreparedNativeStart, AgentRuntimeError> {
    preparation_cancelled(cancel.as_ref())?;
    let workspace = prepare_native_agent_workspace(&task, Arc::clone(&cancel))?;
    preparation_cancelled(cancel.as_ref())?;
    let prompt = build_native_task_prompt(&task, workspace.relative_cwd(), policy)?;
    preparation_cancelled(cancel.as_ref())?;
    let launch_argv = resolve_host_native_argv(AgentProvider::Claude, &task, context.as_ref())?;
    preparation_cancelled(cancel.as_ref())?;
    Ok(PreparedNativeStart::Claude(PreparedClaudeStart {
        task,
        workspace,
        prompt,
        launch_argv,
    }))
}

fn prepare_kimi_start(
    task: AgentTask,
    policy: NativePromptPolicy,
    cancel: Arc<AtomicBool>,
    context: Option<crate::agent_workspace::NativeLaunchContext>,
) -> Result<PreparedNativeStart, AgentRuntimeError> {
    preparation_cancelled(cancel.as_ref())?;
    let workspace = prepare_native_agent_workspace(&task, Arc::clone(&cancel))?;
    preparation_cancelled(cancel.as_ref())?;
    let prompt = build_native_task_prompt(&task, workspace.relative_cwd(), policy)?;
    preparation_cancelled(cancel.as_ref())?;
    let launch_argv = resolve_host_native_argv(AgentProvider::Kimi, &task, context.as_ref())?;
    preparation_cancelled(cancel.as_ref())?;
    Ok(PreparedNativeStart::Kimi(PreparedKimiStart {
        task,
        workspace,
        prompt,
        launch_argv,
    }))
}

fn rollback_failed_start(
    task_manager: &mut TaskManager,
    stream: &AgentEventStream,
    start: AgentRuntimeError,
) -> AgentRuntimeError {
    let detail = bounded_runtime_detail(start.to_string());
    match task_manager.rollback_agent_event_stream_before_spawn(stream, detail) {
        Ok(_) => start,
        Err(rollback) => AgentRuntimeError::StartRollback {
            start: Box::new(start),
            rollback,
        },
    }
}

fn bounded_runtime_detail(detail: String) -> String {
    super::event::bounded_event_detail(Some(detail))
        .unwrap_or_else(|| "native Agent runtime failed".to_string())
}

#[cfg(test)]
mod tests {
    use super::*;

    const TEST_POLICY: NativePromptPolicy = NativePromptPolicy {
        share_command_context: true,
        redact_secrets: true,
    };

    fn pending_preparation(
        runtime: &mut AgentRuntimeManager,
        task_id: TaskId,
        generation: u64,
    ) -> mpsc::SyncSender<PreparationResult> {
        let (sender, receiver) = mpsc::sync_channel(1);
        runtime.preparing.insert(
            task_id,
            PendingCodexPreparation {
                generation,
                policy: TEST_POLICY,
                receiver,
                cancel: Arc::new(AtomicBool::new(false)),
                worker: None,
            },
        );
        sender
    }

    fn task_manager() -> (TaskManager, TaskId) {
        let mut tasks = TaskManager::new();
        let token = uuid::Uuid::new_v4().simple().to_string();
        let task_id = tasks
            .create(super::super::NewTask {
                title: "async native preparation".into(),
                provider: AgentProvider::Codex,
                repo_root: format!("/tmp/app-runtime-test-repository-{token}").into(),
                worktree_path: format!("/tmp/app-runtime-test-worktree-{token}").into(),
                branch: "app/async-native-preparation".into(),
                base_commit: "0123456789abcdef0123456789abcdef01234567".into(),
                source_context: None,
            })
            .unwrap();
        (tasks, task_id)
    }

    #[test]
    fn approval_waits_poll_slowly_and_unchanged_views_are_shared_without_copying() {
        let (mut tasks, task_id) = task_manager();
        let stream = tasks.start_agent_event_stream(task_id).unwrap();
        let task = tasks.get(task_id).unwrap();
        // Never started: no worker, provider or credential is involved.
        let driver =
            ClaudeStreamJsonDriver::new(vec!["/bin/true".into()], task.worktree_path.clone());
        let mut runtime = AgentRuntimeManager::new();
        runtime.running.insert(
            task_id,
            RunningCodexAgent {
                driver: NativeRunningDriver::Claude(driver),
                retained_workspace: None,
                stream,
                worker_joined: false,
                forced_failure: None,
                exit_report: None,
                pending_prompt: None,
                finish_requested: false,
            },
        );
        let change = |runtime: &AgentRuntimeManager,
                      edit: &dyn Fn(&mut CodexAppServerViewSnapshot)| {
            match &runtime.running[&task_id].driver {
                NativeRunningDriver::Claude(driver) => driver.mutate_view_for_test(edit),
                _ => unreachable!("fixture uses the print-stream driver"),
            }
        };
        for (phase, fast) in [
            (CodexAppServerPhase::Running, true),
            (CodexAppServerPhase::WaitingForApproval, false),
            (CodexAppServerPhase::Ready, false),
            (CodexAppServerPhase::Stopping, true),
            (CodexAppServerPhase::Cancelling, true),
        ] {
            change(&runtime, &|view| view.phase = phase);
            assert_eq!(runtime.needs_fast_poll(), fast, "{phase:?}");
        }

        let first = runtime.shared_snapshot(task_id).unwrap();
        let again = runtime.shared_snapshot(task_id).unwrap();
        assert!(Arc::ptr_eq(&first, &again), "an unchanged view is shared");
        assert_eq!(*first, runtime.snapshot(task_id).unwrap());
        let revision = runtime.snapshot_revision(task_id).unwrap();
        assert_eq!(runtime.snapshot_revision(task_id), Some(revision));
        change(&runtime, &|view| view.agent_text.push_str("delta"));
        assert_ne!(runtime.snapshot_revision(task_id), Some(revision));
        let changed = runtime.shared_snapshot(task_id).unwrap();
        assert!(!Arc::ptr_eq(&first, &changed));
        assert_eq!(changed.agent_text, "delta");
        assert_eq!(first.agent_text, "", "an earlier shared view never changes");
        assert_eq!(*changed, runtime.snapshot(task_id).unwrap());

        let unknown = TaskId::new();
        assert!(runtime.shared_snapshot(unknown).is_none());
        assert!(runtime.snapshot_revision(unknown).is_none());
        runtime.running.remove(&task_id);
        assert!(runtime.shared_snapshot(task_id).is_none());
        assert!(runtime.shared_snapshots.lock().is_empty());
    }

    #[test]
    fn unconfirmed_cleanup_is_reported_once_and_stays_locked_without_fast_polling() {
        use crate::agent_task::CodexAppServerProcessExit;

        let (mut tasks, task_id) = task_manager();
        let stream = tasks.start_agent_event_stream(task_id).unwrap();
        let task = tasks.get(task_id).unwrap();
        // This deliberately missing directory makes the fake print worker
        // finish without running any provider or consulting credentials.
        let mut driver = ClaudeStreamJsonDriver::new(
            vec!["/bin/sh".into(), "-c".into(), "exit 0".into()],
            task.worktree_path.clone(),
        );
        driver
            .start(AgentStartRequest {
                provider: AgentProvider::Claude,
                stream: stream.clone(),
                worktree_path: task.worktree_path.clone(),
                source_context: None,
                initial_prompt: Some(AgentPrompt::new("fixture")),
                resume_from: None,
            })
            .unwrap();
        let deadline = std::time::Instant::now() + std::time::Duration::from_secs(5);
        while !driver.worker_is_finished() {
            assert!(std::time::Instant::now() < deadline);
            std::thread::yield_now();
        }
        driver.join_finished_worker().unwrap();
        while matches!(driver.try_next_event(), Ok(Some(_))) {}
        let _ = driver.take_exit_report();
        let mut running = RunningCodexAgent {
            driver: NativeRunningDriver::Claude(driver),
            retained_workspace: None,
            stream,
            worker_joined: true,
            forced_failure: None,
            exit_report: None,
            pending_prompt: None,
            finish_requested: false,
        };
        let exit = CodexAppServerExitReport {
            outcome: AgentSessionOutcome::Failed,
            cause: CodexAppServerExitCause::IoFailed,
            detail: Some("fixture group is still populated".into()),
            process: CodexAppServerProcessExit {
                spawned: true,
                reaped: true,
                containment_verified_empty: false,
                ..CodexAppServerProcessExit::default()
            },
            critical_event_delivery_failed: false,
            stderr_tail: String::new(),
        };
        let mut report = AgentRuntimePollReport::default();
        running.record_exit_report(exit.clone(), &mut report);
        running.record_exit_report(exit.clone(), &mut report);
        assert_eq!(report.issues.len(), 1);
        assert!(report.issues[0]
            .detail
            .contains("task actions remain locked"));
        assert!(report.issues[0].detail.contains("still populated"));
        let mut runtime = AgentRuntimeManager::new();
        runtime.running.insert(task_id, running);
        assert!(runtime.has_any_activity());
        assert!(!runtime.needs_fast_poll());
        for _ in 0..2 {
            let report = runtime.poll(&mut tasks, TEST_POLICY);
            assert!(report.issues.is_empty());
            assert!(report.completions.is_empty());
            assert_eq!(runtime.running[&task_id].exit_report.as_ref(), Some(&exit));
            assert!(tasks.has_active_agent_event_stream(task_id));
            assert!(tasks.next_validation_attempt(task_id).is_err());
            assert!(tasks.archive(task_id).is_err());
        }
        runtime.running.get_mut(&task_id).unwrap().worker_joined = false;
        assert!(
            runtime.needs_fast_poll(),
            "unjoined active workers still need fast polling"
        );
    }

    #[test]
    fn empty_runtime_has_no_running_or_retained_state() {
        let mut runtime = AgentRuntimeManager::new();
        let task_id = TaskId::new();
        assert!(!runtime.has_running(task_id));
        assert!(!runtime.has_preparing(task_id));
        assert!(!runtime.has_any_running());
        assert!(!runtime.has_any_activity());
        assert!(runtime.snapshot(task_id).is_none());
        assert!(runtime.exit_report(task_id).is_none());
        assert!(matches!(
            runtime.cancel(task_id),
            Err(AgentRuntimeError::NotRunning(id)) if id == task_id
        ));
    }

    #[test]
    fn empty_poll_is_bounded_and_idle() {
        let mut runtime = AgentRuntimeManager::new();
        let mut tasks = TaskManager::new();
        let report = runtime.poll(&mut tasks, TEST_POLICY);
        assert_eq!(report, AgentRuntimePollReport::default());
        assert!(!report.made_progress());
    }

    #[test]
    fn terminal_continuation_requires_a_stopped_unsuccessful_effective_outcome() {
        let task_id = TaskId::new();
        let retained = |effective_outcome, process| RetainedCodexAgent {
            view: Arc::new(CodexAppServerViewSnapshot::default()),
            view_revision: 0,
            exit_report: Some(CodexAppServerExitReport {
                // A runtime-forced failure may override a raw clean provider
                // report, so eligibility intentionally uses the retained
                // effective outcome instead of this field.
                outcome: AgentSessionOutcome::Clean,
                cause: super::super::CodexAppServerExitCause::Clean,
                detail: None,
                process,
                critical_event_delivery_failed: false,
                stderr_tail: String::new(),
            }),
            effective_outcome,
        };

        let stopped = super::super::CodexAppServerProcessExit {
            spawned: true,
            provider_released: true,
            reaped: true,
            containment_verified_empty: true,
            success: true,
            code: Some(0),
            signal: None,
        };
        let mut runtime = AgentRuntimeManager::new();
        runtime
            .retained
            .insert(task_id, retained(AgentSessionOutcome::Failed, stopped));
        assert!(runtime.can_continue_in_terminal(task_id));

        runtime
            .retained
            .insert(task_id, retained(AgentSessionOutcome::Clean, stopped));
        assert!(!runtime.can_continue_in_terminal(task_id));

        runtime.retained.insert(
            task_id,
            retained(
                AgentSessionOutcome::Cancelled,
                super::super::CodexAppServerProcessExit {
                    containment_verified_empty: false,
                    ..stopped
                },
            ),
        );
        assert!(!runtime.can_continue_in_terminal(task_id));
    }

    #[test]
    fn pending_preparation_is_activity_rejects_duplicate_start_and_cancels_promptly() {
        let mut runtime = AgentRuntimeManager::new();
        let task_id = TaskId::new();
        let sender = pending_preparation(&mut runtime, task_id, 7);
        let mut tasks = TaskManager::new();

        assert!(runtime.has_preparing(task_id));
        assert!(!runtime.has_running(task_id));
        assert!(runtime.has_any_activity());
        assert!(matches!(
            runtime.start_codex(
                &mut tasks,
                task_id,
                TEST_POLICY,
            ),
            Err(AgentRuntimeError::AlreadyRunning(id)) if id == task_id
        ));

        runtime.cancel(task_id).unwrap();
        assert!(!runtime.has_preparing(task_id));
        assert!(runtime.has_any_activity());
        assert!(sender
            .send(PreparationResult {
                generation: 7,
                result: Err(AgentRuntimeError::Preparation("late".into())),
            })
            .is_ok());
        assert_eq!(
            runtime.poll(&mut tasks, TEST_POLICY),
            AgentRuntimePollReport::default()
        );
        assert!(runtime.cancelled_preparations.is_empty());
        assert!(!runtime.has_any_activity());
    }

    #[test]
    fn preparation_failure_is_reported_without_selecting_task_runtime() {
        let (mut tasks, task_id) = task_manager();
        let before = tasks.get(task_id).unwrap().clone();
        let mut runtime = AgentRuntimeManager::new();
        let sender = pending_preparation(&mut runtime, task_id, 11);
        sender
            .send(PreparationResult {
                generation: 11,
                result: Err(AgentRuntimeError::Preparation(
                    "fixture prerequisite failed".into(),
                )),
            })
            .unwrap();

        let report = runtime.poll(&mut tasks, TEST_POLICY);
        assert_eq!(report.preparations_finished, 1);
        assert_eq!(report.issues.len(), 1);
        assert!(report.issues[0]
            .detail
            .contains("fixture prerequisite failed"));
        assert_eq!(tasks.get(task_id), Some(&before));
        assert!(!tasks.has_active_agent_event_stream(task_id));
        assert!(!runtime.has_any_activity());
    }

    #[test]
    fn changed_sharing_policy_cancels_even_a_ready_preparation_generation() {
        let mut runtime = AgentRuntimeManager::new();
        let task_id = TaskId::new();
        let sender = pending_preparation(&mut runtime, task_id, 13);
        sender
            .send(PreparationResult {
                generation: 13,
                result: Err(AgentRuntimeError::Preparation(
                    "ready result must not win revoked consent".into(),
                )),
            })
            .unwrap();
        let mut tasks = TaskManager::new();

        let report = runtime.poll(
            &mut tasks,
            NativePromptPolicy {
                share_command_context: false,
                redact_secrets: true,
            },
        );
        assert_eq!(report.preparations_finished, 1);
        assert_eq!(report.preparations_started, 0);
        assert_eq!(report.issues.len(), 1);
        assert!(report.issues[0].detail.contains("sharing policy changed"));
        assert!(!runtime.has_preparing(task_id));
        assert!(runtime.has_any_activity());

        assert_eq!(
            runtime.poll(&mut tasks, TEST_POLICY),
            AgentRuntimePollReport::default()
        );
        assert!(!runtime.has_any_activity());
        assert!(!tasks.has_active_agent_event_stream(task_id));
    }

    #[test]
    fn cancelled_preparation_workers_remain_globally_bounded_until_they_exit() {
        let mut runtime = AgentRuntimeManager::new();
        let mut senders = Vec::new();
        for generation in 1..=NATIVE_AGENT_PREPARATIONS_MAX as u64 {
            let task_id = TaskId::new();
            senders.push(pending_preparation(&mut runtime, task_id, generation));
            runtime.cancel(task_id).unwrap();
        }
        assert_eq!(
            runtime.cancelled_preparations.len(),
            NATIVE_AGENT_PREPARATIONS_MAX
        );

        let mut tasks = TaskManager::new();
        let other = TaskId::new();
        assert!(matches!(
            runtime.start_codex(
                &mut tasks,
                other,
                TEST_POLICY,
            ),
            Err(AgentRuntimeError::Preparation(detail)) if detail.contains("at most")
        ));

        drop(senders.pop());
        assert!(matches!(
            runtime.start_codex(
                &mut tasks,
                other,
                TEST_POLICY,
            ),
            Err(AgentRuntimeError::UnknownTask(id)) if id == other
        ));
    }

    #[test]
    fn real_preparation_failure_arrives_asynchronously_and_keeps_task_retryable() {
        let (mut tasks, task_id) = task_manager();
        let before = tasks.get(task_id).unwrap().clone();
        let mut runtime = AgentRuntimeManager::new();
        runtime
            .start_codex(&mut tasks, task_id, TEST_POLICY)
            .unwrap();
        assert!(runtime.has_preparing(task_id));
        assert_eq!(tasks.get(task_id), Some(&before));

        let deadline = std::time::Instant::now() + std::time::Duration::from_secs(2);
        let report = loop {
            let report = runtime.poll(&mut tasks, TEST_POLICY);
            if report.preparations_finished > 0 {
                break report;
            }
            assert!(std::time::Instant::now() < deadline);
            std::thread::yield_now();
        };
        assert_eq!(report.preparations_finished, 1);
        assert_eq!(report.preparations_started, 0);
        assert_eq!(report.issues.len(), 1);
        assert_eq!(tasks.get(task_id), Some(&before));
        assert!(!runtime.has_any_activity());
    }
}

#[cfg(test)]
mod applied_turn_report_tests {
    use super::*;
    use crate::agent_task::{AgentEventKind, AgentTurnId, NewTask};

    fn fixture() -> (TaskManager, AgentEventStream) {
        let mut tasks = TaskManager::new();
        let id = tasks
            .create(NewTask {
                title: "synthetic report fixture".into(),
                provider: AgentProvider::Codex,
                repo_root: "/fixture".into(),
                worktree_path: "/fixture/task".into(),
                branch: "fixture/report".into(),
                base_commit: "a".repeat(40),
                source_context: None,
            })
            .unwrap();
        let stream = tasks.start_agent_event_stream(id).unwrap();
        (tasks, stream)
    }

    #[test]
    fn one_drain_reports_only_accepted_turn_boundaries_in_order() {
        let (mut tasks, stream) = fixture();
        let turn = AgentTurnId::new();
        let mut report = AgentRuntimePollReport::default();
        report
            .apply_event(
                &mut tasks,
                stream.event(
                    1,
                    AgentEventKind::SessionStarted {
                        provider_session_id: None,
                        resumed: false,
                    },
                    None,
                ),
            )
            .unwrap();
        report
            .apply_event(
                &mut tasks,
                stream.event(1 + 1, AgentEventKind::TurnStarted { turn_id: turn }, None),
            )
            .unwrap();
        for sequence in 2..63 {
            report
                .apply_event(
                    &mut tasks,
                    stream.event(sequence + 1, AgentEventKind::TextDelta, None),
                )
                .unwrap();
        }
        report
            .apply_event(
                &mut tasks,
                stream.event(
                    63 + 1,
                    AgentEventKind::TurnCompleted { turn_id: turn },
                    None,
                ),
            )
            .unwrap();
        assert_eq!(report.events_applied, NATIVE_AGENT_EVENTS_PER_FRAME);
        assert_eq!(report.applied_turns.len(), 2);
        assert_eq!(
            report.applied_turns[0],
            AppliedAgentTurn {
                task_id: stream.task_id(),
                epoch: stream.epoch(),
                turn_id: turn,
                completed: false,
                status: TaskStatus::Working
            }
        );
        assert_eq!(
            report.applied_turns[1],
            AppliedAgentTurn {
                task_id: stream.task_id(),
                epoch: stream.epoch(),
                turn_id: turn,
                completed: true,
                status: TaskStatus::ReadyForReview
            }
        );
        assert_eq!(
            tasks.get(stream.task_id()).unwrap().status,
            TaskStatus::ReadyForReview
        );
    }

    #[test]
    fn rejected_turn_does_not_enter_semantic_report() {
        let (mut tasks, stream) = fixture();
        let mut report = AgentRuntimePollReport::default();
        assert!(report
            .apply_event(
                &mut tasks,
                stream.event(
                    1,
                    AgentEventKind::TurnCompleted {
                        turn_id: AgentTurnId::new()
                    },
                    None
                )
            )
            .is_err());
        assert!(report.applied_turns.is_empty());
        assert_eq!(report.events_applied, 0);
    }

    #[test]
    fn boundary_after_full_drain_is_reported_only_in_next_frame() {
        let (mut tasks, stream) = fixture();
        let turn = AgentTurnId::new();
        let mut first = AgentRuntimePollReport::default();
        first
            .apply_event(
                &mut tasks,
                stream.event(
                    1,
                    AgentEventKind::SessionStarted {
                        provider_session_id: None,
                        resumed: false,
                    },
                    None,
                ),
            )
            .unwrap();
        first
            .apply_event(
                &mut tasks,
                stream.event(1 + 1, AgentEventKind::TurnStarted { turn_id: turn }, None),
            )
            .unwrap();
        for sequence in 2..64 {
            first
                .apply_event(
                    &mut tasks,
                    stream.event(sequence + 1, AgentEventKind::TextDelta, None),
                )
                .unwrap();
        }
        assert_eq!(first.events_applied, NATIVE_AGENT_EVENTS_PER_FRAME);
        assert_eq!(first.applied_turns.len(), 1);
        assert!(!first.applied_turns[0].completed);
        let mut second = AgentRuntimePollReport::default();
        second
            .apply_event(
                &mut tasks,
                stream.event(
                    64 + 1,
                    AgentEventKind::TurnCompleted { turn_id: turn },
                    None,
                ),
            )
            .unwrap();
        assert_eq!(second.applied_turns.len(), 1);
        assert!(second.applied_turns[0].completed);
        assert_eq!(
            second.applied_turns[0].turn_id,
            first.applied_turns[0].turn_id
        );
        assert!(second
            .apply_event(
                &mut tasks,
                stream.event(
                    64 + 1,
                    AgentEventKind::TurnCompleted { turn_id: turn },
                    None
                )
            )
            .is_err());
        assert_eq!(second.applied_turns.len(), 1);
    }

    #[test]
    fn default_report_has_no_boundary_allocation() {
        let report = AgentRuntimePollReport::default();
        assert_eq!(report.applied_turns.capacity(), 0);
        assert!(!report.made_progress());
    }
}
